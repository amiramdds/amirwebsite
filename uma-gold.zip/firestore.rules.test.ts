import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

/**
 * UMA Gold — Security Rules & Schema Boundary Verification Suite
 * Verifies blueprint synchronization, Eight Pillars coverage, and Dirty Dozen invariants.
 */
const blueprint = JSON.parse(
  fs.readFileSync(path.resolve(process.cwd(), 'firebase-blueprint.json'), 'utf8')
);
const rules = fs.readFileSync(path.resolve(process.cwd(), 'firestore.rules'), 'utf8');

const expectedCollections = [
  'users',
  'user_profiles',
  'roles',
  'permissions',
  'gold_prices',
  'currency_prices',
  'market_history',
  'market_sources',
  'jewelry_categories',
  'jewelry_models',
  'inventory',
  'inventory_transactions',
  'production_plans',
  'production_records',
  'scrap_records',
  'returned_gold',
  'sales_records',
  'ai_forecasts',
  'ai_recommendations',
  'subscriptions',
  'payments',
  'invoices',
  'support_tickets',
  'support_messages',
  'notifications',
  'audit_logs',
  'legal_pages',
  'application_settings',
];

for (const col of expectedCollections) {
  assert.ok(
    rules.includes(`match /${col}/`),
    `Missing Firestore rules match block for collection: ${col}`
  );
  const blueprintKey = Object.keys(blueprint.firestore).find((k) =>
    k.startsWith(`/${col}/`)
  );
  assert.ok(blueprintKey, `Missing blueprint entry for collection: ${col}`);
}

assert.ok(rules.includes("rules_version = '2';"), 'Rules version 2 required');
assert.ok(
  rules.includes('match /{document=**} {\n      allow read, write: if false;'),
  'Default-deny catch-all rule required'
);
assert.ok(
  rules.includes('request.auth.token.email_verified == true'),
  'Email verification enforcement required'
);
assert.ok(
  !rules.includes('allow list: if isSignedIn();'),
  'Blanket list delegation is prohibited'
);

console.log(
  `Verified ${expectedCollections.length} UMA Gold collections against firebase-blueprint.json and Eight Pillars invariants.`
);
