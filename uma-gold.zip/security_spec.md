# UMA Gold — Firestore Security Specification (Phase 0)

## 1. Data Invariants
1. **Default-Deny Net**: Any unmapped path under `/databases/{database}/documents` is unconditionally denied.
2. **Identity Integrity & No Privilege Escalation**: Users can create their `/users/{userId}` document only with `role == 'free'` and `subscriptionTier == 'free'` (unless already a bootstrapped verified admin). Users cannot mutate their own `role`, `subscriptionTier`, or `status` on `/users/{userId}` or `/subscriptions/{subId}`.
3. **PII Isolation**: `/user_profiles/{userId}` (containing `email`, `phone`, `workshopName`) is readable/writable strictly by `ownerId == request.auth.uid` or verified admins. No blanket `isSignedIn()` read is ever allowed.
4. **Strict User Data Isolation**: All financial, inventory, production, scrap, returned gold, sales, AI forecasts/recommendations, payments, invoices, and notifications require `ownerId == request.auth.uid` on both single-doc reads and `list` queries (never trusting client query filters alone).
5. **Temporal Integrity**: `createdAt` and `updatedAt` are validated against `request.time` on creation/update; `createdAt` and `ownerId` are immutable once written.
6. **Terminal State Locking**: Support tickets in `closed` state cannot be modified by ordinary users; payment records cannot be marked `verified` or `refunded` directly by non-admin clients (`status` transitions are gated).
7. **Support Role Access**: `support_tickets` and `support_messages` allow access to the ticket owner (`ownerId == request.auth.uid`) or verified support agents / admins.
8. **Immutable Audit Logs**: `audit_logs` are append-only (`update` and `delete` are denied for everyone).

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Self-Admin Escalation**: `POST /users/{uid}` with `{ uid, displayName: "Attacker", role: "super_admin", subscriptionTier: "pro" }` -> `PERMISSION_DENIED`.
2. **Role Mutation via Update**: `PATCH /users/{uid}` changing `role` from `"free"` to `"admin"` -> `PERMISSION_DENIED`.
3. **Shadow Ghost Field Injection**: `POST /inventory/{id}` including unexpected key `isVerifiedAdmin: true` -> `PERMISSION_DENIED` (blocked by `hasOnly`).
4. **Spoofed OwnerId Creation**: `POST /scrap_records/{id}` with `ownerId: "victim_uid"` while authenticated as `"attacker_uid"` -> `PERMISSION_DENIED`.
5. **Cross-User PII Read**: `GET /user_profiles/victim_uid` by `"attacker_uid"` -> `PERMISSION_DENIED`.
6. **Unbounded List Scraping**: `LIST /inventory` without matching `ownerId == request.auth.uid` -> `PERMISSION_DENIED`.
7. **ID Poisoning Attack**: `GET /jewelry_models/<1500-char-junk-id>` -> `PERMISSION_DENIED` (blocked by `isValidId`).
8. **Unverified Email Admin Spoof**: Token with `email: "amirhossinbshirrr@gmail.com"` and `email_verified: false` -> `PERMISSION_DENIED`.
9. **Client Timestamp Forgery**: `POST /inventory_transactions/{id}` with backdated `createdAt` (`!= request.time`) -> `PERMISSION_DENIED`.
10. **Immutable Owner Tampering**: `PATCH /production_plans/{id}` attempting to change `ownerId` -> `PERMISSION_DENIED`.
11. **Terminal State Bypass**: `PATCH /support_tickets/{id}` attempting to reopen a `closed` ticket as a regular user -> `PERMISSION_DENIED`.
12. **Audit Log Erasure**: `DELETE /audit_logs/{id}` even by an admin -> `PERMISSION_DENIED`.
