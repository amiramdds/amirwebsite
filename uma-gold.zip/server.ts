import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import express, { Request, Response, NextFunction } from 'express';
import { initializeApp as initAdminApp, getApps as getAdminApps } from 'firebase-admin/app';
import { getAuth as getAdminAuth, DecodedIdToken } from 'firebase-admin/auth';
import { GoogleGenAI, Type } from '@google/genai';

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

// Load Firebase projectId for ID token verification (requires zero IAM)
const firebaseConfigPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
const firebaseConfig = fs.existsSync(firebaseConfigPath)
  ? JSON.parse(fs.readFileSync(firebaseConfigPath, 'utf8'))
  : { projectId: '' };

if (firebaseConfig.projectId && !getAdminApps().length) {
  initAdminApp({ projectId: firebaseConfig.projectId });
}

// Shared Gemini client (server-only)
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY_MISSING');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// In-memory rate limiter (per IP + route bucket)
const rateBuckets = new Map<string, { count: number; resetAt: number }>();
function rateLimit(maxRequests: number, windowMs: number) {
  return (req: Request, res: Response, next: NextFunction) => {
    const key = `${req.ip || 'unknown'}:${req.path}`;
    const now = Date.now();
    const bucket = rateBuckets.get(key);
    if (!bucket || now > bucket.resetAt) {
      rateBuckets.set(key, { count: 1, resetAt: now + windowMs });
      return next();
    }
    if (bucket.count >= maxRequests) {
      return res.status(429).json({
        errorCode: 'RATE_LIMITED',
        message: 'Too many requests. Please wait a moment before trying again.',
      });
    }
    bucket.count += 1;
    return next();
  };
}

// Firebase ID token verification middleware
interface AuthenticatedRequest extends Request {
  user?: DecodedIdToken;
}

async function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization || '';
    if (!authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ errorCode: 'UNAUTHORIZED', message: 'Missing Bearer token.' });
    }
    const token = authHeader.slice(7).trim();
    if (!token || !firebaseConfig.projectId) {
      return res.status(401).json({ errorCode: 'UNAUTHORIZED', message: 'Authentication unavailable.' });
    }
    const decoded = await getAdminAuth().verifyIdToken(token);
    if (!decoded.email_verified) {
      return res.status(403).json({
        errorCode: 'EMAIL_NOT_VERIFIED',
        message: 'Please verify your email address before accessing this resource.',
      });
    }
    req.user = decoded;
    return next();
  } catch (err) {
    return res.status(401).json({
      errorCode: 'INVALID_TOKEN',
      message: err instanceof Error ? err.message : 'Invalid authentication token.',
    });
  }
}

// SSRF guard for custom market feed URLs
function validateSafeExternalUrl(rawUrl: string): URL {
  const parsed = new URL(rawUrl);
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    throw new Error('Only HTTP/HTTPS URLs are permitted.');
  }
  const host = parsed.hostname.toLowerCase();
  const blockedPatterns = [
    /^localhost$/,
    /^127\./,
    /^10\./,
    /^192\.168\./,
    /^169\.254\./,
    /^172\.(1[6-9]|2[0-9]|3[0-1])\./,
    /^0\.0\.0\.0$/,
    /^::1$/,
  ];
  if (blockedPatterns.some((re) => re.test(host))) {
    throw new Error('Private or loopback hosts are blocked.');
  }
  return parsed;
}

// In-memory idempotency & sandbox payment state (never claims production activation without verification)
const processedPaymentAuthorities = new Map<
  string,
  { status: 'pending' | 'verified' | 'failed'; ownerId: string; planId: string; billingCycle: string; amount: number; currency: string; refId?: string }
>();
const paymentSigningSecret = process.env.PAYMENT_SIGNING_SECRET || crypto.randomBytes(32).toString('hex');

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  // Security headers
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  // 1. Health Endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, timestamp: new Date().toISOString() });
  });

  // 2. Market Data Adapter Layer
  app.get('/api/market/snapshot', rateLimit(30, 60_000), async (_req, res) => {
    const provider = (process.env.MARKET_API_PROVIDER || 'none').toLowerCase();
    const fetchedAt = new Date().toISOString();

    try {
      if (provider === 'goldapi' && process.env.GOLD_API_KEY) {
        const resp = await fetch('https://www.goldapi.io/api/XAU/USD', {
          headers: { 'x-access-token': process.env.GOLD_API_KEY },
          signal: AbortSignal.timeout(8000),
        });
        if (!resp.ok) {
          return res.status(502).json({
            configured: true,
            provider: 'goldapi',
            status: 'unavailable',
            fetchedAt,
            error: `GoldAPI responded with HTTP ${resp.status}`,
            goldPrices: [],
            currencyPrices: [],
          });
        }
        const data = (await resp.json()) as { price?: number; chp?: number };
        return res.json({
          configured: true,
          provider: 'goldapi',
          status: 'live',
          fetchedAt,
          goldPrices: [
            {
              symbol: 'XAU/USD',
              market: 'international',
              unit: 'USD/oz',
              price: Number(data.price || 0),
              change24hPct: Number(data.chp || 0),
              status: 'live',
              source: 'GoldAPI.io',
              updatedAt: fetchedAt,
            },
          ],
          currencyPrices: [],
        });
      }

      if (provider === 'metalsapi' && process.env.METALS_API_KEY) {
        const resp = await fetch(
          `https://metals-api.com/api/latest?access_key=${encodeURIComponent(process.env.METALS_API_KEY)}&base=USD&symbols=XAU,EUR`,
          { signal: AbortSignal.timeout(8000) }
        );
        if (!resp.ok) {
          return res.status(502).json({
            configured: true,
            provider: 'metalsapi',
            status: 'unavailable',
            fetchedAt,
            error: `Metals-API responded with HTTP ${resp.status}`,
            goldPrices: [],
            currencyPrices: [],
          });
        }
        const data = (await resp.json()) as { success?: boolean; rates?: { XAU?: number; EUR?: number } };
        const xauRate = data.rates?.XAU ? 1 / data.rates.XAU : 0;
        const eurRate = data.rates?.EUR ? 1 / data.rates.EUR : 0;
        return res.json({
          configured: true,
          provider: 'metalsapi',
          status: data.success ? 'live' : 'unavailable',
          fetchedAt,
          goldPrices: xauRate
            ? [
                {
                  symbol: 'XAU/USD',
                  market: 'international',
                  unit: 'USD/oz',
                  price: Number(xauRate.toFixed(2)),
                  change24hPct: 0,
                  status: 'live',
                  source: 'Metals-API',
                  updatedAt: fetchedAt,
                },
              ]
            : [],
          currencyPrices: eurRate
            ? [
                {
                  pair: 'EUR/USD',
                  rate: Number(eurRate.toFixed(4)),
                  change24hPct: 0,
                  status: 'live',
                  source: 'Metals-API',
                  updatedAt: fetchedAt,
                },
              ]
            : [],
        });
      }

      if (provider === 'custom' && process.env.CUSTOM_MARKET_FEED_URL) {
        const safeUrl = validateSafeExternalUrl(process.env.CUSTOM_MARKET_FEED_URL);
        const resp = await fetch(safeUrl.toString(), { signal: AbortSignal.timeout(8000) });
        if (!resp.ok) {
          return res.status(502).json({
            configured: true,
            provider: 'custom',
            status: 'unavailable',
            fetchedAt,
            error: `Custom feed returned HTTP ${resp.status}`,
            goldPrices: [],
            currencyPrices: [],
          });
        }
        const payload = await resp.json();
        return res.json({
          configured: true,
          provider: 'custom',
          status: 'live',
          fetchedAt,
          goldPrices: Array.isArray(payload.goldPrices) ? payload.goldPrices : [],
          currencyPrices: Array.isArray(payload.currencyPrices) ? payload.currencyPrices : [],
        });
      }

      // Honest unconfigured state — never fabricate live data
      return res.json({
        configured: false,
        provider,
        status: 'unavailable',
        fetchedAt,
        message:
          'No external live market API key is configured on the server. Manual admin entries or explicitly labeled demo evaluation data remain available.',
        goldPrices: [],
        currencyPrices: [],
      });
    } catch (err) {
      return res.status(502).json({
        configured: provider !== 'none',
        provider,
        status: 'unavailable',
        fetchedAt,
        error: err instanceof Error ? err.message : 'Market feed adapter error',
        goldPrices: [],
        currencyPrices: [],
      });
    }
  });

  // 3. Gemini AI Market Intelligence Forecast
  app.post('/api/ai/forecast', requireAuth, rateLimit(12, 60_000), async (req: AuthenticatedRequest, res) => {
    try {
      const {
        language = 'en',
        horizon = 'short_term',
        market = 'combined',
        goldPrices = [],
        currencyPrices = [],
        salesRecords = [],
        inventorySummary = null,
      } = req.body || {};

      if (!Array.isArray(goldPrices) || !Array.isArray(salesRecords)) {
        return res.status(400).json({ errorCode: 'INVALID_INPUT', message: 'Invalid market or sales arrays.' });
      }

      const ai = getGeminiClient();
      const salesCount = salesRecords.length;
      const insufficientSales = salesCount < 5;

      const systemInstruction = `You are the senior gold market quantitative analyst for UMA Gold.
Analyze ONLY the supplied factual inputs (gold prices, FX rates, inventory, and historical sales records).
Rules:
1. Never invent sales records or pretend to have live external prices beyond the provided payload.
2. Explicitly separate: (a) Historical Facts, (b) Calculated Metrics, and (c) AI-Generated Probabilistic Forecasts.
3. Never claim guaranteed financial returns.
4. If historical sales records count (${salesCount}) is below 5, set dataSufficiency to "insufficient" or "limited" and keep confidenceScore <= 55.
5. Respond in ${language === 'fa' ? 'formal Persian (Farsi)' : 'professional English'}.`;

      const promptPayload = JSON.stringify({
        horizon,
        market,
        goldPrices: goldPrices.slice(0, 16),
        currencyPrices: currencyPrices.slice(0, 10),
        salesRecordsCount: salesCount,
        salesRecordsSample: salesRecords.slice(0, 30),
        inventorySummary,
      });

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Generate a structured gold market and jewelry demand forecast based strictly on this telemetry:\n${promptPayload}`,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              dataSufficiency: { type: Type.STRING, enum: ['sufficient', 'limited', 'insufficient'] },
              confidenceScore: { type: Type.NUMBER },
              riskLevel: { type: Type.STRING, enum: ['low', 'medium', 'high'] },
              historicalFacts: { type: Type.ARRAY, items: { type: Type.STRING } },
              calculatedEstimates: { type: Type.ARRAY, items: { type: Type.STRING } },
              forecastOutlook: { type: Type.STRING },
              risingCategories: { type: Type.ARRAY, items: { type: Type.STRING } },
              decliningCategories: { type: Type.ARRAY, items: { type: Type.STRING } },
              keyDrivers: { type: Type.ARRAY, items: { type: Type.STRING } },
              disclaimer: { type: Type.STRING },
            },
            required: [
              'dataSufficiency',
              'confidenceScore',
              'riskLevel',
              'historicalFacts',
              'calculatedEstimates',
              'forecastOutlook',
              'risingCategories',
              'decliningCategories',
              'keyDrivers',
              'disclaimer',
            ],
          },
        },
      });

      const parsed = JSON.parse((response.text || '{}').trim());
      if (insufficientSales) {
        parsed.dataSufficiency = salesCount === 0 ? 'insufficient' : 'limited';
        parsed.confidenceScore = Math.min(Number(parsed.confidenceScore || 45), 55);
      }

      return res.json({
        ...parsed,
        generatedAt: new Date().toISOString(),
        modelUsed: 'gemini-4-hydrogen',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg === 'GEMINI_API_KEY_MISSING') {
        return res.status(503).json({
          errorCode: 'GEMINI_KEY_MISSING',
          message: 'GEMINI_API_KEY is not configured in server secrets.',
        });
      }
      return res.status(502).json({
        errorCode: 'AI_UPSTREAM_ERROR',
        message: msg,
      });
    }
  });

  // 4. Smart Jewelry Production Planner (Resource-Constrained AI Optimizer)
  app.post('/api/ai/production-plan', requireAuth, rateLimit(12, 60_000), async (req: AuthenticatedRequest, res) => {
    try {
      const {
        language = 'en',
        availableMeltedGrams,
        meltedPurity = 750,
        budget = 0,
        targetPurityKarat = 18,
        riskPreference = 'medium',
        profitObjective = 'balanced',
        preferredCategories = [],
        maxUnitsConstraint = 100,
        lossRatePct = 1.5,
        recoverableScrapPct = 4.0,
        gold18kPricePerGram = 0,
        catalogModels = [],
      } = req.body || {};

      const meltedG = Number(availableMeltedGrams);
      const purity = Number(meltedPurity);
      const budgetAmt = Number(budget);
      if (!Number.isFinite(meltedG) || meltedG <= 0 || !Number.isFinite(purity) || purity < 100 || purity > 999.9) {
        return res.status(400).json({ errorCode: 'INVALID_INPUT', message: 'Valid melted gold weight and purity are required.' });
      }
      if (!Array.isArray(catalogModels) || catalogModels.length === 0) {
        return res.status(400).json({ errorCode: 'EMPTY_CATALOG', message: 'At least one active jewelry model is required.' });
      }

      const targetPerMille = targetPurityKarat === 24 ? 999.9 : targetPurityKarat === 21 ? 875 : 750;
      const availableFineGold = meltedG * (purity / 1000);
      // Max gross 18K/target karat gold producible from available fine gold accounting for permanent loss
      const effectiveYieldFactor = 1 - Math.min(Math.max(Number(lossRatePct), 0), 15) / 100;
      const maxProducibleGrossGrams = (availableFineGold / (targetPerMille / 1000)) * effectiveYieldFactor;

      const sanitizedCatalog = catalogModels.slice(0, 20).map((m: Record<string, unknown>) => ({
        id: String(m.id || ''),
        nameEn: String(m.nameEn || ''),
        nameFa: String(m.nameFa || ''),
        categoryId: String(m.categoryId || ''),
        minWeightGrams: Number(m.minWeightGrams || 1),
        maxWeightGrams: Number(m.maxWeightGrams || 5),
        laborFeePct: Number(m.laborFeePct || 10),
        additionalCostPerUnit: Number(m.additionalCostPerUnit || 0),
        productionHours: Number(m.productionHours || 4),
        demandIndex: Number(m.demandIndex || 60),
      }));

      const ai = getGeminiClient();
      const systemInstruction = `You are the Master Jewelry Production Planner for UMA Gold.
Design up to 3 distinct production plan scenarios (Scenario A: Balanced Demand, Scenario B: High-Turnover Cashflow, Scenario C: Maximum Profit Margin) using ONLY the supplied registered catalog models.
CRITICAL HARD CONSTRAINTS (NEVER VIOLATE):
1. Total finished gross gold across all items in ANY scenario MUST NOT exceed ${maxProducibleGrossGrams.toFixed(2)} grams.
2. Total labor + additional manufacturing cost in ANY scenario MUST NOT exceed budget ${budgetAmt} (if budget > 0).
3. Total units in ANY scenario MUST NOT exceed ${Number(maxUnitsConstraint) || 100}.
4. Recommend unitWeightGrams strictly between each model's minWeightGrams and maxWeightGrams.
5. Respond in ${language === 'fa' ? 'formal Persian (Farsi)' : 'professional English'}.`;

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Generate 3 comparable jewelry production plans given:
Available Melted Gold: ${meltedG}g at ${purity}/1000 (${availableFineGold.toFixed(2)}g fine gold)
Max Producible Target Karat (${targetPurityKarat}K) Gross Gold after ${lossRatePct}% loss: ${maxProducibleGrossGrams.toFixed(2)}g
Recoverable Scrap Rate: ${recoverableScrapPct}%
Manufacturing Budget: ${budgetAmt}
18K Price Reference per gram: ${gold18kPricePerGram}
Preferred Categories: ${JSON.stringify(preferredCategories)}
Risk Preference: ${riskPreference}, Profit Objective: ${profitObjective}
Registered Catalog Models: ${JSON.stringify(sanitizedCatalog)}`,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              plans: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    planName: { type: Type.STRING },
                    strategyType: { type: Type.STRING, enum: ['balanced', 'turnover', 'margin'] },
                    riskLevel: { type: Type.STRING, enum: ['low', 'medium', 'high'] },
                    explanation: { type: Type.STRING },
                    items: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          modelId: { type: Type.STRING },
                          modelName: { type: Type.STRING },
                          categoryId: { type: Type.STRING },
                          units: { type: Type.INTEGER },
                          unitWeightGrams: { type: Type.NUMBER },
                          rationale: { type: Type.STRING },
                          demandConfidence: { type: Type.NUMBER },
                        },
                        required: ['modelId', 'modelName', 'categoryId', 'units', 'unitWeightGrams', 'rationale', 'demandConfidence'],
                      },
                    },
                  },
                  required: ['planName', 'strategyType', 'riskLevel', 'explanation', 'items'],
                },
              },
            },
            required: ['plans'],
          },
        },
      });

      const raw = JSON.parse((response.text || '{"plans":[]}').trim()) as {
        plans: Array<{
          planName: string;
          strategyType: string;
          riskLevel: string;
          explanation: string;
          items: Array<{
            modelId: string;
            modelName: string;
            categoryId: string;
            units: number;
            unitWeightGrams: number;
            rationale: string;
            demandConfidence: number;
          }>;
        }>;
      };

      // Deterministic server-side constraint enforcement: NEVER allow recommendations exceeding gold or budget
      const verifiedPlans = (raw.plans || []).slice(0, 3).map((plan) => {
        let runningGold = 0;
        let runningCost = 0;
        let totalUnits = 0;
        const clampedItems = [];

        for (const item of plan.items || []) {
          const catalogRef = sanitizedCatalog.find((c) => c.id === item.modelId) || sanitizedCatalog[0];
          const unitW = Math.min(
            Math.max(Number(item.unitWeightGrams || catalogRef.minWeightGrams), catalogRef.minWeightGrams),
            catalogRef.maxWeightGrams
          );
          let units = Math.max(0, Math.floor(Number(item.units || 0)));
          if (units === 0) continue;

          const unitLaborCost =
            gold18kPricePerGram > 0
              ? unitW * gold18kPricePerGram * (catalogRef.laborFeePct / 100) + catalogRef.additionalCostPerUnit
              : catalogRef.additionalCostPerUnit;

          while (units > 0) {
            const addedGold = units * unitW;
            const addedCost = units * unitLaborCost;
            const withinGold = runningGold + addedGold <= maxProducibleGrossGrams + 0.001;
            const withinBudget = budgetAmt <= 0 || runningCost + addedCost <= budgetAmt + 0.01;
            const withinUnitCap = totalUnits + units <= (Number(maxUnitsConstraint) || 100);
            if (withinGold && withinBudget && withinUnitCap) {
              break;
            }
            units -= 1;
          }

          if (units > 0) {
            const totalItemGold = Number((units * unitW).toFixed(2));
            const totalItemCost = Number((units * unitLaborCost).toFixed(2));
            runningGold += totalItemGold;
            runningCost += totalItemCost;
            totalUnits += units;
            clampedItems.push({
              ...item,
              units,
              unitWeightGrams: Number(unitW.toFixed(2)),
              totalGoldGrams: totalItemGold,
              estimatedLaborCost: totalItemCost,
            });
          }
        }

        const remainingGold = Math.max(0, Number((maxProducibleGrossGrams - runningGold).toFixed(2)));
        const estimatedGrossRevenue =
          gold18kPricePerGram > 0
            ? runningGold * gold18kPricePerGram * 1.18 + runningCost
            : runningCost * 1.25;
        const estimatedGoldValue = gold18kPricePerGram > 0 ? runningGold * gold18kPricePerGram : 0;
        const estimatedProfit = Number((estimatedGrossRevenue - estimatedGoldValue - runningCost).toFixed(2));

        return {
          planName: plan.planName,
          strategyType: plan.strategyType,
          riskLevel: plan.riskLevel,
          explanation: plan.explanation,
          items: clampedItems,
          totals: {
            totalUnits,
            totalGoldRequiredGrams: Number(runningGold.toFixed(2)),
            maxAvailableTargetGoldGrams: Number(maxProducibleGrossGrams.toFixed(2)),
            remainingGoldGrams: remainingGold,
            estimatedProductionCost: Number(runningCost.toFixed(2)),
            estimatedProfit,
          },
        };
      });

      return res.json({
        plans: verifiedPlans,
        constraintsVerified: true,
        generatedAt: new Date().toISOString(),
        modelUsed: 'gemini-4-hydrogen',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg === 'GEMINI_API_KEY_MISSING') {
        return res.status(503).json({
          errorCode: 'GEMINI_KEY_MISSING',
          message: 'GEMINI_API_KEY is not configured in server secrets.',
        });
      }
      return res.status(502).json({
        errorCode: 'AI_UPSTREAM_ERROR',
        message: msg,
      });
    }
  });

  // 5. Zarinpal Payment Initiation & Verification (Server-Authoritative)
  app.post('/api/payments/zarinpal/initiate', requireAuth, rateLimit(10, 60_000), async (req: AuthenticatedRequest, res) => {
    const merchantId = process.env.ZARINPAL_MERCHANT_ID || '';
    const isSandbox = process.env.ZARINPAL_SANDBOX === 'true';
    const { planId = 'pro', billingCycle = 'monthly', amount = 0, currency = 'IRR', callbackUrl } = req.body || {};

    if (!['pro', 'organization'].includes(planId) || !['monthly', 'annual'].includes(billingCycle)) {
      return res.status(400).json({ errorCode: 'INVALID_PLAN', message: 'Invalid subscription plan or billing cycle.' });
    }
    const numericAmount = Number(amount);
    if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
      return res.status(400).json({ errorCode: 'INVALID_AMOUNT', message: 'Payment amount must be positive.' });
    }

    if (!merchantId && !isSandbox) {
      return res.status(422).json({
        errorCode: 'GATEWAY_NOT_CONFIGURED',
        message: 'ZARINPAL_MERCHANT_ID is not configured on the server. Enable ZARINPAL_SANDBOX=true only for testing.',
      });
    }

    const ownerId = req.user!.uid;
    if (isSandbox) {
      const authority = `TEST_${crypto.randomBytes(12).toString('hex').toUpperCase()}`;
      processedPaymentAuthorities.set(authority, {
        status: 'pending',
        ownerId,
        planId,
        billingCycle,
        amount: numericAmount,
        currency,
      });
      return res.json({
        gateway: 'zarinpal',
        isTestMode: true,
        authority,
        paymentUrl: null,
        message: 'Sandbox test transaction initiated. Verify using server callback verification.',
      });
    }

    try {
      const targetCallback =
        callbackUrl || process.env.ZARINPAL_CALLBACK_URL || `${process.env.APP_URL || ''}/billing/history`;
      const zpRes = await fetch('https://api.zarinpal.com/pg/v4/payment/request.json', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          merchant_id: merchantId,
          amount: Math.round(numericAmount),
          callback_url: targetCallback,
          description: `UMA Gold ${planId} (${billingCycle}) subscription`,
        }),
        signal: AbortSignal.timeout(10000),
      });
      const zpData = (await zpRes.json()) as { data?: { code?: number; authority?: string }; errors?: unknown };
      if (zpData.data?.code === 100 && zpData.data.authority) {
        processedPaymentAuthorities.set(zpData.data.authority, {
          status: 'pending',
          ownerId,
          planId,
          billingCycle,
          amount: numericAmount,
          currency,
        });
        return res.json({
          gateway: 'zarinpal',
          isTestMode: false,
          authority: zpData.data.authority,
          paymentUrl: `https://www.zarinpal.com/pg/StartPay/${zpData.data.authority}`,
        });
      }
      return res.status(502).json({
        errorCode: 'ZARINPAL_REJECTED',
        message: 'Zarinpal initiation did not return success code 100.',
      });
    } catch (err) {
      return res.status(502).json({
        errorCode: 'ZARINPAL_NETWORK_ERROR',
        message: err instanceof Error ? err.message : 'Zarinpal network failure',
      });
    }
  });

  app.post('/api/payments/zarinpal/verify', requireAuth, rateLimit(10, 60_000), async (req: AuthenticatedRequest, res) => {
    const merchantId = process.env.ZARINPAL_MERCHANT_ID || '';
    const isSandbox = process.env.ZARINPAL_SANDBOX === 'true';
    const { authority, statusQuery = 'OK' } = req.body || {};

    if (!authority || typeof authority !== 'string') {
      return res.status(400).json({ errorCode: 'MISSING_AUTHORITY', message: 'Payment authority is required.' });
    }

    const record = processedPaymentAuthorities.get(authority);
    if (!record) {
      return res.status(404).json({ errorCode: 'AUTHORITY_NOT_FOUND', message: 'Unknown payment authority.' });
    }
    if (record.ownerId !== req.user!.uid) {
      return res.status(403).json({ errorCode: 'FORBIDDEN', message: 'Payment belongs to another user.' });
    }
    if (record.status === 'verified') {
      return res.status(409).json({
        errorCode: 'DUPLICATE_CALLBACK',
        message: 'This payment authority has already been verified.',
        refId: record.refId,
      });
    }

    if (statusQuery !== 'OK') {
      record.status = 'failed';
      return res.status(400).json({ errorCode: 'PAYMENT_CANCELLED', message: 'Payment was cancelled or failed at gateway.' });
    }

    if (isSandbox && authority.startsWith('TEST_')) {
      const refId = `SANDBOX_REF_${Date.now()}`;
      record.status = 'verified';
      record.refId = refId;
      const receiptSig = crypto
        .createHmac('sha256', paymentSigningSecret)
        .update(`${record.ownerId}:${authority}:${refId}`)
        .digest('hex');
      return res.json({
        verified: true,
        isTestMode: true,
        authority,
        refId,
        planId: record.planId,
        billingCycle: record.billingCycle,
        amount: record.amount,
        currency: record.currency,
        receiptSignature: receiptSig,
      });
    }

    if (!merchantId) {
      return res.status(422).json({ errorCode: 'GATEWAY_NOT_CONFIGURED', message: 'Zarinpal merchant ID missing.' });
    }

    try {
      const verifyRes = await fetch('https://api.zarinpal.com/pg/v4/payment/verify.json', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          merchant_id: merchantId,
          amount: Math.round(record.amount),
          authority,
        }),
        signal: AbortSignal.timeout(10000),
      });
      const verifyJson = (await verifyRes.json()) as { data?: { code?: number; ref_id?: number } };
      if (verifyJson.data?.code === 100 || verifyJson.data?.code === 101) {
        const refId = String(verifyJson.data.ref_id || Date.now());
        record.status = 'verified';
        record.refId = refId;
        const receiptSig = crypto
          .createHmac('sha256', paymentSigningSecret)
          .update(`${record.ownerId}:${authority}:${refId}`)
          .digest('hex');
        return res.json({
          verified: true,
          isTestMode: false,
          authority,
          refId,
          planId: record.planId,
          billingCycle: record.billingCycle,
          amount: record.amount,
          currency: record.currency,
          receiptSignature: receiptSig,
        });
      }
      record.status = 'failed';
      return res.status(400).json({ errorCode: 'VERIFICATION_FAILED', message: 'Gateway verification failed.' });
    } catch (err) {
      return res.status(502).json({
        errorCode: 'ZARINPAL_VERIFY_ERROR',
        message: err instanceof Error ? err.message : 'Verification error',
      });
    }
  });

  // Frontend serving: Vite middleware in development, static dist/ in production
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`UMA Gold server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start UMA Gold server:', err);
  process.exit(1);
});
