import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { ErrorBoundary } from './components/ui/ErrorBoundary';
import { WorkspaceShell } from './components/layout/WorkspaceShell';
import { LandingPage } from './components/pages/LandingPage';
import {
  IranMarketAnalyticsView,
  IntlMarketAnalyticsView,
  OverviewDashboard,
  PricesDirectoryView,
} from './components/pages/MarketViews';
import { AIPredictionsView, DemandAnalysisView } from './components/pages/IntelligenceViews';
import { ProductionPlannerView, PurityCalculatorView } from './components/pages/ProductionViews';
import { InventoryManagementView, JewelryCatalogView } from './components/pages/InventoryCatalogViews';
import {
  AuthView,
  PaymentHistoryView,
  PricingSubscriptionView,
  ProfileSettingsView,
  UserDashboardView,
} from './components/pages/AccountBillingViews';
import {
  ContactView,
  FaqView,
  LegalPageView,
  SupportCenterView,
  SupportChatView,
  SupportTicketsView,
} from './components/pages/SupportLegalViews';
import { AdminConsoleView } from './components/pages/AdminConsoleView';

const RouteViewport: React.FC = () => {
  const { route } = useApp();

  if (route === 'landing') {
    return <LandingPage />;
  }

  let view: React.ReactNode;
  switch (route) {
    case 'overview':
      view = <OverviewDashboard />;
      break;
    case 'prices':
      view = <PricesDirectoryView />;
      break;
    case 'iran-market':
      view = <IranMarketAnalyticsView />;
      break;
    case 'intl-market':
      view = <IntlMarketAnalyticsView />;
      break;
    case 'ai-predictions':
      view = <AIPredictionsView />;
      break;
    case 'demand-analysis':
      view = <DemandAnalysisView />;
      break;
    case 'production-planner':
      view = <ProductionPlannerView />;
      break;
    case 'inventory':
      view = <InventoryManagementView />;
      break;
    case 'catalog':
      view = <JewelryCatalogView />;
      break;
    case 'calculator':
      view = <PurityCalculatorView />;
      break;
    case 'user-dashboard':
      view = <UserDashboardView />;
      break;
    case 'pricing':
      view = <PricingSubscriptionView />;
      break;
    case 'payments':
      view = <PaymentHistoryView />;
      break;
    case 'support-center':
      view = <SupportCenterView />;
      break;
    case 'support-chat':
      view = <SupportChatView />;
      break;
    case 'support-tickets':
      view = <SupportTicketsView />;
      break;
    case 'faq':
      view = <FaqView />;
      break;
    case 'contact':
      view = <ContactView />;
      break;
    case 'auth':
      view = <AuthView />;
      break;
    case 'profile':
      view = <ProfileSettingsView />;
      break;
    case 'legal-privacy':
      view = <LegalPageView slug="privacy" />;
      break;
    case 'legal-terms':
      view = <LegalPageView slug="terms" />;
      break;
    case 'legal-refund':
      view = <LegalPageView slug="subscription-refund" />;
      break;
    case 'legal-ai':
      view = <LegalPageView slug="ai-disclaimer" />;
      break;
    case 'admin':
      view = <AdminConsoleView />;
      break;
    default:
      view = <OverviewDashboard />;
  }

  return <WorkspaceShell>{view}</WorkspaceShell>;
};

export default function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <RouteViewport />
      </AppProvider>
    </ErrorBoundary>
  );
}
