import React, { useState } from 'react';
import {
  Activity,
  BarChart3,
  Bot,
  Calculator,
  CreditCard,
  FileText,
  Gem,
  Globe,
  HelpCircle,
  LayoutDashboard,
  LogOut,
  Mail,
  Menu,
  MessageSquare,
  Package,
  Scale,
  Settings,
  Shield,
  Sparkles,
  Ticket,
  TrendingUp,
  User as UserIcon,
  X,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../i18n/translations';
import { PageRoute } from '../../types/domain';

interface NavGroup {
  labelEn: string;
  labelFa: string;
  items: { route: PageRoute; labelKey: keyof typeof TRANSLATIONS.en.nav; icon: React.ReactNode; adminOnly?: boolean }[];
}

export const WorkspaceShell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const {
    lang,
    setLang,
    route,
    navigate,
    user,
    isAdmin,
    isSupportOrAdmin,
    isVerified,
    subscriptionTier,
    demoMode,
    setDemoMode,
    marketProviderStatus,
    logout,
    resendVerification,
    toasts,
    dismissToast,
  } = useApp();

  const [mobileOpen, setMobileOpen] = useState(false);
  const t = TRANSLATIONS[lang];

  const groups: NavGroup[] = [
    {
      labelEn: 'Markets & Analytics',
      labelFa: 'بازارها و تحلیل',
      items: [
        { route: 'overview', labelKey: 'overview', icon: <LayoutDashboard className="w-4 h-4" /> },
        { route: 'prices', labelKey: 'prices', icon: <TrendingUp className="w-4 h-4" /> },
        { route: 'iran-market', labelKey: 'iranMarket', icon: <BarChart3 className="w-4 h-4" /> },
        { route: 'intl-market', labelKey: 'intlMarket', icon: <Globe className="w-4 h-4" /> },
      ],
    },
    {
      labelEn: 'AI & Workshop',
      labelFa: 'هوش مصنوعی و کارگاه',
      items: [
        { route: 'ai-predictions', labelKey: 'aiPredictions', icon: <Bot className="w-4 h-4" /> },
        { route: 'demand-analysis', labelKey: 'demandAnalysis', icon: <Activity className="w-4 h-4" /> },
        { route: 'production-planner', labelKey: 'productionPlanner', icon: <Sparkles className="w-4 h-4" /> },
        { route: 'calculator', labelKey: 'calculator', icon: <Calculator className="w-4 h-4" /> },
        { route: 'inventory', labelKey: 'inventory', icon: <Package className="w-4 h-4" /> },
        { route: 'catalog', labelKey: 'catalog', icon: <Gem className="w-4 h-4" /> },
      ],
    },
    {
      labelEn: 'Account & Billing',
      labelFa: 'حساب و اشتراک',
      items: [
        { route: 'user-dashboard', labelKey: 'userDashboard', icon: <UserIcon className="w-4 h-4" /> },
        { route: 'pricing', labelKey: 'pricing', icon: <CreditCard className="w-4 h-4" /> },
        { route: 'payments', labelKey: 'payments', icon: <FileText className="w-4 h-4" /> },
        { route: 'profile', labelKey: 'profile', icon: <Settings className="w-4 h-4" /> },
      ],
    },
    {
      labelEn: 'Support & Governance',
      labelFa: 'پشتیبانی و قوانین',
      items: [
        { route: 'support-center', labelKey: 'supportCenter', icon: <HelpCircle className="w-4 h-4" /> },
        { route: 'support-chat', labelKey: 'supportChat', icon: <MessageSquare className="w-4 h-4" /> },
        { route: 'support-tickets', labelKey: 'supportTickets', icon: <Ticket className="w-4 h-4" /> },
        { route: 'faq', labelKey: 'faq', icon: <HelpCircle className="w-4 h-4" /> },
        { route: 'contact', labelKey: 'contact', icon: <Mail className="w-4 h-4" /> },
        { route: 'legal-ai', labelKey: 'legalAi', icon: <Scale className="w-4 h-4" /> },
      ],
    },
  ];

  if (isAdmin || isSupportOrAdmin) {
    groups.push({
      labelEn: 'Administration',
      labelFa: 'مدیریت پلتفرم',
      items: [{ route: 'admin', labelKey: 'admin', icon: <Shield className="w-4 h-4" />, adminOnly: true }],
    });
  }

  const handleNav = (r: PageRoute) => {
    navigate(r);
    setMobileOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#09090B] text-[#F5F2EB] flex flex-col lg:flex-row">
      {/* Mobile Header (kept compact <= 56px) */}
      <header className="lg:hidden sticky top-0 z-40 h-14 bg-[#09090B]/95 backdrop-blur border-b border-[#24242B] px-4 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={() => handleNav('landing')}
          className="font-display text-xl font-semibold tracking-tight text-[#E5C76B] whitespace-nowrap shrink-0"
        >
          {t.brand}
        </button>
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setLang(lang === 'en' ? 'fa' : 'en')}
            className="px-2.5 py-1 text-xs font-medium border border-[#24242B] rounded-md text-[#D4CFC4] hover:border-[#D4AF37] whitespace-nowrap shrink-0"
          >
            {lang === 'en' ? 'فارسی' : 'EN'}
          </button>
          <button
            type="button"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle Menu"
            className="p-2 text-[#D4CFC4] hover:text-[#E5C76B]"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Sidebar */}
      <aside
        className={`${
          mobileOpen ? 'fixed inset-0 top-14 z-30 block' : 'hidden'
        } lg:block lg:w-64 lg:shrink-0 bg-[#0D0D10] border-e border-[#24242B] flex flex-col justify-between overflow-y-auto`}
      >
        <div className="p-5 space-y-6">
          <div className="hidden lg:flex items-center justify-between gap-2 pb-4 border-b border-[#24242B]">
            <button
              type="button"
              onClick={() => handleNav('landing')}
              className="font-display text-2xl font-semibold tracking-tight text-[#E5C76B] whitespace-nowrap shrink-0"
            >
              {t.brand}
            </button>
            <span className="text-[11px] font-mono-num text-[#9A968E] uppercase">
              {subscriptionTier}
            </span>
          </div>

          <nav className="space-y-5">
            {groups.map((g) => (
              <div key={g.labelEn}>
                <div className="text-[11px] font-medium text-[#7E7B74] px-2.5 mb-1.5">
                  {lang === 'fa' ? g.labelFa : g.labelEn}
                </div>
                <div className="space-y-0.5">
                  {g.items.map((item) => {
                    const active = route === item.route;
                    return (
                      <button
                        key={item.route}
                        type="button"
                        onClick={() => handleNav(item.route)}
                        className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm transition-colors whitespace-nowrap ${
                          active
                            ? 'bg-[#D4AF37]/15 text-[#E5C76B] font-medium'
                            : 'text-[#B8B3A8] hover:text-[#F5F2EB] hover:bg-[#18181D]'
                        }`}
                      >
                        <span className="shrink-0">{item.icon}</span>
                        <span className="truncate">{t.nav[item.labelKey]}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </nav>
        </div>

        {/* Sidebar Bottom Footer */}
        <div className="p-4 border-t border-[#24242B] space-y-3">
          <div className="flex items-center justify-between gap-2 text-xs text-[#9A968E]">
            <span>{lang === 'fa' ? 'حالت دمو' : 'Demo Feed'}</span>
            <button
              type="button"
              onClick={() => setDemoMode(!demoMode)}
              className={`px-2 py-0.5 rounded text-[11px] font-medium border transition-colors whitespace-nowrap shrink-0 ${
                demoMode
                  ? 'border-[#D4AF37]/50 text-[#E5C76B] bg-[#D4AF37]/10'
                  : 'border-[#24242B] text-[#7E7B74]'
              }`}
            >
              {demoMode ? (lang === 'fa' ? 'فعال' : 'ON') : lang === 'fa' ? 'خاموش' : 'OFF'}
            </button>
          </div>
          {user ? (
            <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#24242B]">
              <button
                type="button"
                onClick={() => handleNav('profile')}
                className="text-xs text-[#D4CFC4] hover:text-[#E5C76B] truncate text-start"
              >
                {user.displayName || user.email}
              </button>
              <button
                type="button"
                onClick={() => void logout()}
                title={t.nav.signOut}
                className="p-1.5 text-[#9A968E] hover:text-[#EF4444] shrink-0"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => handleNav('auth')}
              className="w-full py-2 px-3 text-xs font-medium bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B] transition-colors whitespace-nowrap"
            >
              {t.nav.signIn}
            </button>
          )}
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Desktop Workspace Top Toolbar */}
        <div className="hidden lg:flex items-center justify-between gap-6 px-8 h-14 border-b border-[#24242B] bg-[#09090B]/80 backdrop-blur sticky top-0 z-20">
          <div className="flex items-center gap-3 text-xs text-[#9A968E] min-w-0">
            <span className="text-[#F5F2EB] font-medium truncate">
              {t.nav[
                (Object.entries({
                  overview: 'overview',
                  prices: 'prices',
                  'iran-market': 'iranMarket',
                  'intl-market': 'intlMarket',
                  'ai-predictions': 'aiPredictions',
                  'demand-analysis': 'demandAnalysis',
                  'production-planner': 'productionPlanner',
                  inventory: 'inventory',
                  catalog: 'catalog',
                  calculator: 'calculator',
                  'user-dashboard': 'userDashboard',
                  pricing: 'pricing',
                  payments: 'payments',
                  'support-center': 'supportCenter',
                  'support-chat': 'supportChat',
                  'support-tickets': 'supportTickets',
                  faq: 'faq',
                  contact: 'contact',
                  auth: 'signIn',
                  profile: 'profile',
                  'legal-privacy': 'legalPrivacy',
                  'legal-terms': 'legalTerms',
                  'legal-refund': 'legalRefund',
                  'legal-ai': 'legalAi',
                  admin: 'admin',
                }) as [string, keyof typeof TRANSLATIONS.en.nav][]).find(([k]) => k === route)?.[1] || 'overview'
              ]}
            </span>
            <span aria-hidden="true">·</span>
            <span className="truncate">
              {marketProviderStatus.configured
                ? `${t.demoBanner.liveApiActive} (${marketProviderStatus.provider})`
                : demoMode
                ? t.demoBanner.title
                : t.demoBanner.manualMode}
            </span>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="flex items-center border border-[#24242B] rounded-lg p-0.5 bg-[#121216]">
              <button
                type="button"
                onClick={() => setLang('en')}
                className={`px-2.5 py-1 text-xs rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  lang === 'en' ? 'bg-[#D4AF37] text-[#09090B] font-semibold' : 'text-[#9A968E] hover:text-[#F5F2EB]'
                }`}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => setLang('fa')}
                className={`px-2.5 py-1 text-xs rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  lang === 'fa' ? 'bg-[#D4AF37] text-[#09090B] font-semibold' : 'text-[#9A968E] hover:text-[#F5F2EB]'
                }`}
              >
                فارسی
              </button>
            </div>
            {!user && (
              <button
                type="button"
                onClick={() => navigate('auth')}
                className="px-4 py-1.5 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B] transition-colors whitespace-nowrap shrink-0"
              >
                {t.nav.signIn}
              </button>
            )}
          </div>
        </div>

        {/* Unverified Email Warning Banner */}
        {user && !isVerified && (
          <div className="bg-[#F59E0B]/10 border-b border-[#F59E0B]/30 px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs text-[#FCD34D]">
            <span>{t.common.verifyEmailNotice}</span>
            <button
              type="button"
              onClick={() => void resendVerification()}
              className="px-3 py-1 bg-[#F59E0B]/20 hover:bg-[#F59E0B]/30 rounded text-xs font-medium whitespace-nowrap shrink-0"
            >
              {lang === 'fa' ? 'ارسال مجدد ایمیل تایید' : 'Resend Verification'}
            </button>
          </div>
        )}

        {/* Demo Mode Honest Attribution Strip */}
        {demoMode && !marketProviderStatus.configured && (
          <div className="bg-[#121216] border-b border-[#24242B] px-6 lg:px-8 py-2 flex flex-wrap items-center justify-between gap-2 text-xs text-[#B8B3A8]">
            <span>
              <strong className="text-[#E5C76B] font-medium me-2">{t.demoBanner.title}:</strong>
              {t.demoBanner.desc}
            </span>
            <button
              type="button"
              onClick={() => setDemoMode(false)}
              className="text-xs text-[#9A968E] hover:text-[#E5C76B] underline whitespace-nowrap shrink-0"
            >
              {lang === 'fa' ? 'مخفی‌سازی داده‌های دمو' : 'Hide Demo Feed'}
            </button>
          </div>
        )}

        {/* Viewport Content */}
        <main className="flex-1 p-5 lg:p-8 max-w-[1320px] w-full mx-auto">{children}</main>

        {/* Quiet Footer */}
        <footer className="border-t border-[#24242B] px-6 lg:px-8 py-5 text-xs text-[#7E7B74] flex flex-wrap items-center justify-between gap-4">
          <span>© 2026 UMA Gold · amiruma · amirhossinbasirpor@gmail.com</span>
          <div className="flex flex-wrap items-center gap-4">
            <button type="button" onClick={() => navigate('legal-privacy')} className="hover:text-[#D4AF37]">
              {t.nav.legalPrivacy}
            </button>
            <button type="button" onClick={() => navigate('legal-terms')} className="hover:text-[#D4AF37]">
              {t.nav.legalTerms}
            </button>
            <button type="button" onClick={() => navigate('legal-refund')} className="hover:text-[#D4AF37]">
              {t.nav.legalRefund}
            </button>
            <button type="button" onClick={() => navigate('legal-ai')} className="hover:text-[#D4AF37]">
              {t.nav.legalAi}
            </button>
          </div>
        </footer>
      </div>

      {/* Non-blocking Toast Container */}
      {toasts.length > 0 && (
        <div className="fixed bottom-4 end-4 z-50 flex flex-col gap-2 max-w-sm w-full px-4 sm:px-0">
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className={`flex items-center justify-between gap-3 px-4 py-3 rounded-lg border text-xs shadow-lg ${
                toast.type === 'error'
                  ? 'bg-[#1F1215] border-[#EF4444]/40 text-[#FCA5A5]'
                  : toast.type === 'success'
                  ? 'bg-[#101C16] border-[#10B981]/40 text-[#6EE7B7]'
                  : 'bg-[#16161B] border-[#D4AF37]/40 text-[#F5E6B3]'
              }`}
            >
              <span>{toast.text}</span>
              <button type="button" onClick={() => dismissToast(toast.id)} className="shrink-0 opacity-70 hover:opacity-100">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
