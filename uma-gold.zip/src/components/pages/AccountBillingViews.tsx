import React, { useEffect, useState } from 'react';
import { Check, CreditCard, Download, FileText, KeyRound, ShieldAlert, Trash2 } from 'lucide-react';
import { addDoc, collection, deleteDoc, doc, getDoc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { deleteUser } from 'firebase/auth';
import { useApp } from '../../context/AppContext';
import { auth, db, OperationType, handleFirestoreError } from '../../firebase';
import { TRANSLATIONS, formatMoney, formatNum } from '../../i18n/translations';
import { PageRoute } from '../../types/domain';

export const UserDashboardView: React.FC = () => {
  const { lang, user, isVerified, inventory, savedPlans, salesRecords, subscriptionTier, navigate, pushToast } = useApp();
  const t = TRANSLATIONS[lang];

  if (!user || !isVerified) {
    return (
      <div className="bg-[#121216] border border-[#24242B] rounded-xl p-8 text-center space-y-4">
        <h2 className="font-display text-2xl text-[#F5F2EB]">{t.nav.userDashboard}</h2>
        <p className="text-sm text-[#9A968E]">{t.common.signInRequired}</p>
        <button type="button" onClick={() => navigate('auth')} className="px-5 py-2.5 text-sm font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg">
          {t.common.goToAuth}
        </button>
      </div>
    );
  }

  const handleDeletePlan = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'production_plans', id));
      pushToast('info', lang === 'fa' ? 'برنامه حذف شد.' : 'Plan removed.');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `production_plans/${id}`);
    }
  };

  const handleExportReport = () => {
    const payload = {
      exportedAt: new Date().toISOString(),
      subscriptionTier,
      inventory,
      savedPlans,
      salesRecords,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `uma-gold-workspace-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{t.nav.userDashboard}</h1>
          <p className="text-sm text-[#9A968E] mt-1">
            {user.displayName || user.email} · {lang === 'fa' ? 'اشتراک:' : 'Tier:'} <strong className="text-[#E5C76B] uppercase">{subscriptionTier}</strong>
          </p>
        </div>
        <button
          type="button"
          onClick={handleExportReport}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium border border-[#24242B] rounded-lg hover:border-[#D4AF37] text-[#E5C76B]"
        >
          <Download className="w-4 h-4" />
          <span>{t.common.exportJson}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'طلای آب‌شده موجود' : 'Melted Stock'}</div>
          <div className="text-2xl font-semibold text-[#E5C76B] font-mono-num mt-1">{formatNum(inventory?.meltedGoldGrams || 0, lang)} g</div>
        </div>
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'برنامه‌های تولید ذخیره‌شده' : 'Saved Production Plans'}</div>
          <div className="text-2xl font-semibold text-[#F5F2EB] font-mono-num mt-1">{savedPlans.length}</div>
        </div>
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'سوابق فروش ثبت‌شده' : 'Sales Logs'}</div>
          <div className="text-2xl font-semibold text-[#F5F2EB] font-mono-num mt-1">{salesRecords.length}</div>
        </div>
      </div>

      <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-[#F5F2EB]">
            {lang === 'fa' ? 'برنامه‌های تولید ذخیره‌شده' : 'Saved Production Plans'}
          </h3>
          <button type="button" onClick={() => navigate('production-planner')} className="text-xs text-[#E5C76B] hover:underline">
            {lang === 'fa' ? '+ برنامه جدید' : '+ New Plan'}
          </button>
        </div>
        {savedPlans.length === 0 ? (
          <p className="text-xs text-[#7E7B74]">{t.common.empty}</p>
        ) : (
          <div className="divide-y divide-[#24242B]">
            {savedPlans.map((p) => (
              <div key={p.id} className="py-3 flex flex-wrap items-center justify-between gap-4">
                <div className="space-y-1 max-w-2xl">
                  <div className="text-sm font-medium text-[#F5F2EB]">{p.title}</div>
                  <div className="text-xs text-[#9A968E]">{p.summary}</div>
                  <div className="text-xs font-mono-num text-[#D4AF37]">
                    Used: {p.totalGoldUsedGrams}g / {p.availableMeltedGrams}g · Est. Profit: {formatNum(p.estimatedProfit, lang, 0)} · Risk: {p.riskLevel}
                  </div>
                </div>
                <button type="button" onClick={() => void handleDeletePlan(p.id)} className="text-[#9A968E] hover:text-[#EF4444]">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export const PricingSubscriptionView: React.FC = () => {
  const { lang, user, isVerified, appSettings, subscriptionTier, getAuthToken, pushToast, navigate } = useApp();
  const t = TRANSLATIONS[lang];
  const [cycle, setCycle] = useState<'monthly' | 'annual'>('monthly');
  const [currency, setCurrency] = useState<'IRR' | 'USD'>('IRR');
  const [loading, setLoading] = useState(false);
  const [gatewayNote, setGatewayNote] = useState('');

  const proPrice =
    currency === 'IRR'
      ? cycle === 'monthly'
        ? appSettings.proMonthlyIrr
        : appSettings.proAnnualIrr
      : cycle === 'monthly'
      ? appSettings.proMonthlyUsd
      : appSettings.proAnnualUsd;

  const handleCheckout = async (planId: 'pro' | 'organization') => {
    if (!user || !isVerified) {
      pushToast('info', t.common.signInRequired);
      navigate('auth');
      return;
    }
    setLoading(true);
    setGatewayNote('');
    const amount = planId === 'pro' ? proPrice : Math.round(proPrice * 2.2);
    try {
      const token = await getAuthToken();
      const resp = await fetch('/api/payments/zarinpal/initiate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          planId,
          billingCycle: cycle,
          amount,
          currency,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        setGatewayNote(data.message || 'Payment gateway is not configured on the server.');
        return;
      }

      // Record pending payment in user's Firestore payments collection
      await addDoc(collection(db, 'payments'), {
        ownerId: user.uid,
        planId,
        billingCycle: cycle,
        amount,
        currency,
        gateway: 'zarinpal',
        authority: data.authority || '',
        refId: '',
        status: 'pending',
        isTestMode: Boolean(data.isTestMode),
        createdAt: serverTimestamp(),
      });

      if (data.paymentUrl) {
        setGatewayNote(
          `${lang === 'fa' ? 'درگاه آماده است:' : 'Gateway ready:'} ${data.paymentUrl} (Authority: ${data.authority})`
        );
      } else {
        setGatewayNote(
          `${lang === 'fa' ? 'تراکنش تستی سندباکس ایجاد شد:' : 'Sandbox test transaction initiated:'} ${data.authority}`
        );
        navigate('payments');
      }
    } catch (err) {
      setGatewayNote(err instanceof Error ? err.message : 'Checkout initiation failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{t.nav.pricing}</h1>
          <p className="text-sm text-[#9A968E] mt-1">
            {lang === 'fa'
              ? 'تعرفه‌های شفاف برای طلافروشان، کارگاه‌ها و سازمان‌ها — تایید پرداخت صرفاً سمت سرور'
              : 'Transparent monthly & annual plans with server-verified Zarinpal & international gateway architecture.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center p-1 bg-[#121216] border border-[#24242B] rounded-lg">
            {(['monthly', 'annual'] as const).map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setCycle(c)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap ${
                  cycle === c ? 'bg-[#D4AF37] text-[#09090B]' : 'text-[#9A968E]'
                }`}
              >
                {c === 'monthly' ? (lang === 'fa' ? 'ماهانه' : 'Monthly') : lang === 'fa' ? 'سالانه' : 'Annual'}
              </button>
            ))}
          </div>
          <div className="flex items-center p-1 bg-[#121216] border border-[#24242B] rounded-lg">
            {(['IRR', 'USD'] as const).map((cur) => (
              <button
                key={cur}
                type="button"
                onClick={() => setCurrency(cur)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap ${
                  currency === cur ? 'bg-[#D4AF37] text-[#09090B]' : 'text-[#9A968E]'
                }`}
              >
                {cur}
              </button>
            ))}
          </div>
        </div>
      </div>

      {gatewayNote && (
        <div className="bg-[#16161B] border border-[#D4AF37]/40 rounded-xl p-4 text-xs text-[#F5E6B3]">
          {gatewayNote}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Free Plan */}
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-6 flex flex-col justify-between gap-6">
          <div className="space-y-4">
            <div>
              <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'برای شروع و ارزیابی' : 'For evaluation & basic monitoring'}</div>
              <h3 className="text-xl font-semibold text-[#F5F2EB] mt-1">{lang === 'fa' ? 'طرح رایگان' : 'Free Plan'}</h3>
              <div className="text-2xl font-semibold text-[#E5C76B] font-mono-num mt-3">
                {formatMoney(0, currency, lang)}
              </div>
            </div>
            <ul className="space-y-2 text-xs text-[#B8B3A8]">
              <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-[#10B981]" /> {lang === 'fa' ? 'داشبورد قیمت طلا و ارز' : 'Market price dashboard'}</li>
              <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-[#10B981]" /> {lang === 'fa' ? 'ماشین‌حساب پایه عیار و سود' : 'Basic purity & profit calculator'}</li>
              <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-[#10B981]" /> {lang === 'fa' ? 'تحلیل پایه بازار' : 'Basic market parity analysis'}</li>
            </ul>
          </div>
          <div className="text-xs text-[#7E7B74] pt-4 border-t border-[#24242B]">
            {subscriptionTier === 'free' ? (lang === 'fa' ? 'طرح فعلی شما' : 'Current Plan') : 'Included'}
          </div>
        </div>

        {/* Pro Plan */}
        <div className="bg-[#161512] border border-[#D4AF37] rounded-xl p-6 flex flex-col justify-between gap-6">
          <div className="space-y-4">
            <div>
              <div className="text-xs text-[#D4AF37]">{lang === 'fa' ? 'برای کارگاه‌ها و طلافروشان' : 'For active workshops & retailers'}</div>
              <h3 className="text-xl font-semibold text-[#F5F2EB] mt-1">{lang === 'fa' ? 'طرح حرفه‌ای (Pro)' : 'Professional Plan'}</h3>
              <div className="text-2xl font-semibold text-[#E5C76B] font-mono-num mt-3">
                {formatMoney(proPrice, currency, lang)}
              </div>
            </div>
            <ul className="space-y-2 text-xs text-[#D4CFC4]">
              <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-[#D4AF37]" /> {lang === 'fa' ? 'پیش‌بینی‌های پیشرفته هوش مصنوعی' : 'Advanced Gemini AI forecasts'}</li>
              <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-[#D4AF37]" /> {lang === 'fa' ? 'برنامه‌ریز تولید چندسناریویی' : 'Multi-plan AI production optimizer'}</li>
              <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-[#D4AF37]" /> {lang === 'fa' ? 'مدیریت کامل موجودی، ضایعات و مرجوعی' : 'Full inventory, scrap & return ledger'}</li>
              <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-[#D4AF37]" /> {lang === 'fa' ? 'گزارش‌های سودآوری و ذخیره نامحدود' : 'Saved production & profitability reports'}</li>
            </ul>
          </div>
          <button
            type="button"
            disabled={loading}
            onClick={() => void handleCheckout('pro')}
            className="w-full py-2.5 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B] flex items-center justify-center gap-2"
          >
            <CreditCard className="w-4 h-4" />
            <span>{lang === 'fa' ? 'پرداخت و ارتقا (زرین‌پال)' : 'Checkout via Zarinpal'}</span>
          </button>
        </div>

        {/* Organization Plan */}
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-6 flex flex-col justify-between gap-6">
          <div className="space-y-4">
            <div>
              <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'برای کارخانجات و هلدینگ‌ها' : 'For multi-bench factories & desks'}</div>
              <h3 className="text-xl font-semibold text-[#F5F2EB] mt-1">{lang === 'fa' ? 'طرح سازمانی' : 'Organization Plan'}</h3>
              <div className="text-2xl font-semibold text-[#E5C76B] font-mono-num mt-3">
                {formatMoney(Math.round(proPrice * 2.2), currency, lang)}
              </div>
            </div>
            <ul className="space-y-2 text-xs text-[#B8B3A8]">
              <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-[#10B981]" /> {lang === 'fa' ? 'تمامی امکانات طرح حرفه‌ای' : 'All Professional capabilities'}</li>
              <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-[#10B981]" /> {lang === 'fa' ? 'پشتیبانی اختصاصی SLA' : 'Priority support SLA'}</li>
              <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-[#10B981]" /> {lang === 'fa' ? 'اتصال اختصاصی فید بازار' : 'Custom market feed integration'}</li>
            </ul>
          </div>
          <button
            type="button"
            disabled={loading}
            onClick={() => void handleCheckout('organization')}
            className="w-full py-2.5 text-xs font-semibold border border-[#D4AF37]/60 text-[#E5C76B] rounded-lg hover:bg-[#D4AF37]/10"
          >
            {lang === 'fa' ? 'درخواست و پرداخت سازمانی' : 'Subscribe Organization'}
          </button>
        </div>
      </div>
    </div>
  );
};

export const PaymentHistoryView: React.FC = () => {
  const { lang, user, isVerified, payments, getAuthToken, pushToast, navigate } = useApp();
  const t = TRANSLATIONS[lang];
  const [verifying, setVerifying] = useState('');

  if (!user || !isVerified) {
    return (
      <div className="bg-[#121216] border border-[#24242B] rounded-xl p-8 text-center space-y-4">
        <h2 className="font-display text-2xl text-[#F5F2EB]">{t.nav.payments}</h2>
        <p className="text-sm text-[#9A968E]">{t.common.signInRequired}</p>
        <button type="button" onClick={() => navigate('auth')} className="px-5 py-2.5 text-sm font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg">
          {t.common.goToAuth}
        </button>
      </div>
    );
  }

  const handleVerifyCallback = async (authority?: string) => {
    if (!authority) return;
    setVerifying(authority);
    try {
      const token = await getAuthToken();
      const resp = await fetch('/api/payments/zarinpal/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ authority, statusQuery: 'OK' }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        pushToast('error', data.message || 'Verification failed.');
        return;
      }
      pushToast(
        'success',
        `${lang === 'fa' ? 'تراکنش تایید شد' : 'Server verified'} (${data.refId}) ${data.isTestMode ? '[TEST MODE]' : ''}`
      );
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Verification error');
    } finally {
      setVerifying('');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{t.nav.payments}</h1>
        <p className="text-sm text-[#9A968E] mt-1">
          {lang === 'fa'
            ? 'تاریخچه تراکنش‌ها، رسیدهای فاکتور و تایید سمت سرور درگاه'
            : 'Transaction records, server-verified receipts, and invoice history.'}
        </p>
      </div>

      <div className="bg-[#121216] border border-[#24242B] rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-[#24242B] text-xs text-[#9A968E]">
            <tr>
              <th className="text-start py-3 px-4 font-medium">{lang === 'fa' ? 'طرح' : 'Plan'}</th>
              <th className="text-end py-3 px-4 font-medium">{lang === 'fa' ? 'مبلغ' : 'Amount'}</th>
              <th className="text-start py-3 px-4 font-medium">{lang === 'fa' ? 'درگاه / کد' : 'Gateway / Authority'}</th>
              <th className="text-start py-3 px-4 font-medium">{t.common.statusLabel}</th>
              <th className="text-end py-3 px-4 font-medium">{lang === 'fa' ? 'عملیات' : 'Action'}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#24242B]">
            {payments.length === 0 ? (
              <tr>
                <td colSpan={5} className="py-8 text-center text-sm text-[#7E7B74]">
                  {t.common.empty}
                </td>
              </tr>
            ) : (
              payments.map((p) => (
                <tr key={p.id}>
                  <td className="py-3 px-4 font-medium uppercase">
                    {p.planId} ({p.billingCycle})
                  </td>
                  <td className="py-3 px-4 text-end font-mono-num text-[#E5C76B]">
                    {formatMoney(p.amount, p.currency, lang)}
                  </td>
                  <td className="py-3 px-4 text-xs font-mono-num text-[#9A968E]">
                    {p.gateway} · {p.authority || '—'} {p.isTestMode ? '(TEST)' : ''}
                  </td>
                  <td className="py-3 px-4 text-xs uppercase">{p.status}</td>
                  <td className="py-3 px-4 text-end">
                    {p.status === 'pending' && p.authority ? (
                      <button
                        type="button"
                        disabled={verifying === p.authority}
                        onClick={() => void handleVerifyCallback(p.authority)}
                        className="px-3 py-1 text-xs bg-[#D4AF37]/20 text-[#E5C76B] rounded hover:bg-[#D4AF37]/30"
                      >
                        {verifying === p.authority ? '...' : lang === 'fa' ? 'تایید استعلام' : 'Verify Callback'}
                      </button>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs text-[#9A968E]">
                        <FileText className="w-3.5 h-3.5" /> {p.refId || 'Receipt'}
                      </span>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export const AuthView: React.FC<{ onSuccessNavigate?: PageRoute }> = ({ onSuccessNavigate = 'overview' }) => {
  const { lang, user, signInGoogle, signInEmail, registerEmail, resetPassword, navigate, pushToast } = useApp();
  const [mode, setMode] = useState<'login' | 'register' | 'reset'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === 'login') {
        await signInEmail(email, password);
        navigate(onSuccessNavigate);
      } else if (mode === 'register') {
        await registerEmail(name, email, password);
        navigate(onSuccessNavigate);
      } else {
        await resetPassword(email);
        setMode('login');
      }
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setBusy(false);
    }
  };

  const handleGoogle = async () => {
    setBusy(true);
    try {
      await signInGoogle();
      navigate(onSuccessNavigate);
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Google Sign-In failed.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-md mx-auto bg-[#121216] border border-[#24242B] rounded-xl p-7 space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold text-[#E5C76B]">
          {mode === 'login'
            ? lang === 'fa'
              ? 'ورود به حساب کاربری'
              : 'Sign In to UMA Gold'
            : mode === 'register'
            ? lang === 'fa'
              ? 'ایجاد حساب جدید'
              : 'Create UMA Gold Account'
            : lang === 'fa'
            ? 'بازیابی رمز عبور'
            : 'Reset Password'}
        </h1>
        <p className="text-xs text-[#9A968E] mt-1">
          {lang === 'fa'
            ? 'ورود با گوگل تایید آنی ایمیل را فعال می‌کند.'
            : 'Google Sign-In activates verified access immediately.'}
        </p>
      </div>

      {user && (
        <div className="p-3 bg-[#101C16] border border-[#10B981]/30 rounded-lg text-xs text-[#6EE7B7]">
          {lang === 'fa' ? `وارد شده با: ${user.email}` : `Signed in as ${user.email}`}
        </div>
      )}

      <button
        type="button"
        disabled={busy}
        onClick={() => void handleGoogle()}
        className="w-full py-2.5 px-4 bg-[#F5F2EB] text-[#09090B] text-sm font-semibold rounded-lg hover:bg-white transition-colors"
      >
        {lang === 'fa' ? 'ورود سریع با حساب گوگل' : 'Continue with Google'}
      </button>

      <div className="relative flex items-center justify-center text-xs text-[#7E7B74]">
        <span className="border-t border-[#24242B] flex-1" />
        <span className="px-3">{lang === 'fa' ? 'یا با ایمیل' : 'or with email'}</span>
        <span className="border-t border-[#24242B] flex-1" />
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        {mode === 'register' && (
          <input
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={lang === 'fa' ? 'نام و نام خانوادگی / نام کارگاه' : 'Full Name / Workshop Name'}
            className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2.5 text-sm"
          />
        )}
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder={lang === 'fa' ? 'ایمیل' : 'Email address'}
          className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2.5 text-sm"
        />
        {mode !== 'reset' && (
          <input
            type="password"
            required
            minLength={6}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder={lang === 'fa' ? 'رمز عبور (حداقل ۶ کاراکتر)' : 'Password (min 6 chars)'}
            className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2.5 text-sm"
          />
        )}
        <button
          type="submit"
          disabled={busy}
          className="w-full py-2.5 bg-[#D4AF37] text-[#09090B] text-sm font-semibold rounded-lg hover:bg-[#E5C76B]"
        >
          {busy
            ? '...'
            : mode === 'login'
            ? lang === 'fa'
              ? 'ورود'
              : 'Sign In'
            : mode === 'register'
            ? lang === 'fa'
              ? 'ثبت‌نام'
              : 'Create Account'
            : lang === 'fa'
            ? 'ارسال لینک بازیابی'
            : 'Send Reset Link'}
        </button>
      </form>

      <div className="flex items-center justify-between text-xs text-[#9A968E] pt-2 border-t border-[#24242B]">
        <button type="button" onClick={() => setMode(mode === 'login' ? 'register' : 'login')} className="hover:text-[#E5C76B]">
          {mode === 'login'
            ? lang === 'fa'
              ? 'حساب ندارید؟ ثبت‌نام'
              : 'Need an account? Register'
            : lang === 'fa'
            ? 'حساب دارید؟ ورود'
            : 'Already registered? Sign In'}
        </button>
        <button type="button" onClick={() => setMode('reset')} className="hover:text-[#E5C76B]">
          {lang === 'fa' ? 'فراموشی رمز؟' : 'Forgot password?'}
        </button>
      </div>
    </div>
  );
};

export const ProfileSettingsView: React.FC = () => {
  const { lang, setLang, user, isVerified, userRole, subscriptionTier, resetPassword, pushToast, navigate } = useApp();
  const t = TRANSLATIONS[lang];

  const [workshopName, setWorkshopName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [businessType, setBusinessType] = useState<'retailer' | 'manufacturer' | 'workshop' | 'investor' | 'trader'>('workshop');
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    if (!user || !isVerified) return;
    getDoc(doc(db, 'user_profiles', user.uid))
      .then((snap) => {
        if (snap.exists()) {
          const d = snap.data();
          setWorkshopName(String(d.workshopName || ''));
          setPhone(String(d.phone || ''));
          setCity(String(d.city || ''));
          if (d.businessType) setBusinessType(d.businessType);
        }
      })
      .catch(() => {});
  }, [user, isVerified]);

  if (!user || !isVerified) {
    return (
      <div className="bg-[#121216] border border-[#24242B] rounded-xl p-8 text-center space-y-4">
        <h2 className="font-display text-2xl text-[#F5F2EB]">{t.nav.profile}</h2>
        <p className="text-sm text-[#9A968E]">{t.common.signInRequired}</p>
        <button type="button" onClick={() => navigate('auth')} className="px-5 py-2.5 text-sm font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg">
          {t.common.goToAuth}
        </button>
      </div>
    );
  }

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await setDoc(doc(db, 'user_profiles', user.uid), {
        ownerId: user.uid,
        email: user.email || '',
        phone: phone.trim(),
        workshopName: workshopName.trim(),
        city: city.trim(),
        businessType,
        updatedAt: serverTimestamp(),
      });
      await updateDoc(doc(db, 'users', user.uid), {
        language: lang,
        updatedAt: serverTimestamp(),
      });
      pushToast('success', lang === 'fa' ? 'تنظیمات پروفایل ذخیره شد.' : 'Profile & language preferences saved.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `user_profiles/${user.uid}`);
    }
  };

  const handleDeleteAccount = async () => {
    if (!auth.currentUser) return;
    try {
      await deleteDoc(doc(db, 'user_profiles', auth.currentUser.uid));
      await deleteDoc(doc(db, 'users', auth.currentUser.uid));
      await deleteUser(auth.currentUser);
      pushToast('info', lang === 'fa' ? 'حساب کاربری حذف شد.' : 'Account deleted.');
      navigate('landing');
    } catch (err) {
      pushToast('error', err instanceof Error ? err.message : 'Please re-authenticate before deleting account.');
    }
  };

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{t.nav.profile}</h1>
        <p className="text-xs text-[#9A968E] mt-1">
          {user.email} · Role: {userRole} · Plan: {subscriptionTier}
        </p>
      </div>

      <form onSubmit={handleSaveProfile} className="bg-[#121216] border border-[#24242B] rounded-xl p-6 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs text-[#9A968E] mb-1">{lang === 'fa' ? 'نام کارگاه / گالری' : 'Workshop / Store Name'}</label>
            <input type="text" value={workshopName} onChange={(e) => setWorkshopName(e.target.value)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-[#9A968E] mb-1">{lang === 'fa' ? 'شماره تماس' : 'Phone'}</label>
            <input type="text" value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num" />
          </div>
          <div>
            <label className="block text-xs text-[#9A968E] mb-1">{lang === 'fa' ? 'شهر' : 'City'}</label>
            <input type="text" value={city} onChange={(e) => setCity(e.target.value)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-[#9A968E] mb-1">{lang === 'fa' ? 'نوع فعالیت' : 'Business Role'}</label>
            <select value={businessType} onChange={(e) => setBusinessType(e.target.value as typeof businessType)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm">
              <option value="workshop">{lang === 'fa' ? 'کارگاه طلاسازی' : 'Jewelry Workshop'}</option>
              <option value="manufacturer">{lang === 'fa' ? 'تولیدکننده صنعتی' : 'Jewelry Manufacturer'}</option>
              <option value="retailer">{lang === 'fa' ? 'طلافروشی / گالری' : 'Gold Retailer'}</option>
              <option value="trader">{lang === 'fa' ? 'بنکدار / معامله‌گر' : 'Bullion Trader'}</option>
              <option value="investor">{lang === 'fa' ? 'سرمایه‌گذار' : 'Gold Investor'}</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-[#24242B]">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-[#9A968E]">{lang === 'fa' ? 'زبان:' : 'Language:'}</span>
            <button type="button" onClick={() => setLang('en')} className={`px-2.5 py-1 rounded ${lang === 'en' ? 'bg-[#D4AF37] text-[#09090B]' : 'bg-[#09090B]'}`}>English</button>
            <button type="button" onClick={() => setLang('fa')} className={`px-2.5 py-1 rounded ${lang === 'fa' ? 'bg-[#D4AF37] text-[#09090B]' : 'bg-[#09090B]'}`}>فارسی</button>
          </div>
          <button type="submit" className="px-5 py-2 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B]">
            {t.common.save}
          </button>
        </div>
      </form>

      <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <KeyRound className="w-5 h-5 text-[#D4AF37]" />
          <div className="text-xs text-[#B8B3A8]">
            {lang === 'fa' ? 'ارسال ایمیل تغییر / بازیابی رمز عبور' : 'Send password reset link to your email'}
          </div>
        </div>
        <button
          type="button"
          onClick={() => user.email && void resetPassword(user.email)}
          className="px-4 py-2 text-xs border border-[#24242B] rounded-lg hover:border-[#D4AF37]"
        >
          {lang === 'fa' ? 'ارسال لینک' : 'Send Reset Email'}
        </button>
      </div>

      {/* Account Deletion Workflow */}
      <div className="bg-[#1F1215]/50 border border-[#EF4444]/30 rounded-xl p-5 space-y-3">
        <div className="flex items-center gap-2 text-sm font-semibold text-[#FCA5A5]">
          <ShieldAlert className="w-4 h-4" />
          <span>{lang === 'fa' ? 'حذف دائمی حساب کاربری' : 'Permanent Account Deletion'}</span>
        </div>
        <p className="text-xs text-[#B8B3A8]">
          {lang === 'fa'
            ? 'این عملیات پروفایل شما را حذف می‌کند. برای تایید دکمه زیر را فشار دهید.'
            : 'Deleting your account permanently removes your profile access. Confirm below to proceed.'}
        </p>
        {!confirmDelete ? (
          <button
            type="button"
            onClick={() => setConfirmDelete(true)}
            className="px-4 py-2 text-xs border border-[#EF4444]/50 text-[#FCA5A5] rounded-lg hover:bg-[#EF4444]/10"
          >
            {lang === 'fa' ? 'درخواست حذف حساب' : 'Request Account Deletion'}
          </button>
        ) : (
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => void handleDeleteAccount()}
              className="px-4 py-2 text-xs font-semibold bg-[#EF4444] text-white rounded-lg"
            >
              {lang === 'fa' ? 'تایید نهایی حذف' : 'Confirm Permanent Deletion'}
            </button>
            <button
              type="button"
              onClick={() => setConfirmDelete(false)}
              className="px-3 py-2 text-xs text-[#9A968E]"
            >
              {t.common.cancel}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
