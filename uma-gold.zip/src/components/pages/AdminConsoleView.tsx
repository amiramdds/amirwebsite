import React, { useEffect, useState } from 'react';
import { Download, Shield, Save } from 'lucide-react';
import { addDoc, collection, doc, onSnapshot, orderBy, query, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { useApp } from '../../context/AppContext';
import { db, OperationType, handleFirestoreError } from '../../firebase';
import { DEFAULT_LEGAL_DOCS } from '../../data/demoData';
import { UserRole } from '../../types/domain';

type AdminTab = 'settings' | 'prices' | 'users' | 'support' | 'legal' | 'audit';

export const AdminConsoleView: React.FC = () => {
  const {
    lang,
    user,
    isAdmin,
    isSupportOrAdmin,
    appSettings,
    goldPrices,
    catalogModels,
    marketProviderStatus,
    pushToast,
  } = useApp();

  const [tab, setTab] = useState<AdminTab>(isAdmin ? 'settings' : 'support');
  const [lossPct, setLossPct] = useState(String(appSettings.defaultLossPct));
  const [scrapPct, setScrapPct] = useState(String(appSettings.recoverableScrapPct));
  const [proMonthlyIrr, setProMonthlyIrr] = useState(String(appSettings.proMonthlyIrr));
  const [proAnnualIrr, setProAnnualIrr] = useState(String(appSettings.proAnnualIrr));
  const [proMonthlyUsd, setProMonthlyUsd] = useState(String(appSettings.proMonthlyUsd));
  const [proAnnualUsd, setProAnnualUsd] = useState(String(appSettings.proAnnualUsd));

  const [usersList, setUsersList] = useState<Array<{ id: string; displayName: string; role: UserRole; subscriptionTier: string }>>([]);
  const [auditLogs, setAuditLogs] = useState<Array<{ id: string; actorUid: string; action: string; summary: string; createdAt: string }>>([]);
  const [allTickets, setAllTickets] = useState<Array<{ id: string; ownerId: string; subject: string; status: string }>>([]);
  const [replyTicketId, setReplyTicketId] = useState('');
  const [replyOwnerId, setReplyOwnerId] = useState('');
  const [replyBody, setReplyBody] = useState('');

  const [legalSlug, setLegalSlug] = useState<'privacy' | 'terms' | 'subscription-refund' | 'ai-disclaimer'>('ai-disclaimer');
  const [legalBodyEn, setLegalBodyEn] = useState(DEFAULT_LEGAL_DOCS['ai-disclaimer'].bodyEn);
  const [legalBodyFa, setLegalBodyFa] = useState(DEFAULT_LEGAL_DOCS['ai-disclaimer'].bodyFa);

  const [manualSym, setManualSym] = useState('IR18K');
  const [manualVal, setManualVal] = useState('46850000');
  const [manualMarket, setManualMarket] = useState<'iran' | 'international'>('iran');
  const [manualUnit, setManualUnit] = useState('IRR/g');

  useEffect(() => {
    if (!isAdmin || !user) return;
    const unsubUsers = onSnapshot(
      collection(db, 'users'),
      (snap) => {
        setUsersList(
          snap.docs.map((d) => ({
            id: d.id,
            displayName: String(d.data().displayName || d.id),
            role: (d.data().role as UserRole) || 'free',
            subscriptionTier: String(d.data().subscriptionTier || 'free'),
          }))
        );
      },
      () => {}
    );

    const unsubAudit = onSnapshot(
      query(collection(db, 'audit_logs'), orderBy('createdAt', 'desc')),
      (snap) => {
        setAuditLogs(
          snap.docs.map((d) => ({
            id: d.id,
            actorUid: String(d.data().actorUid || ''),
            action: String(d.data().action || ''),
            summary: String(d.data().summary || ''),
            createdAt: d.data().createdAt?.toDate ? d.data().createdAt.toDate().toISOString() : '',
          }))
        );
      },
      () => {}
    );

    const unsubTickets = onSnapshot(
      collection(db, 'support_tickets'),
      (snap) => {
        setAllTickets(
          snap.docs.map((d) => ({
            id: d.id,
            ownerId: String(d.data().ownerId || ''),
            subject: String(d.data().subject || ''),
            status: String(d.data().status || 'open'),
          }))
        );
      },
      () => {}
    );

    return () => {
      unsubUsers();
      unsubAudit();
      unsubTickets();
    };
  }, [isAdmin, user]);

  if (!isAdmin && !isSupportOrAdmin) {
    return (
      <div className="bg-[#1F1215] border border-[#EF4444]/40 rounded-xl p-8 text-center space-y-2">
        <Shield className="w-8 h-8 text-[#EF4444] mx-auto" />
        <h2 className="text-xl font-semibold text-[#F5F2EB]">
          {lang === 'fa' ? 'دسترسی محدود شده' : 'Administrator Authorization Required'}
        </h2>
        <p className="text-xs text-[#B8B3A8]">
          {lang === 'fa'
            ? 'این بخش صرفاً برای مدیران و پشتیبانان تاییدشده مجاز است.'
            : 'This console is restricted to verified administrators and support agents.'}
        </p>
      </div>
    );
  }

  const logAudit = async (action: string, targetCollection: string, summary: string) => {
    if (!user) return;
    await addDoc(collection(db, 'audit_logs'), {
      actorUid: user.uid,
      action,
      targetCollection,
      summary: summary.slice(0, 390),
      createdAt: serverTimestamp(),
    });
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    try {
      await setDoc(doc(db, 'application_settings', 'global'), {
        key: 'global',
        defaultLossPct: Number(lossPct) || 1.5,
        recoverableScrapPct: Number(scrapPct) || 4.0,
        proMonthlyIrr: Number(proMonthlyIrr) || 18500000,
        proAnnualIrr: Number(proAnnualIrr) || 175000000,
        proMonthlyUsd: Number(proMonthlyUsd) || 39,
        proAnnualUsd: Number(proAnnualUsd) || 390,
        demoModeEnabled: true,
        updatedAt: serverTimestamp(),
      });
      await logAudit('UPDATE_SETTINGS', 'application_settings', `Loss=${lossPct}%, Scrap=${scrapPct}%`);
      pushToast('success', lang === 'fa' ? 'تنظیمات سیستم ذخیره شد.' : 'System settings saved.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'application_settings/global');
    }
  };

  const handlePublishManualPrice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin || !user) return;
    const docId = manualSym.replace(/[^a-zA-Z0-9_-]/g, '_');
    try {
      await setDoc(doc(db, 'gold_prices', docId), {
        symbol: manualSym,
        market: manualMarket,
        unit: manualUnit,
        price: Number(manualVal) || 0,
        change24hPct: 0,
        status: 'manual',
        source: `Admin (${user.email || user.uid})`,
        updatedBy: user.uid,
        updatedAt: serverTimestamp(),
      });
      await logAudit('MANUAL_PRICE_OVERRIDE', 'gold_prices', `${manualSym} = ${manualVal} ${manualUnit}`);
      pushToast('success', lang === 'fa' ? 'نرخ دستی ثبت شد.' : 'Manual price published.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `gold_prices/${docId}`);
    }
  };

  const handleUpdateRole = async (uid: string, role: UserRole, tier: string) => {
    if (!isAdmin) return;
    try {
      await updateDoc(doc(db, 'users', uid), {
        role,
        subscriptionTier: tier,
        updatedAt: serverTimestamp(),
      });
      await logAudit('RBAC_ROLE_CHANGE', 'users', `Set ${uid} role=${role}, tier=${tier}`);
      pushToast('success', 'User role updated.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${uid}`);
    }
  };

  const handleReplyTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !replyTicketId || !replyBody.trim()) return;
    try {
      await addDoc(collection(db, 'support_messages'), {
        ownerId: replyOwnerId,
        ticketId: replyTicketId,
        senderUid: user.uid,
        senderRole: isAdmin ? 'admin' : 'support_agent',
        body: replyBody.trim(),
        createdAt: serverTimestamp(),
      });
      await updateDoc(doc(db, 'support_tickets', replyTicketId), {
        status: 'in_progress',
        updatedAt: serverTimestamp(),
      });
      setReplyBody('');
      pushToast('success', 'Support reply sent.');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'support_messages');
    }
  };

  const handleSaveLegal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    const base = DEFAULT_LEGAL_DOCS[legalSlug];
    try {
      await setDoc(doc(db, 'legal_pages', legalSlug), {
        slug: legalSlug,
        titleEn: base.titleEn,
        titleFa: base.titleFa,
        bodyEn: legalBodyEn,
        bodyFa: legalBodyFa,
        updatedAt: serverTimestamp(),
      });
      await logAudit('UPDATE_LEGAL_PAGE', 'legal_pages', `Updated ${legalSlug}`);
      pushToast('success', 'Legal page updated.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `legal_pages/${legalSlug}`);
    }
  };

  const exportBackup = () => {
    const backup = {
      exportedAt: new Date().toISOString(),
      appSettings,
      goldPrices,
      catalogModels,
      auditLogs,
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `uma-gold-admin-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold text-[#E5C76B]">
            {lang === 'fa' ? 'پنل جامع مدیریت UMA Gold' : 'UMA Gold Administration Console'}
          </h1>
          <p className="text-xs text-[#9A968E] mt-1">
            Market Adapter: {marketProviderStatus.provider} ({marketProviderStatus.status})
          </p>
        </div>
        <button
          type="button"
          onClick={exportBackup}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium border border-[#24242B] rounded-lg hover:border-[#D4AF37]"
        >
          <Download className="w-4 h-4" />
          <span>{lang === 'fa' ? 'پشتیبان‌گیری JSON' : 'Backup Export'}</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-1 p-1 bg-[#121216] border border-[#24242B] rounded-lg w-fit">
        {(
          [
            ['settings', lang === 'fa' ? 'تنظیمات و تعرفه' : 'Rules & Pricing'],
            ['prices', lang === 'fa' ? 'مدیریت نرخ‌ها' : 'Market Prices'],
            ['users', lang === 'fa' ? 'کاربران و نقش‌ها' : 'Users & RBAC'],
            ['support', lang === 'fa' ? 'میز پشتیبانی' : 'Support Desk'],
            ['legal', lang === 'fa' ? 'صفحات قانونی' : 'Legal Pages'],
            ['audit', lang === 'fa' ? 'گزارش ممیزی' : 'Audit Logs'],
          ] as [AdminTab, string][]
        ).map(([k, label]) => (
          <button
            key={k}
            type="button"
            onClick={() => setTab(k)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap ${
              tab === k ? 'bg-[#D4AF37] text-[#09090B]' : 'text-[#9A968E] hover:text-[#F5F2EB]'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === 'settings' && isAdmin && (
        <form onSubmit={handleSaveSettings} className="bg-[#121216] border border-[#24242B] rounded-xl p-6 space-y-4 max-w-2xl">
          <h3 className="text-sm font-semibold text-[#E5C76B]">
            {lang === 'fa' ? 'قوانین ساخت و تعرفه اشتراک‌ها' : 'Manufacturing Rules & Subscription Pricing'}
          </h3>
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-[#9A968E] mb-1">Default Loss (%)</label>
              <input type="number" step="0.1" value={lossPct} onChange={(e) => setLossPct(e.target.value)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 font-mono-num" />
            </div>
            <div>
              <label className="block text-[#9A968E] mb-1">Recoverable Scrap (%)</label>
              <input type="number" step="0.1" value={scrapPct} onChange={(e) => setScrapPct(e.target.value)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 font-mono-num" />
            </div>
            <div>
              <label className="block text-[#9A968E] mb-1">Pro Monthly (IRR)</label>
              <input type="number" value={proMonthlyIrr} onChange={(e) => setProMonthlyIrr(e.target.value)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 font-mono-num" />
            </div>
            <div>
              <label className="block text-[#9A968E] mb-1">Pro Annual (IRR)</label>
              <input type="number" value={proAnnualIrr} onChange={(e) => setProAnnualIrr(e.target.value)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 font-mono-num" />
            </div>
            <div>
              <label className="block text-[#9A968E] mb-1">Pro Monthly (USD)</label>
              <input type="number" value={proMonthlyUsd} onChange={(e) => setProMonthlyUsd(e.target.value)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 font-mono-num" />
            </div>
            <div>
              <label className="block text-[#9A968E] mb-1">Pro Annual (USD)</label>
              <input type="number" value={proAnnualUsd} onChange={(e) => setProAnnualUsd(e.target.value)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 font-mono-num" />
            </div>
          </div>
          <button type="submit" className="inline-flex items-center gap-2 px-5 py-2 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg">
            <Save className="w-4 h-4" /> <span>Save Settings</span>
          </button>
        </form>
      )}

      {tab === 'prices' && isAdmin && (
        <form onSubmit={handlePublishManualPrice} className="bg-[#121216] border border-[#24242B] rounded-xl p-6 space-y-4 max-w-2xl">
          <h3 className="text-sm font-semibold text-[#E5C76B]">
            {lang === 'fa' ? 'ثبت دستی قیمت طلا (با ثبت ممیزی)' : 'Manual Price Entry (Audited)'}
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <select value={manualSym} onChange={(e) => setManualSym(e.target.value)} className="bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2">
              <option value="IR18K">IR18K</option>
              <option value="IR24K">IR24K</option>
              <option value="MELTED">MELTED</option>
              <option value="MITHQAL">MITHQAL</option>
              <option value="EMAMI">EMAMI</option>
              <option value="XAU/USD">XAU/USD</option>
            </select>
            <select value={manualMarket} onChange={(e) => setManualMarket(e.target.value as 'iran' | 'international')} className="bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2">
              <option value="iran">Iran</option>
              <option value="international">International</option>
            </select>
            <input type="text" value={manualUnit} onChange={(e) => setManualUnit(e.target.value)} placeholder="Unit" className="bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2" />
            <input type="number" step="any" value={manualVal} onChange={(e) => setManualVal(e.target.value)} placeholder="Price" className="bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 font-mono-num" />
          </div>
          <button type="submit" className="px-5 py-2 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg">
            Publish Manual Rate
          </button>
        </form>
      )}

      {tab === 'users' && isAdmin && (
        <div className="bg-[#121216] border border-[#24242B] rounded-xl overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-[#24242B] text-xs text-[#9A968E]">
              <tr>
                <th className="text-start py-3 px-4">User</th>
                <th className="text-start py-3 px-4">Role</th>
                <th className="text-start py-3 px-4">Tier</th>
                <th className="text-end py-3 px-4">Update</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#24242B]">
              {usersList.map((u) => (
                <tr key={u.id}>
                  <td className="py-3 px-4 text-xs">
                    <div className="text-[#F5F2EB]">{u.displayName}</div>
                    <div className="text-[#7E7B74] font-mono-num">{u.id}</div>
                  </td>
                  <td className="py-3 px-4 text-xs">{u.role}</td>
                  <td className="py-3 px-4 text-xs uppercase">{u.subscriptionTier}</td>
                  <td className="py-3 px-4 text-end">
                    <select
                      value={u.role}
                      onChange={(e) => void handleUpdateRole(u.id, e.target.value as UserRole, u.subscriptionTier)}
                      className="bg-[#09090B] border border-[#24242B] rounded px-2 py-1 text-xs"
                    >
                      <option value="free">free</option>
                      <option value="pro">pro</option>
                      <option value="organization">organization</option>
                      <option value="support_agent">support_agent</option>
                      <option value="admin">admin</option>
                      <option value="super_admin">super_admin</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'support' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4 divide-y divide-[#24242B]">
            <h3 className="text-sm font-semibold text-[#E5C76B] pb-2">Tickets Queue</h3>
            {allTickets.map((tk) => (
              <button
                key={tk.id}
                type="button"
                onClick={() => {
                  setReplyTicketId(tk.id);
                  setReplyOwnerId(tk.ownerId);
                }}
                className="w-full text-start py-2.5 flex items-center justify-between text-xs hover:text-[#E5C76B]"
              >
                <span>{tk.subject}</span>
                <span className="text-[#9A968E]">{tk.status}</span>
              </button>
            ))}
          </div>

          <form onSubmit={handleReplyTicket} className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-3">
            <h3 className="text-sm font-semibold text-[#F5F2EB]">Reply to Ticket</h3>
            <div className="text-xs text-[#9A968E]">Selected Ticket: {replyTicketId || 'Select a ticket on the left'}</div>
            <textarea rows={4} value={replyBody} onChange={(e) => setReplyBody(e.target.value)} placeholder="Write official support reply..." className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm" />
            <button type="submit" disabled={!replyTicketId} className="px-4 py-2 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg disabled:opacity-40">
              Send Reply
            </button>
          </form>
        </div>
      )}

      {tab === 'legal' && isAdmin && (
        <form onSubmit={handleSaveLegal} className="bg-[#121216] border border-[#24242B] rounded-xl p-6 space-y-4">
          <select
            value={legalSlug}
            onChange={(e) => {
              const s = e.target.value as typeof legalSlug;
              setLegalSlug(s);
              setLegalBodyEn(DEFAULT_LEGAL_DOCS[s].bodyEn);
              setLegalBodyFa(DEFAULT_LEGAL_DOCS[s].bodyFa);
            }}
            className="bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm"
          >
            <option value="privacy">Privacy Policy</option>
            <option value="terms">Terms of Service</option>
            <option value="subscription-refund">Subscription & Refund Policy</option>
            <option value="ai-disclaimer">AI Disclaimer</option>
          </select>
          <textarea rows={6} value={legalBodyEn} onChange={(e) => setLegalBodyEn(e.target.value)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg p-3 text-xs" />
          <textarea rows={6} dir="rtl" value={legalBodyFa} onChange={(e) => setLegalBodyFa(e.target.value)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg p-3 text-xs" />
          <button type="submit" className="px-5 py-2 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg">
            Save Legal Document
          </button>
        </form>
      )}

      {tab === 'audit' && isAdmin && (
        <div className="bg-[#121216] border border-[#24242B] rounded-xl divide-y divide-[#24242B]">
          {auditLogs.length === 0 ? (
            <div className="p-6 text-center text-xs text-[#7E7B74]">No audit entries logged yet.</div>
          ) : (
            auditLogs.map((log) => (
              <div key={log.id} className="p-3.5 flex flex-wrap justify-between gap-2 text-xs">
                <div>
                  <span className="text-[#E5C76B] font-mono-num me-2">{log.action}</span>
                  <span className="text-[#D4CFC4]">{log.summary}</span>
                </div>
                <span className="text-[#7E7B74] font-mono-num">{log.createdAt}</span>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
