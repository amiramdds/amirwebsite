import React, { useMemo, useState } from 'react';
import { AlertTriangle, Bot, Plus, Trash2 } from 'lucide-react';
import { addDoc, collection, deleteDoc, doc, serverTimestamp } from 'firebase/firestore';
import { useApp } from '../../context/AppContext';
import { db, OperationType, handleFirestoreError } from '../../firebase';
import { JEWELRY_CATEGORIES } from '../../data/demoData';
import { TRANSLATIONS, formatNum } from '../../i18n/translations';
import { AIForecastResult, JewelryCategorySlug } from '../../types/domain';

export const AIPredictionsView: React.FC = () => {
  const {
    lang,
    user,
    isVerified,
    goldPrices,
    currencyPrices,
    salesRecords,
    inventory,
    getAuthToken,
    pushToast,
    navigate,
  } = useApp();
  const t = TRANSLATIONS[lang];

  const [horizon, setHorizon] = useState<'short_term' | 'medium_term'>('short_term');
  const [market, setMarket] = useState<'combined' | 'iran' | 'international'>('combined');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [forecast, setForecast] = useState<AIForecastResult | null>(null);

  const realSalesCount = salesRecords.filter((s) => !s.isDemo).length;

  const runForecast = async () => {
    if (!user || !isVerified) {
      pushToast('info', t.common.signInRequired);
      navigate('auth');
      return;
    }
    setLoading(true);
    setErrorMsg('');
    try {
      const token = await getAuthToken();
      const resp = await fetch('/api/ai/forecast', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          language: lang,
          horizon,
          market,
          goldPrices,
          currencyPrices,
          salesRecords,
          inventorySummary: inventory,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        setErrorMsg(data.message || 'Forecast generation failed.');
        return;
      }
      setForecast(data);
      // Persist forecast record under user's isolated Firestore collection
      await addDoc(collection(db, 'ai_forecasts'), {
        ownerId: user.uid,
        horizon,
        market,
        confidenceScore: Number(data.confidenceScore || 0),
        riskLevel: data.riskLevel || 'medium',
        summary: String(data.forecastOutlook || '').slice(0, 2400),
        dataSufficiency: data.dataSufficiency || 'insufficient',
        createdAt: serverTimestamp(),
      });
      pushToast('success', lang === 'fa' ? 'تحلیل هوشمند با موفقیت تولید و ذخیره شد.' : 'AI forecast generated and saved.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Network error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{t.nav.aiPredictions}</h1>
          <p className="text-sm text-[#9A968E] mt-1">
            {lang === 'fa'
              ? 'تحلیل احتمالی روند طلا و تقاضای رده‌های جواهر با تفکیک شفاف حقایق تاریخی، محاسبات و پیش‌بینی'
              : 'Probabilistic market & demand outlook separating historical facts, calculated spreads, and AI estimates.'}
          </p>
        </div>
      </div>

      {/* Data Sufficiency Notice */}
      <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-3">
          <AlertTriangle className={`w-4 h-4 shrink-0 ${realSalesCount < 5 ? 'text-[#F59E0B]' : 'text-[#10B981]'}`} />
          <span className="text-[#D4CFC4]">
            {realSalesCount < 5
              ? lang === 'fa'
                ? `تعداد سوابق فروش واقعی شما (${realSalesCount}) کمتر از ۵ مورد است؛ ضریب اطمینان پیش‌بینی به صورت خودکار محدود می‌شود.`
                : `You currently have ${realSalesCount} verified workshop sales records (<5). Forecast confidence is capped until more sales history is logged.`
              : lang === 'fa'
              ? `${realSalesCount} رکورد فروش واقعی در تحلیل لحاظ می‌شود.`
              : `${realSalesCount} verified sales records will ground this forecast.`}
          </span>
        </div>
        <button
          type="button"
          onClick={() => navigate('demand-analysis')}
          className="text-[#E5C76B] hover:underline whitespace-nowrap shrink-0"
        >
          {lang === 'fa' ? 'ثبت سوابق فروش' : 'Log Sales History'}
        </button>
      </div>

      {/* Controls */}
      <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5 flex flex-wrap items-end gap-4">
        <div>
          <label className="block text-xs text-[#9A968E] mb-1.5">
            {lang === 'fa' ? 'افق زمانی' : 'Forecast Horizon'}
          </label>
          <select
            value={horizon}
            onChange={(e) => setHorizon(e.target.value as 'short_term' | 'medium_term')}
            className="bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm text-[#F5F2EB]"
          >
            <option value="short_term">{lang === 'fa' ? 'کوتاه‌مدت (۷ تا ۱۴ روز)' : 'Short-Term (7–14 Days)'}</option>
            <option value="medium_term">{lang === 'fa' ? 'میان‌مدت (۱ تا ۳ ماه)' : 'Medium-Term (1–3 Months)'}</option>
          </select>
        </div>
        <div>
          <label className="block text-xs text-[#9A968E] mb-1.5">
            {lang === 'fa' ? 'محدوده بازار' : 'Market Scope'}
          </label>
          <select
            value={market}
            onChange={(e) => setMarket(e.target.value as 'combined' | 'iran' | 'international')}
            className="bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm text-[#F5F2EB]"
          >
            <option value="combined">{lang === 'fa' ? 'ترکیبی (ایران و جهانی)' : 'Combined (Iran & Global)'}</option>
            <option value="iran">{lang === 'fa' ? 'بازار ایران' : 'Iran Market'}</option>
            <option value="international">{lang === 'fa' ? 'انس جهانی' : 'International XAU/USD'}</option>
          </select>
        </div>
        <button
          type="button"
          disabled={loading}
          onClick={() => void runForecast()}
          className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B] disabled:opacity-50"
        >
          <Bot className="w-4 h-4" />
          <span>{loading ? t.common.loading : lang === 'fa' ? 'تولید پیش‌بینی هوشمند' : 'Generate AI Forecast'}</span>
        </button>
      </div>

      {errorMsg && (
        <div className="bg-[#1F1215] border border-[#EF4444]/40 text-[#FCA5A5] rounded-xl p-4 text-sm">
          {errorMsg}
        </div>
      )}

      {forecast && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
              <div className="text-xs text-[#9A968E]">{t.common.confidence}</div>
              <div className="text-2xl font-semibold text-[#E5C76B] font-mono-num mt-1">
                {forecast.confidenceScore}%
              </div>
              <div className="text-xs text-[#7E7B74] mt-1">
                {lang === 'fa' ? 'کفایت داده:' : 'Data Sufficiency:'} {forecast.dataSufficiency}
              </div>
            </div>
            <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
              <div className="text-xs text-[#9A968E]">{t.common.risk}</div>
              <div className="text-2xl font-semibold text-[#F5F2EB] uppercase mt-1">{forecast.riskLevel}</div>
            </div>
            <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
              <div className="text-xs text-[#9A968E]">{t.common.lastUpdated}</div>
              <div className="text-sm font-mono-num text-[#D4CFC4] mt-2">
                {new Date(forecast.generatedAt).toLocaleString(lang === 'fa' ? 'fa-IR' : 'en-US')}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-3">
              <h3 className="text-sm font-semibold text-[#10B981]">
                {lang === 'fa' ? '۱. حقایق تاریخی و داده‌های ورودی' : '1. Observed Historical Facts'}
              </h3>
              <ul className="space-y-2 text-xs text-[#D4CFC4] list-disc ps-4">
                {forecast.historicalFacts.map((item, i) => (
                  <li key={i}>{item}</li>
                ))}
              </ul>
            </div>

            <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-3">
              <h3 className="text-sm font-semibold text-[#E5C76B]">
                {lang === 'fa' ? '۲. محاسبات و شاخص‌های استخراج‌شده' : '2. Calculated Market Estimates'}
              </h3>
              <ul className="space-y-2 text-xs text-[#D4CFC4] list-disc ps-4">
                {forecast.calculatedEstimates.map((item, i) => (
                  <li key={i}>{item}</li>
                ))}
              </ul>
            </div>

            <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-3">
              <h3 className="text-sm font-semibold text-[#F59E0B]">
                {lang === 'fa' ? '۳. پیش‌بینی احتمالی هوش مصنوعی' : '3. AI-Generated Forecast'}
              </h3>
              <p className="text-xs text-[#D4CFC4] leading-relaxed">{forecast.forecastOutlook}</p>
              <div className="pt-2 border-t border-[#24242B] text-xs space-y-1">
                <div>
                  <span className="text-[#10B981]">{lang === 'fa' ? 'صعودی:' : 'Rising:'}</span>{' '}
                  {forecast.risingCategories.join(' · ') || '—'}
                </div>
                <div>
                  <span className="text-[#EF4444]">{lang === 'fa' ? 'کاهشی:' : 'Declining:'}</span>{' '}
                  {forecast.decliningCategories.join(' · ') || '—'}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4 text-xs text-[#9A968E]">
            <strong className="text-[#E5C76B]">{t.nav.legalAi}:</strong> {forecast.disclaimer}
          </div>
        </div>
      )}
    </div>
  );
};

export const DemandAnalysisView: React.FC = () => {
  const { lang, user, isVerified, salesRecords, catalogModels, pushToast, navigate } = useApp();
  const t = TRANSLATIONS[lang];

  const [categoryId, setCategoryId] = useState<JewelryCategorySlug>('rings');
  const [modelName, setModelName] = useState(catalogModels[0]?.nameEn || '');
  const [unitsSold, setUnitsSold] = useState('3');
  const [totalWeight, setTotalWeight] = useState('14.5');
  const [saleDate, setSaleDate] = useState('2026-11-21');

  const handleAddSale = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !isVerified) {
      pushToast('info', t.common.signInRequired);
      navigate('auth');
      return;
    }
    try {
      await addDoc(collection(db, 'sales_records'), {
        ownerId: user.uid,
        categoryId,
        modelName: modelName.trim(),
        unitsSold: Math.max(1, Number(unitsSold) || 1),
        totalWeightGrams: Math.max(0.1, Number(totalWeight) || 1),
        saleDate,
        isDemo: false,
        createdAt: serverTimestamp(),
      });
      pushToast('success', lang === 'fa' ? 'سابقه فروش ثبت شد.' : 'Sales record added.');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'sales_records');
    }
  };

  const handleDeleteSale = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'sales_records', id));
      pushToast('info', lang === 'fa' ? 'رکورد حذف شد.' : 'Record deleted.');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `sales_records/${id}`);
    }
  };

  const categoryAggregation = useMemo(() => {
    const map = new Map<string, { units: number; grams: number }>();
    for (const s of salesRecords) {
      const cur = map.get(s.categoryId) || { units: 0, grams: 0 };
      map.set(s.categoryId, {
        units: cur.units + s.unitsSold,
        grams: cur.grams + s.totalWeightGrams,
      });
    }
    return JEWELRY_CATEGORIES.map((c) => ({
      ...c,
      units: map.get(c.id)?.units || 0,
      grams: map.get(c.id)?.grams || 0,
    }));
  }, [salesRecords]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{t.nav.demandAnalysis}</h1>
        <p className="text-sm text-[#9A968E] mt-1">
          {lang === 'fa'
            ? 'تحلیل تقاضا بر اساس سوابق واقعی فروش کارگاه و فروشگاه شما (بدون داده‌های ساختگی)'
            : 'Jewelry category demand grounded strictly in your recorded workshop & retail sales observations.'}
        </p>
      </div>

      {/* Category Demand Distribution */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {categoryAggregation.map((cat) => (
          <div key={cat.id} className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
            <div className="text-xs text-[#9A968E]">{lang === 'fa' ? cat.nameFa : cat.nameEn}</div>
            <div className="text-lg font-semibold text-[#E5C76B] font-mono-num mt-1">
              {formatNum(cat.units, lang, 0)} {t.common.units}
            </div>
            <div className="text-xs text-[#7E7B74] font-mono-num">{formatNum(cat.grams, lang, 2)} g</div>
          </div>
        ))}
      </div>

      {/* Add Real Sales Observation */}
      <form onSubmit={handleAddSale} className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-semibold text-[#F5F2EB]">
          {lang === 'fa' ? 'ثبت سابقه فروش واقعی (جهت بهبود پیش‌بینی هوش مصنوعی)' : 'Log Actual Sales Record'}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <select
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value as JewelryCategorySlug)}
            className="bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm text-[#F5F2EB]"
          >
            {JEWELRY_CATEGORIES.map((c) => (
              <option key={c.id} value={c.id}>
                {lang === 'fa' ? c.nameFa : c.nameEn}
              </option>
            ))}
          </select>
          <input
            type="text"
            required
            value={modelName}
            onChange={(e) => setModelName(e.target.value)}
            placeholder={lang === 'fa' ? 'نام مدل' : 'Model name'}
            className="bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm text-[#F5F2EB]"
          />
          <input
            type="number"
            min="1"
            required
            value={unitsSold}
            onChange={(e) => setUnitsSold(e.target.value)}
            placeholder={t.common.units}
            className="bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num text-[#F5F2EB]"
          />
          <input
            type="number"
            step="0.1"
            min="0.1"
            required
            value={totalWeight}
            onChange={(e) => setTotalWeight(e.target.value)}
            placeholder={lang === 'fa' ? 'وزن کل (گرم)' : 'Total grams'}
            className="bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num text-[#F5F2EB]"
          />
          <div className="flex gap-2">
            <input
              type="date"
              value={saleDate}
              onChange={(e) => setSaleDate(e.target.value)}
              className="flex-1 bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num text-[#F5F2EB]"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-[#D4AF37] text-[#09090B] rounded-lg text-sm font-semibold hover:bg-[#E5C76B] shrink-0"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>
      </form>

      {/* Sales Table */}
      <div className="bg-[#121216] border border-[#24242B] rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-[#24242B] text-xs text-[#9A968E]">
            <tr>
              <th className="text-start py-3 px-4 font-medium">{lang === 'fa' ? 'تاریخ' : 'Date'}</th>
              <th className="text-start py-3 px-4 font-medium">{lang === 'fa' ? 'رده' : 'Category'}</th>
              <th className="text-start py-3 px-4 font-medium">{lang === 'fa' ? 'مدل' : 'Model'}</th>
              <th className="text-end py-3 px-4 font-medium">{t.common.units}</th>
              <th className="text-end py-3 px-4 font-medium">{t.common.grams}</th>
              <th className="text-end py-3 px-4 font-medium">{t.common.delete}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#24242B]">
            {salesRecords.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-sm text-[#7E7B74]">
                  {t.common.empty}
                </td>
              </tr>
            ) : (
              salesRecords.map((s) => (
                <tr key={s.id}>
                  <td className="py-3 px-4 font-mono-num text-xs text-[#9A968E]">{s.saleDate}</td>
                  <td className="py-3 px-4 text-xs">{s.categoryId}</td>
                  <td className="py-3 px-4 text-[#F5F2EB]">{s.modelName}</td>
                  <td className="py-3 px-4 text-end font-mono-num">{s.unitsSold}</td>
                  <td className="py-3 px-4 text-end font-mono-num text-[#E5C76B]">{s.totalWeightGrams} g</td>
                  <td className="py-3 px-4 text-end">
                    <button
                      type="button"
                      onClick={() => void handleDeleteSale(s.id)}
                      className="text-[#9A968E] hover:text-[#EF4444]"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
