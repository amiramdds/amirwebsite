import React, { useMemo, useState } from 'react';
import { Plus, Recycle, RotateCcw, Search, Edit3, Check } from 'lucide-react';
import { addDoc, collection, doc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { useApp } from '../../context/AppContext';
import { db, OperationType, handleFirestoreError } from '../../firebase';
import { JEWELRY_CATEGORIES, GENERATED_IMAGES } from '../../data/demoData';
import { TRANSLATIONS, formatNum } from '../../i18n/translations';
import { SafeImage } from '../ui/SafeImage';
import { JewelryCategorySlug, JewelryModel } from '../../types/domain';

export const InventoryManagementView: React.FC = () => {
  const {
    lang,
    user,
    isVerified,
    inventory,
    inventoryTx,
    scrapRecords,
    returnedGold,
    pushToast,
    navigate,
  } = useApp();
  const t = TRANSLATIONS[lang];

  const [meltedDelta, setMeltedDelta] = useState('50');
  const [meltedPurity, setMeltedPurity] = useState('750');
  const [meltedNote, setMeltedNote] = useState('');

  const [scrapLabel, setScrapLabel] = useState('');
  const [scrapGrams, setScrapGrams] = useState('4.5');
  const [scrapPurity, setScrapPurity] = useState('750');
  const [scrapRecovery, setScrapRecovery] = useState('96');

  const [retLabel, setRetLabel] = useState('');
  const [retGrams, setRetGrams] = useState('8.2');
  const [retPurity, setRetPurity] = useState('750');
  const [retCond, setRetCond] = useState<'reusable' | 'remelt_required' | 'stone_removal'>('reusable');

  if (!user || !isVerified) {
    return (
      <div className="bg-[#121216] border border-[#24242B] rounded-xl p-8 text-center space-y-4">
        <h2 className="font-display text-2xl text-[#F5F2EB]">{t.nav.inventory}</h2>
        <p className="text-sm text-[#9A968E]">{t.common.signInRequired}</p>
        <button
          type="button"
          onClick={() => navigate('auth')}
          className="px-5 py-2.5 text-sm font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg"
        >
          {t.common.goToAuth}
        </button>
      </div>
    );
  }

  const adjustMeltedStock = async (mode: 'add' | 'consume') => {
    const grams = Math.max(0.01, Number(meltedDelta) || 0);
    const purity = Math.min(Math.max(Number(meltedPurity) || 750, 100), 999.9);
    const current = inventory?.meltedGoldGrams || 0;
    const nextMelted = mode === 'add' ? current + grams : Math.max(0, current - grams);

    try {
      await setDoc(doc(db, 'inventory', user.uid), {
        ownerId: user.uid,
        meltedGoldGrams: Number(nextMelted.toFixed(3)),
        meltedPurityPerMille: purity,
        scrapGoldGrams: inventory?.scrapGoldGrams || 0,
        returnedGoldGrams: inventory?.returnedGoldGrams || 0,
        updatedAt: serverTimestamp(),
      });
      await addDoc(collection(db, 'inventory_transactions'), {
        ownerId: user.uid,
        txType: mode === 'add' ? 'melted_add' : 'melted_consume',
        grossGrams: grams,
        purityPerMille: purity,
        fineGoldGrams: Number(((mode === 'add' ? 1 : -1) * grams * (purity / 1000)).toFixed(3)),
        note: meltedNote || (mode === 'add' ? 'Melted gold deposit' : 'Workshop consumption'),
        createdAt: serverTimestamp(),
      });
      setMeltedNote('');
      pushToast('success', lang === 'fa' ? 'موجودی با ثبت تراکنش بروزرسانی شد.' : 'Inventory updated and logged.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `inventory/${user.uid}`);
    }
  };

  const handleAddScrap = async (e: React.FormEvent) => {
    e.preventDefault();
    const grams = Math.max(0.01, Number(scrapGrams) || 0);
    const purity = Math.min(Math.max(Number(scrapPurity) || 750, 100), 999.9);
    const recovery = Math.min(Math.max(Number(scrapRecovery) || 95, 0), 100);
    try {
      await addDoc(collection(db, 'scrap_records'), {
        ownerId: user.uid,
        sourceLabel: scrapLabel.trim() || 'Workshop Filing Scrap',
        grossGrams: grams,
        purityPerMille: purity,
        estimatedRecoveryPct: recovery,
        status: 'stored',
        createdAt: serverTimestamp(),
      });
      await setDoc(doc(db, 'inventory', user.uid), {
        ownerId: user.uid,
        meltedGoldGrams: inventory?.meltedGoldGrams || 0,
        meltedPurityPerMille: inventory?.meltedPurityPerMille || 750,
        scrapGoldGrams: Number(((inventory?.scrapGoldGrams || 0) + grams).toFixed(3)),
        returnedGoldGrams: inventory?.returnedGoldGrams || 0,
        updatedAt: serverTimestamp(),
      });
      await addDoc(collection(db, 'inventory_transactions'), {
        ownerId: user.uid,
        txType: 'scrap_add',
        grossGrams: grams,
        purityPerMille: purity,
        fineGoldGrams: Number((grams * (purity / 1000) * (recovery / 100)).toFixed(3)),
        note: scrapLabel.trim() || 'Scrap logged',
        createdAt: serverTimestamp(),
      });
      setScrapLabel('');
      pushToast('success', lang === 'fa' ? 'ضایعات ثبت شد.' : 'Scrap record logged.');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'scrap_records');
    }
  };

  const handleRecoverScrap = async (id: string, grams: number, purity: number, recoveryPct: number) => {
    const recovered = Number((grams * (recoveryPct / 100)).toFixed(3));
    try {
      await updateDoc(doc(db, 'scrap_records', id), { status: 'reused' });
      await setDoc(doc(db, 'inventory', user.uid), {
        ownerId: user.uid,
        meltedGoldGrams: Number(((inventory?.meltedGoldGrams || 0) + recovered).toFixed(3)),
        meltedPurityPerMille: inventory?.meltedPurityPerMille || purity,
        scrapGoldGrams: Math.max(0, Number(((inventory?.scrapGoldGrams || 0) - grams).toFixed(3))),
        returnedGoldGrams: inventory?.returnedGoldGrams || 0,
        updatedAt: serverTimestamp(),
      });
      await addDoc(collection(db, 'inventory_transactions'), {
        ownerId: user.uid,
        txType: 'scrap_recover',
        grossGrams: recovered,
        purityPerMille: purity,
        fineGoldGrams: Number((recovered * (purity / 1000)).toFixed(3)),
        note: `Scrap refined & returned to melted stock (${recoveryPct}%)`,
        createdAt: serverTimestamp(),
      });
      pushToast('success', lang === 'fa' ? 'ضایعات به موجودی آب‌شده بازگشت.' : 'Scrap recovered into melted stock.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `scrap_records/${id}`);
    }
  };

  const handleAddReturned = async (e: React.FormEvent) => {
    e.preventDefault();
    const grams = Math.max(0.01, Number(retGrams) || 0);
    const purity = Math.min(Math.max(Number(retPurity) || 750, 100), 999.9);
    try {
      await addDoc(collection(db, 'returned_gold'), {
        ownerId: user.uid,
        itemLabel: retLabel.trim() || 'Returned Jewelry Piece',
        grossGrams: grams,
        purityPerMille: purity,
        condition: retCond,
        createdAt: serverTimestamp(),
      });
      await setDoc(doc(db, 'inventory', user.uid), {
        ownerId: user.uid,
        meltedGoldGrams: inventory?.meltedGoldGrams || 0,
        meltedPurityPerMille: inventory?.meltedPurityPerMille || 750,
        scrapGoldGrams: inventory?.scrapGoldGrams || 0,
        returnedGoldGrams: Number(((inventory?.returnedGoldGrams || 0) + grams).toFixed(3)),
        updatedAt: serverTimestamp(),
      });
      await addDoc(collection(db, 'inventory_transactions'), {
        ownerId: user.uid,
        txType: 'returned_add',
        grossGrams: grams,
        purityPerMille: purity,
        fineGoldGrams: Number((grams * (purity / 1000)).toFixed(3)),
        note: `Returned gold (${retCond}): ${retLabel.trim()}`,
        createdAt: serverTimestamp(),
      });
      setRetLabel('');
      pushToast('success', lang === 'fa' ? 'طلای مرجوعی ثبت شد.' : 'Returned gold logged.');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'returned_gold');
    }
  };

  const totalFineInventory =
    ((inventory?.meltedGoldGrams || 0) * (inventory?.meltedPurityPerMille || 750)) / 1000;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{t.nav.inventory}</h1>
        <p className="text-sm text-[#9A968E] mt-1">
          {lang === 'fa'
            ? 'مدیریت طلای آب‌شده، ثبت ضایعات و طلای مرجوعی با دفتر کل قابل ردیابی'
            : 'Traceable melted stock, recoverable workshop scrap, returned gold, and full reconciliation ledger.'}
        </p>
      </div>

      {/* Balances */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'طلای آب‌شده' : 'Melted Gold Stock'}</div>
          <div className="text-2xl font-semibold text-[#E5C76B] font-mono-num mt-1">
            {formatNum(inventory?.meltedGoldGrams || 0, lang)} g
          </div>
          <div className="text-xs text-[#7E7B74] font-mono-num">
            {lang === 'fa' ? 'عیار:' : 'Purity:'} {inventory?.meltedPurityPerMille || 750}
          </div>
        </div>
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'معادل ۲۴ عیار خالص' : 'Fine Gold Equivalent'}</div>
          <div className="text-2xl font-semibold text-[#F5F2EB] font-mono-num mt-1">
            {formatNum(totalFineInventory, lang)} g
          </div>
        </div>
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'ضایعات ذخیره' : 'Stored Scrap Gold'}</div>
          <div className="text-2xl font-semibold text-[#10B981] font-mono-num mt-1">
            {formatNum(inventory?.scrapGoldGrams || 0, lang)} g
          </div>
        </div>
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'طلای مرجوعی' : 'Returned Gold'}</div>
          <div className="text-2xl font-semibold text-[#F5F2EB] font-mono-num mt-1">
            {formatNum(inventory?.returnedGoldGrams || 0, lang)} g
          </div>
        </div>
      </div>

      {/* Forms Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Melted Adjustment */}
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-semibold text-[#E5C76B]">
            {lang === 'fa' ? 'تغییر موجودی آب‌شده' : 'Adjust Melted Stock'}
          </h3>
          <input
            type="number"
            step="0.1"
            value={meltedDelta}
            onChange={(e) => setMeltedDelta(e.target.value)}
            placeholder="Grams"
            className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num"
          />
          <input
            type="number"
            step="0.1"
            value={meltedPurity}
            onChange={(e) => setMeltedPurity(e.target.value)}
            placeholder="Purity (e.g. 750)"
            className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num"
          />
          <input
            type="text"
            value={meltedNote}
            onChange={(e) => setMeltedNote(e.target.value)}
            placeholder={lang === 'fa' ? 'توضیحات / شماره شمش' : 'Note / Bar reference'}
            className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm"
          />
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => void adjustMeltedStock('add')}
              className="flex-1 py-2 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B]"
            >
              {lang === 'fa' ? '+ افزایش' : '+ Add Stock'}
            </button>
            <button
              type="button"
              onClick={() => void adjustMeltedStock('consume')}
              className="flex-1 py-2 text-xs font-medium border border-[#24242B] text-[#F5F2EB] rounded-lg hover:border-[#EF4444]"
            >
              {lang === 'fa' ? '− مصرف' : '− Consume'}
            </button>
          </div>
        </div>

        {/* Scrap Registration */}
        <form onSubmit={handleAddScrap} className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-semibold text-[#10B981] flex items-center gap-2">
            <Recycle className="w-4 h-4" />
            <span>{lang === 'fa' ? 'ثبت ضایعات قابل بازیافت' : 'Log Recoverable Scrap'}</span>
          </h3>
          <input
            type="text"
            required
            value={scrapLabel}
            onChange={(e) => setScrapLabel(e.target.value)}
            placeholder={lang === 'fa' ? 'منبع (مثلاً سوهان‌کاری میز ۱)' : 'Source (e.g. Bench 1 Filings)'}
            className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm"
          />
          <div className="grid grid-cols-3 gap-2">
            <input type="number" step="0.1" value={scrapGrams} onChange={(e) => setScrapGrams(e.target.value)} placeholder="g" className="bg-[#09090B] border border-[#24242B] rounded-lg px-2 py-2 text-xs font-mono-num" />
            <input type="number" step="0.1" value={scrapPurity} onChange={(e) => setScrapPurity(e.target.value)} placeholder="750" className="bg-[#09090B] border border-[#24242B] rounded-lg px-2 py-2 text-xs font-mono-num" />
            <input type="number" step="1" value={scrapRecovery} onChange={(e) => setScrapRecovery(e.target.value)} placeholder="96%" className="bg-[#09090B] border border-[#24242B] rounded-lg px-2 py-2 text-xs font-mono-num" />
          </div>
          <button
            type="submit"
            className="w-full py-2 text-xs font-semibold bg-[#10B981]/20 border border-[#10B981]/50 text-[#6EE7B7] rounded-lg hover:bg-[#10B981]/30"
          >
            {lang === 'fa' ? 'ثبت ضایعات' : 'Register Scrap'}
          </button>
        </form>

        {/* Returned Gold */}
        <form onSubmit={handleAddReturned} className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-semibold text-[#F5F2EB] flex items-center gap-2">
            <RotateCcw className="w-4 h-4 text-[#D4AF37]" />
            <span>{lang === 'fa' ? 'ثبت طلای مرجوعی' : 'Register Returned Gold'}</span>
          </h3>
          <input
            type="text"
            required
            value={retLabel}
            onChange={(e) => setRetLabel(e.target.value)}
            placeholder={lang === 'fa' ? 'شرح قطعه مرجوعی' : 'Returned item description'}
            className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm"
          />
          <div className="grid grid-cols-2 gap-2">
            <input type="number" step="0.1" value={retGrams} onChange={(e) => setRetGrams(e.target.value)} placeholder="Grams" className="bg-[#09090B] border border-[#24242B] rounded-lg px-2 py-2 text-xs font-mono-num" />
            <input type="number" step="0.1" value={retPurity} onChange={(e) => setRetPurity(e.target.value)} placeholder="Purity" className="bg-[#09090B] border border-[#24242B] rounded-lg px-2 py-2 text-xs font-mono-num" />
          </div>
          <select value={retCond} onChange={(e) => setRetCond(e.target.value as 'reusable' | 'remelt_required' | 'stone_removal')} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-xs">
            <option value="reusable">{lang === 'fa' ? 'قابل فروش مجدد' : 'Reusable'}</option>
            <option value="remelt_required">{lang === 'fa' ? 'نیازمند ذوب مجدد' : 'Remelt Required'}</option>
            <option value="stone_removal">{lang === 'fa' ? 'نیازمند مخرج‌کاری / جدا کردن نگین' : 'Stone Removal'}</option>
          </select>
          <button
            type="submit"
            className="w-full py-2 text-xs font-semibold border border-[#D4AF37]/60 text-[#E5C76B] rounded-lg hover:bg-[#D4AF37]/10"
          >
            {lang === 'fa' ? 'ثبت مرجوعی' : 'Register Returned Gold'}
          </button>
        </form>
      </div>

      {/* Scrap & Returned Active Lists */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-semibold text-[#F5F2EB]">{lang === 'fa' ? 'سوابق ضایعات' : 'Scrap Recovery Queue'}</h3>
          {scrapRecords.length === 0 ? (
            <p className="text-xs text-[#7E7B74]">{t.common.empty}</p>
          ) : (
            <div className="divide-y divide-[#24242B]">
              {scrapRecords.map((s) => (
                <div key={s.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                  <div>
                    <div className="text-[#F5F2EB] font-medium">{s.sourceLabel}</div>
                    <div className="text-[#7E7B74] font-mono-num">
                      {s.grossGrams}g · {s.purityPerMille} · Est. {s.estimatedRecoveryPct}% · {s.status}
                    </div>
                  </div>
                  {s.status === 'stored' && (
                    <button
                      type="button"
                      onClick={() => void handleRecoverScrap(s.id, s.grossGrams, s.purityPerMille, s.estimatedRecoveryPct)}
                      className="px-2.5 py-1 bg-[#10B981]/15 text-[#6EE7B7] rounded hover:bg-[#10B981]/25 shrink-0"
                    >
                      {lang === 'fa' ? 'بازیافت به آب‌شده' : 'Recover to Stock'}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-semibold text-[#F5F2EB]">{lang === 'fa' ? 'دفتر کل تراکنش‌های موجودی' : 'Traceable Reconciliation Ledger'}</h3>
          {inventoryTx.length === 0 ? (
            <p className="text-xs text-[#7E7B74]">{t.common.empty}</p>
          ) : (
            <div className="divide-y divide-[#24242B] max-h-72 overflow-y-auto">
              {inventoryTx.map((tx) => (
                <div key={tx.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                  <div>
                    <div className="text-[#F5F2EB]">{tx.note}</div>
                    <div className="text-[#7E7B74] font-mono-num">{tx.txType} · {new Date(tx.createdAt).toLocaleString()}</div>
                  </div>
                  <div className="text-end font-mono-num">
                    <div className="text-[#E5C76B]">{tx.grossGrams}g</div>
                    <div className="text-[#7E7B74]">{tx.fineGoldGrams}g Au</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {returnedGold.length > 0 && (
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5">
          <h3 className="text-sm font-semibold text-[#F5F2EB] mb-3">{lang === 'fa' ? 'طلای مرجوعی ثبت‌شده' : 'Returned Gold Log'}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
            {returnedGold.map((r) => (
              <div key={r.id} className="p-3 bg-[#18181D] border border-[#24242B] rounded-lg flex justify-between">
                <div>
                  <div className="text-[#F5F2EB] font-medium">{r.itemLabel}</div>
                  <div className="text-[#7E7B74]">{r.condition}</div>
                </div>
                <div className="font-mono-num text-[#E5C76B]">{r.grossGrams}g ({r.purityPerMille})</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export const JewelryCatalogView: React.FC = () => {
  const { lang, catalogModels, isAdmin, pushToast } = useApp();
  const t = TRANSLATIONS[lang];
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'demand' | 'weight' | 'labor'>('demand');
  const [showAddModal, setShowAddModal] = useState(false);

  const [newNameEn, setNewNameEn] = useState('');
  const [newNameFa, setNewNameFa] = useState('');
  const [newCat, setNewCat] = useState<JewelryCategorySlug>('rings');
  const [newMinW, setNewMinW] = useState('3');
  const [newMaxW, setNewMaxW] = useState('6');
  const [newLabor, setNewLabor] = useState('12');

  const filtered = useMemo(() => {
    return catalogModels
      .filter((m) => {
        if (catFilter !== 'all' && m.categoryId !== catFilter) return false;
        if (!search.trim()) return true;
        const q = search.toLowerCase();
        return m.nameEn.toLowerCase().includes(q) || m.nameFa.includes(search);
      })
      .sort((a, b) => {
        if (sortBy === 'demand') return b.demandIndex - a.demandIndex;
        if (sortBy === 'weight') return a.minWeightGrams - b.minWeightGrams;
        return a.laborFeePct - b.laborFeePct;
      });
  }, [catalogModels, catFilter, search, sortBy]);

  const handleCreateModel = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    try {
      await addDoc(collection(db, 'jewelry_models'), {
        nameEn: newNameEn.trim(),
        nameFa: newNameFa.trim(),
        categoryId: newCat,
        descriptionEn: 'Registered workshop production model.',
        descriptionFa: 'مدل ثبت‌شده در کاتالوگ کارگاه.',
        imageUrl: GENERATED_IMAGES.ring,
        minWeightGrams: Number(newMinW) || 2,
        maxWeightGrams: Number(newMaxW) || 5,
        purityKarat: 18,
        laborFeePct: Number(newLabor) || 12,
        additionalCostPerUnit: 2000000,
        productionHours: 4,
        demandIndex: 80,
        isActive: true,
        updatedAt: serverTimestamp(),
      });
      setShowAddModal(false);
      setNewNameEn('');
      setNewNameFa('');
      pushToast('success', lang === 'fa' ? 'مدل جدید به کاتالوگ اضافه شد.' : 'Jewelry model created.');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'jewelry_models');
    }
  };

  const toggleActive = async (m: JewelryModel) => {
    if (!isAdmin || m.isDemo) return;
    try {
      await updateDoc(doc(db, 'jewelry_models', m.id), {
        isActive: !m.isActive,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `jewelry_models/${m.id}`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{t.nav.catalog}</h1>
          <p className="text-sm text-[#9A968E] mt-1">
            {lang === 'fa'
              ? 'کاتالوگ ۸ رده جواهرات متصل به موتور هوش مصنوعی برنامه‌ریز تولید'
              : 'Registered 8-category jewelry catalog powering AI production recommendations.'}
          </p>
        </div>
        {isAdmin && (
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B]"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'fa' ? 'افزودن مدل جدید' : 'Add Catalog Model'}</span>
          </button>
        )}
      </div>

      {/* Filters & Search */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-[#7E7B74] absolute start-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t.common.search}
            className="w-full bg-[#121216] border border-[#24242B] rounded-lg ps-9 pe-3 py-2 text-sm"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={catFilter}
            onChange={(e) => setCatFilter(e.target.value)}
            className="bg-[#121216] border border-[#24242B] rounded-lg px-3 py-2 text-xs"
          >
            <option value="all">{t.common.all}</option>
            {JEWELRY_CATEGORIES.map((c) => (
              <option key={c.id} value={c.id}>
                {lang === 'fa' ? c.nameFa : c.nameEn}
              </option>
            ))}
          </select>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'demand' | 'weight' | 'labor')}
            className="bg-[#121216] border border-[#24242B] rounded-lg px-3 py-2 text-xs"
          >
            <option value="demand">{lang === 'fa' ? 'مرتب‌سازی: تقاضا' : 'Sort: Demand Index'}</option>
            <option value="weight">{lang === 'fa' ? 'مرتب‌سازی: وزن' : 'Sort: Min Weight'}</option>
            <option value="labor">{lang === 'fa' ? 'مرتب‌سازی: اجرت' : 'Sort: Labor %'}</option>
          </select>
        </div>
      </div>

      {/* Catalog Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {filtered.map((m) => {
          const cat = JEWELRY_CATEGORIES.find((c) => c.id === m.categoryId);
          return (
            <div key={m.id} className="bg-[#121216] border border-[#24242B] rounded-xl overflow-hidden flex flex-col">
              <div className="aspect-[4/3] bg-[#18181D]">
                <SafeImage src={m.imageUrl} alt={lang === 'fa' ? m.nameFa : m.nameEn} className="w-full h-full object-cover" />
              </div>
              <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                <div className="space-y-1">
                  <div className="text-xs text-[#9A968E]">
                    {lang === 'fa' ? cat?.nameFa : cat?.nameEn} · {m.purityKarat}K · {m.demandIndex}%
                  </div>
                  <h3 className="text-sm font-semibold text-[#F5F2EB]">
                    {lang === 'fa' ? m.nameFa : m.nameEn}
                  </h3>
                  <p className="text-xs text-[#9A968E] line-clamp-2">
                    {lang === 'fa' ? m.descriptionFa : m.descriptionEn}
                  </p>
                </div>
                <div className="pt-2 border-t border-[#24242B] flex items-center justify-between text-xs font-mono-num">
                  <span className="text-[#E5C76B]">
                    {m.minWeightGrams}–{m.maxWeightGrams}g
                  </span>
                  <span className="text-[#9A968E]">
                    {m.laborFeePct}% · {m.productionHours}h
                  </span>
                  {isAdmin && !m.isDemo && (
                    <button
                      type="button"
                      onClick={() => void toggleActive(m)}
                      className="text-[#D4AF37] hover:underline"
                    >
                      {m.isActive ? <Check className="w-3.5 h-3.5" /> : <Edit3 className="w-3.5 h-3.5" />}
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <form onSubmit={handleCreateModel} className="bg-[#121216] border border-[#24242B] rounded-xl p-6 max-w-md w-full space-y-3">
            <h3 className="text-base font-semibold text-[#E5C76B]">
              {lang === 'fa' ? 'افزودن مدل جدید به کاتالوگ' : 'Add Jewelry Model'}
            </h3>
            <input type="text" required value={newNameEn} onChange={(e) => setNewNameEn(e.target.value)} placeholder="Name (English)" className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm" />
            <input type="text" required value={newNameFa} onChange={(e) => setNewNameFa(e.target.value)} placeholder="نام مدل (فارسی)" className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm" />
            <select value={newCat} onChange={(e) => setNewCat(e.target.value as JewelryCategorySlug)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm">
              {JEWELRY_CATEGORIES.map((c) => (
                <option key={c.id} value={c.id}>{lang === 'fa' ? c.nameFa : c.nameEn}</option>
              ))}
            </select>
            <div className="grid grid-cols-3 gap-2">
              <input type="number" step="0.1" value={newMinW} onChange={(e) => setNewMinW(e.target.value)} placeholder="Min g" className="bg-[#09090B] border border-[#24242B] rounded-lg px-2 py-2 text-xs font-mono-num" />
              <input type="number" step="0.1" value={newMaxW} onChange={(e) => setNewMaxW(e.target.value)} placeholder="Max g" className="bg-[#09090B] border border-[#24242B] rounded-lg px-2 py-2 text-xs font-mono-num" />
              <input type="number" step="0.5" value={newLabor} onChange={(e) => setNewLabor(e.target.value)} placeholder="Labor %" className="bg-[#09090B] border border-[#24242B] rounded-lg px-2 py-2 text-xs font-mono-num" />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 text-xs border border-[#24242B] rounded-lg">{t.common.cancel}</button>
              <button type="submit" className="px-4 py-2 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg">{t.common.save}</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
