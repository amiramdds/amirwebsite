import React from 'react';
import { ArrowRight, ArrowLeft } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { GENERATED_IMAGES, JEWELRY_CATEGORIES } from '../../data/demoData';
import { TRANSLATIONS, formatNum } from '../../i18n/translations';
import { SafeImage } from '../ui/SafeImage';

export const LandingPage: React.FC = () => {
  const { lang, setLang, navigate, catalogModels, goldPrices, demoMode } = useApp();
  const t = TRANSLATIONS[lang];
  const ArrowIcon = lang === 'fa' ? ArrowLeft : ArrowRight;

  const spot18k = goldPrices.find((g) => g.symbol === 'IR18K');
  const xauUsd = goldPrices.find((g) => g.symbol === 'XAU/USD');

  return (
    <div className="min-h-screen bg-[#09090B] text-[#F5F2EB]">
      {/* Top Bar Contract: 3 exact zones separated by gap-8 */}
      <header className="border-b border-[#24242B] bg-[#09090B]/95 backdrop-blur sticky top-0 z-30">
        <div className="max-w-[1240px] mx-auto px-6 h-16 flex items-center justify-between gap-8">
          <button
            type="button"
            onClick={() => navigate('landing')}
            className="font-display text-2xl font-semibold tracking-tight text-[#E5C76B] whitespace-nowrap shrink-0"
          >
            {t.brand}
          </button>

          <nav className="hidden md:flex items-center gap-7 text-sm text-[#B8B3A8]">
            <button
              type="button"
              onClick={() => navigate('overview')}
              className="hover:text-[#E5C76B] transition-colors whitespace-nowrap shrink-0"
            >
              {t.nav.markets}
            </button>
            <button
              type="button"
              onClick={() => navigate('ai-predictions')}
              className="hover:text-[#E5C76B] transition-colors whitespace-nowrap shrink-0"
            >
              {t.nav.intelligence}
            </button>
            <button
              type="button"
              onClick={() => navigate('production-planner')}
              className="hover:text-[#E5C76B] transition-colors whitespace-nowrap shrink-0"
            >
              {t.nav.planner}
            </button>
            <button
              type="button"
              onClick={() => navigate('pricing')}
              className="hover:text-[#E5C76B] transition-colors whitespace-nowrap shrink-0"
            >
              {t.nav.pricing}
            </button>
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => navigate('overview')}
              className="px-4 py-2 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B] transition-colors whitespace-nowrap shrink-0"
            >
              {t.nav.launchWorkspace}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Split */}
      <section className="max-w-[1240px] mx-auto px-6 pt-10 pb-12">
        {/* Language & Mode Bar below header */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-8 text-xs text-[#9A968E]">
          <span>
            {t.tagline} · {demoMode ? t.demoBanner.title : t.demoBanner.liveApiActive}
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setLang(lang === 'en' ? 'fa' : 'en')}
              className="px-3 py-1 border border-[#24242B] rounded-md text-[#E5C76B] hover:border-[#D4AF37] transition-colors whitespace-nowrap shrink-0"
            >
              {lang === 'en' ? 'تغییر به فارسی (RTL)' : 'Switch to English (LTR)'}
            </button>
            <button
              type="button"
              onClick={() => navigate('auth')}
              className="px-3 py-1 border border-[#24242B] rounded-md text-[#D4CFC4] hover:border-[#D4AF37] transition-colors whitespace-nowrap shrink-0"
            >
              {t.nav.signIn}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-center space-y-6">
            <p className="text-xs font-medium tracking-wider text-[#D4AF37] uppercase">
              {t.landing.eyebrow}
            </p>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-[54px] font-semibold leading-[1.12] text-[#F5F2EB] text-balance">
              {t.landing.heroTitle}
            </h1>
            <p className="text-base text-[#B8B3A8] leading-relaxed max-w-xl">
              {t.landing.heroSubtitle}
            </p>
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                type="button"
                onClick={() => navigate('overview')}
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B] transition-colors whitespace-nowrap shrink-0"
              >
                <span>{t.landing.primaryCta}</span>
                <ArrowIcon className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => navigate('production-planner')}
                className="px-5 py-3 text-sm font-medium border border-[#2C2C35] text-[#F5F2EB] rounded-lg hover:border-[#D4AF37] transition-colors whitespace-nowrap shrink-0"
              >
                {t.landing.secondaryCta}
              </button>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="h-full min-h-[300px] lg:min-h-[420px] rounded-xl overflow-hidden border border-[#24242B] bg-[#121216] relative">
              <SafeImage
                src={GENERATED_IMAGES.heroAtelier}
                alt={t.brand}
                className="w-full h-full lg:h-full object-cover"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent p-5 flex items-end justify-between gap-4">
                <div>
                  <div className="text-xs text-[#D4AF37]">
                    {spot18k ? (lang === 'fa' ? spot18k.labelFa : spot18k.labelEn) : '18K Reference'}
                  </div>
                  <div className="text-lg font-semibold font-mono-num text-[#F5F2EB]">
                    {spot18k ? `${formatNum(spot18k.price, lang, 0)} ${spot18k.unit}` : '—'}
                  </div>
                </div>
                <div className="text-end">
                  <div className="text-xs text-[#9A968E]">XAU/USD</div>
                  <div className="text-lg font-semibold font-mono-num text-[#E5C76B]">
                    {xauUsd ? `$${formatNum(xauUsd.price, lang, 2)}` : '—'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Full-width 4-column benchmark strip below Hero split */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-10 pt-8 border-t border-[#24242B]">
          {[
            { label: t.landing.stat1Label, val: t.landing.stat1Val },
            { label: t.landing.stat2Label, val: t.landing.stat2Val },
            { label: t.landing.stat3Label, val: t.landing.stat3Val },
            { label: t.landing.stat4Label, val: t.landing.stat4Val },
          ].map((stat) => (
            <div key={stat.label} className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
              <div className="text-xs text-[#9A968E]">{stat.label}</div>
              <div className="text-xl font-semibold text-[#E5C76B] font-mono-num mt-1">{stat.val}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Capabilities Section */}
      <section className="max-w-[1240px] mx-auto px-6 py-14 border-t border-[#24242B]">
        <h2 className="font-display text-3xl font-semibold text-[#F5F2EB] mb-8 text-balance">
          {t.landing.capTitle}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { title: t.landing.cap1Title, desc: t.landing.cap1Desc, target: 'iran-market' as const },
            { title: t.landing.cap2Title, desc: t.landing.cap2Desc, target: 'production-planner' as const },
            { title: t.landing.cap3Title, desc: t.landing.cap3Desc, target: 'calculator' as const },
          ].map((cap) => (
            <div
              key={cap.title}
              className="bg-[#121216] border border-[#24242B] rounded-xl p-6 flex flex-col justify-between gap-6 hover:border-[#D4AF37]/50 transition-colors"
            >
              <div className="space-y-3">
                <h3 className="text-lg font-semibold text-[#E5C76B]">{cap.title}</h3>
                <p className="text-sm text-[#B8B3A8] leading-relaxed">{cap.desc}</p>
              </div>
              <button
                type="button"
                onClick={() => navigate(cap.target)}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-[#E5C76B] hover:underline w-fit"
              >
                <span>{lang === 'fa' ? 'باز کردن ابزار' : 'Open Module'}</span>
                <ArrowIcon className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Catalog Spotlight (4 items) */}
      <section className="max-w-[1240px] mx-auto px-6 py-14 border-t border-[#24242B]">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <h2 className="font-display text-3xl font-semibold text-[#F5F2EB]">
            {t.landing.catalogSpotlight}
          </h2>
          <button
            type="button"
            onClick={() => navigate('catalog')}
            className="text-xs font-medium text-[#E5C76B] hover:underline whitespace-nowrap shrink-0"
          >
            {lang === 'fa' ? 'مشاهده کامل کاتالوگ (۸ رده)' : 'View Full Catalog (8 Categories)'}
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {catalogModels.slice(0, 4).map((m) => {
            const cat = JEWELRY_CATEGORIES.find((c) => c.id === m.categoryId);
            return (
              <div
                key={m.id}
                onClick={() => navigate('catalog')}
                className="bg-[#121216] border border-[#24242B] rounded-xl overflow-hidden cursor-pointer hover:border-[#D4AF37]/60 transition-colors"
              >
                <div className="aspect-[4/3] bg-[#18181D] overflow-hidden">
                  <SafeImage
                    src={m.imageUrl}
                    alt={lang === 'fa' ? m.nameFa : m.nameEn}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4 space-y-1.5">
                  <div className="text-xs text-[#9A968E]">
                    {lang === 'fa' ? cat?.nameFa : cat?.nameEn} · {m.purityKarat}K
                  </div>
                  <h3 className="text-sm font-semibold text-[#F5F2EB] truncate">
                    {lang === 'fa' ? m.nameFa : m.nameEn}
                  </h3>
                  <div className="text-xs text-[#D4AF37] font-mono-num">
                    {m.minWeightGrams}–{m.maxWeightGrams} {t.common.grams} · {m.laborFeePct}% {lang === 'fa' ? 'اجرت' : 'labor'}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* CTA & Quiet Footer */}
      <section className="max-w-[1240px] mx-auto px-6 py-14 border-t border-[#24242B]">
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#F5F2EB]">
              {t.landing.ctaBandTitle}
            </h2>
            <p className="text-sm text-[#B8B3A8]">{t.landing.ctaBandDesc}</p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => navigate('auth')}
              className="px-5 py-2.5 text-sm font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B] transition-colors whitespace-nowrap shrink-0"
            >
              {t.nav.signIn}
            </button>
            <button
              type="button"
              onClick={() => navigate('pricing')}
              className="px-5 py-2.5 text-sm font-medium border border-[#2C2C35] text-[#F5F2EB] rounded-lg hover:border-[#D4AF37] transition-colors whitespace-nowrap shrink-0"
            >
              {t.nav.pricing}
            </button>
          </div>
        </div>
      </section>

      <footer className="border-t border-[#24242B] bg-[#0B0B0E]">
        <div className="max-w-[1240px] mx-auto px-6 py-10 grid grid-cols-1 md:grid-cols-4 gap-8 text-xs text-[#9A968E]">
          <div className="space-y-2">
            <div className="font-display text-xl text-[#E5C76B]">{t.brand}</div>
            <p>{t.tagline}</p>
            <p className="text-[#7E7B74]">Owner: amiruma · amirhossinbasirpor@gmail.com</p>
          </div>
          <div className="space-y-2">
            <div className="text-[#F5F2EB] font-medium">{t.nav.markets}</div>
            <div className="flex flex-col gap-1.5 items-start">
              <button type="button" onClick={() => navigate('overview')} className="hover:text-[#E5C76B]">{t.nav.overview}</button>
              <button type="button" onClick={() => navigate('prices')} className="hover:text-[#E5C76B]">{t.nav.prices}</button>
              <button type="button" onClick={() => navigate('iran-market')} className="hover:text-[#E5C76B]">{t.nav.iranMarket}</button>
              <button type="button" onClick={() => navigate('intl-market')} className="hover:text-[#E5C76B]">{t.nav.intlMarket}</button>
            </div>
          </div>
          <div className="space-y-2">
            <div className="text-[#F5F2EB] font-medium">{t.nav.planner}</div>
            <div className="flex flex-col gap-1.5 items-start">
              <button type="button" onClick={() => navigate('production-planner')} className="hover:text-[#E5C76B]">{t.nav.productionPlanner}</button>
              <button type="button" onClick={() => navigate('calculator')} className="hover:text-[#E5C76B]">{t.nav.calculator}</button>
              <button type="button" onClick={() => navigate('inventory')} className="hover:text-[#E5C76B]">{t.nav.inventory}</button>
              <button type="button" onClick={() => navigate('support-center')} className="hover:text-[#E5C76B]">{t.nav.supportCenter}</button>
            </div>
          </div>
          <div className="space-y-2">
            <div className="text-[#F5F2EB] font-medium">{lang === 'fa' ? 'قوانین و اسناد' : 'Legal & Trust'}</div>
            <div className="flex flex-col gap-1.5 items-start">
              <button type="button" onClick={() => navigate('legal-privacy')} className="hover:text-[#E5C76B]">{t.nav.legalPrivacy}</button>
              <button type="button" onClick={() => navigate('legal-terms')} className="hover:text-[#E5C76B]">{t.nav.legalTerms}</button>
              <button type="button" onClick={() => navigate('legal-refund')} className="hover:text-[#E5C76B]">{t.nav.legalRefund}</button>
              <button type="button" onClick={() => navigate('legal-ai')} className="hover:text-[#E5C76B]">{t.nav.legalAi}</button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
