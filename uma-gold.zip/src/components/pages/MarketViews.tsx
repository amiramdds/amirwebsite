import React, { useMemo, useState } from 'react';
import { RefreshCw, Search, ArrowUpRight, ArrowDownRight, Edit3 } from 'lucide-react';
import { doc, serverTimestamp, setDoc, addDoc, collection } from 'firebase/firestore';
import { useApp } from '../../context/AppContext';
import { db, OperationType, handleFirestoreError } from '../../firebase';
import { JEWELRY_CATEGORIES } from '../../data/demoData';
import { TRANSLATIONS, formatNum } from '../../i18n/translations';
import { calculateIranGoldParity } from '../../utils/goldMath';
import { LuxuryAreaChart } from '../ui/LuxuryChart';
import { GoldPriceItem, PriceStatus } from '../../types/domain';

function StatusLabel({ status, lang }: { status: PriceStatus; lang: 'en' | 'fa' }) {
  const t = TRANSLATIONS[lang].status;
  const color =
    status === 'live'
      ? 'text-[#10B981]'
      : status === 'manual'
      ? 'text-[#E5C76B]'
      : status === 'delayed'
      ? 'text-[#F59E0B]'
      : 'text-[#EF4444]';
  return <span className={`text-xs font-medium ${color}`}>{t[status]}</span>;
}

export const OverviewDashboard: React.FC = () => {
  const {
    lang,
    navigate,
    goldPrices,
    currencyPrices,
    marketHistory,
    inventory,
    catalogModels,
    subscriptionTier,
    user,
    refreshMarketSnapshot,
  } = useApp();
  const t = TRANSLATIONS[lang];
  const [chartSymbol, setChartSymbol] = useState<'IR18K' | 'XAU/USD'>('IR18K');

  const chartPoints = useMemo(
    () =>
      marketHistory
        .filter((h) => h.symbol === chartSymbol)
        .map((h) => ({ label: h.dateLabel, value: h.price })),
    [marketHistory, chartSymbol]
  );

  const featuredGold = goldPrices.slice(0, 4);
  const usdIrr = currencyPrices.find((c) => c.pair === 'USD/IRR');
  const topModels = [...catalogModels].sort((a, b) => b.demandIndex - a.demandIndex).slice(0, 4);

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{t.nav.overview}</h1>
          <p className="text-sm text-[#9A968E] mt-1">
            {lang === 'fa'
              ? 'نمای یکپارچه قیمت طلا، ارز، موجودی کارگاه و فرصت‌های تولید'
              : 'Unified view of gold benchmarks, FX rates, workshop inventory, and production opportunities.'}
          </p>
        </div>
        <button
          type="button"
          onClick={() => void refreshMarketSnapshot()}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium bg-[#121216] border border-[#24242B] rounded-lg hover:border-[#D4AF37] text-[#E5C76B] whitespace-nowrap shrink-0"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>{t.common.refresh}</span>
        </button>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4">
        {featuredGold.map((item) => (
          <div key={item.id} className="bg-[#121216] border border-[#24242B] rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between gap-2 text-xs text-[#9A968E]">
              <span className="truncate">{lang === 'fa' ? item.labelFa : item.labelEn}</span>
              <StatusLabel status={item.status} lang={lang} />
            </div>
            <div className="text-xl font-semibold text-[#F5F2EB] font-mono-num">
              {formatNum(item.price, lang, item.price < 5000 ? 2 : 0)}{' '}
              <span className="text-xs text-[#7E7B74]">{item.unit}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className={item.change24hPct >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}>
                {item.change24hPct >= 0 ? '+' : ''}
                {item.change24hPct}%
              </span>
              <span className="text-[#7E7B74] truncate">{item.source}</span>
            </div>
          </div>
        ))}

        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between gap-2 text-xs text-[#9A968E]">
            <span>{usdIrr ? (lang === 'fa' ? usdIrr.labelFa : usdIrr.labelEn) : 'USD/IRR'}</span>
            {usdIrr && <StatusLabel status={usdIrr.status} lang={lang} />}
          </div>
          <div className="text-xl font-semibold text-[#E5C76B] font-mono-num">
            {usdIrr ? formatNum(usdIrr.rate, lang, 0) : '—'}
          </div>
          <div className="text-xs text-[#7E7B74] truncate">
            {lang === 'fa' ? 'اشتراک:' : 'Plan:'} <strong className="text-[#D4CFC4] uppercase">{subscriptionTier}</strong>
          </div>
        </div>
      </div>

      {/* Main Chart + Inventory & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 space-y-3">
          <div className="flex items-center gap-2">
            {(['IR18K', 'XAU/USD'] as const).map((sym) => (
              <button
                key={sym}
                type="button"
                onClick={() => setChartSymbol(sym)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                  chartSymbol === sym
                    ? 'bg-[#D4AF37] text-[#09090B] border-[#D4AF37]'
                    : 'bg-[#121216] text-[#B8B3A8] border-[#24242B] hover:border-[#D4AF37]/50'
                }`}
              >
                {sym}
              </button>
            ))}
          </div>
          <LuxuryAreaChart
            title={chartSymbol === 'IR18K' ? (lang === 'fa' ? 'روند طلای ۱۸ عیار ایران' : 'Iran 18K Gold Trend') : 'XAU/USD Spot Trend'}
            subtitle={lang === 'fa' ? 'سری تاریخی ۱۴ روزه (منبع ثبت‌شده)' : '14-period historical trajectory'}
            points={chartPoints}
            unit={chartSymbol === 'IR18K' ? 'IRR' : 'USD'}
            lang={lang}
          />
        </div>

        <div className="lg:col-span-4 space-y-4">
          <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-[#F5F2EB]">
                {lang === 'fa' ? 'موجودی طلای کارگاه' : 'Workshop Gold Inventory'}
              </h3>
              <button
                type="button"
                onClick={() => navigate('inventory')}
                className="text-xs text-[#E5C76B] hover:underline"
              >
                {lang === 'fa' ? 'مدیریت' : 'Manage'}
              </button>
            </div>
            {user && inventory ? (
              <div className="space-y-3 text-sm">
                <div className="flex justify-between py-1.5 border-b border-[#24242B]">
                  <span className="text-[#9A968E]">{lang === 'fa' ? 'طلای آب‌شده' : 'Melted Stock'}</span>
                  <span className="font-mono-num text-[#E5C76B]">
                    {formatNum(inventory.meltedGoldGrams, lang)} g ({inventory.meltedPurityPerMille})
                  </span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-[#24242B]">
                  <span className="text-[#9A968E]">{lang === 'fa' ? 'ضایعات قابل بازیافت' : 'Recoverable Scrap'}</span>
                  <span className="font-mono-num text-[#F5F2EB]">{formatNum(inventory.scrapGoldGrams, lang)} g</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-[#9A968E]">{lang === 'fa' ? 'طلای مرجوعی' : 'Returned Gold'}</span>
                  <span className="font-mono-num text-[#F5F2EB]">{formatNum(inventory.returnedGoldGrams, lang)} g</span>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-xs text-[#9A968E]">
                  {lang === 'fa'
                    ? 'برای مشاهده موجودی خصوصی طلای آب‌شده و ضایعات وارد شوید.'
                    : 'Sign in to access your private melted gold, scrap, and returned inventory.'}
                </p>
                <button
                  type="button"
                  onClick={() => navigate('auth')}
                  className="w-full py-2 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B]"
                >
                  {t.common.goToAuth}
                </button>
              </div>
            )}
          </div>

          <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-3">
            <h3 className="text-sm font-semibold text-[#F5F2EB]">
              {lang === 'fa' ? 'فرصت‌های تولید پیشنهادی' : 'Production Opportunities'}
            </h3>
            <div className="space-y-2.5">
              {topModels.map((m) => (
                <div key={m.id} className="flex items-center justify-between gap-3 text-xs py-1.5 border-b border-[#24242B] last:border-0">
                  <span className="text-[#D4CFC4] truncate">{lang === 'fa' ? m.nameFa : m.nameEn}</span>
                  <span className="text-[#E5C76B] font-mono-num shrink-0">{m.demandIndex}%</span>
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={() => navigate('production-planner')}
              className="w-full py-2 text-xs font-semibold border border-[#D4AF37]/60 text-[#E5C76B] rounded-lg hover:bg-[#D4AF37]/10 transition-colors"
            >
              {t.nav.productionPlanner}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export const PricesDirectoryView: React.FC = () => {
  const { lang, goldPrices, currencyPrices, isAdmin, user, pushToast, refreshMarketSnapshot } = useApp();
  const t = TRANSLATIONS[lang];
  const [search, setSearch] = useState('');
  const [marketFilter, setMarketFilter] = useState<'all' | 'iran' | 'international'>('all');
  const [editingPrice, setEditingPrice] = useState<GoldPriceItem | null>(null);
  const [manualValue, setManualValue] = useState('');

  const filteredGold = useMemo(
    () =>
      goldPrices.filter((g) => {
        if (marketFilter !== 'all' && g.market !== marketFilter) return false;
        if (!search.trim()) return true;
        const q = search.toLowerCase();
        return (
          g.symbol.toLowerCase().includes(q) ||
          g.labelEn.toLowerCase().includes(q) ||
          g.labelFa.includes(search)
        );
      }),
    [goldPrices, marketFilter, search]
  );

  const handleSaveManualPrice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPrice || !isAdmin || !user) return;
    const numeric = Number(manualValue);
    if (!Number.isFinite(numeric) || numeric <= 0) return;

    const docId = editingPrice.symbol.replace(/[^a-zA-Z0-9_-]/g, '_');
    try {
      await setDoc(doc(db, 'gold_prices', docId), {
        symbol: editingPrice.symbol,
        market: editingPrice.market,
        unit: editingPrice.unit,
        price: numeric,
        change24hPct: editingPrice.change24hPct,
        status: 'manual',
        source: `Manual Admin (${user.email || user.uid})`,
        updatedBy: user.uid,
        updatedAt: serverTimestamp(),
      });
      await addDoc(collection(db, 'audit_logs'), {
        actorUid: user.uid,
        action: 'MANUAL_PRICE_UPDATE',
        targetCollection: 'gold_prices',
        summary: `Updated ${editingPrice.symbol} to ${numeric} ${editingPrice.unit}`,
        createdAt: serverTimestamp(),
      });
      pushToast('success', lang === 'fa' ? 'قیمت دستی ثبت و ممیزی شد.' : 'Manual price recorded and audited.');
      setEditingPrice(null);
      setManualValue('');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `gold_prices/${docId}`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{t.nav.prices}</h1>
          <p className="text-sm text-[#9A968E] mt-1">
            {lang === 'fa'
              ? 'نرخ طلای ایران، انس جهانی و ارزها با شفافیت کامل منبع و زمان بروزرسانی'
              : 'Iranian gold, global XAU/USD, and FX rates with explicit source attribution and update timestamps.'}
          </p>
        </div>
        <button
          type="button"
          onClick={() => void refreshMarketSnapshot()}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium bg-[#121216] border border-[#24242B] rounded-lg hover:border-[#D4AF37] text-[#E5C76B]"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>{t.common.refresh}</span>
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-[#7E7B74] absolute start-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t.common.search}
            className="w-full bg-[#121216] border border-[#24242B] rounded-lg ps-9 pe-3 py-2 text-sm text-[#F5F2EB] focus:outline-none focus:border-[#D4AF37]"
          />
        </div>
        <div className="flex items-center gap-1 p-1 bg-[#121216] border border-[#24242B] rounded-lg">
          {(['all', 'iran', 'international'] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setMarketFilter(m)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                marketFilter === m ? 'bg-[#D4AF37] text-[#09090B]' : 'text-[#9A968E] hover:text-[#F5F2EB]'
              }`}
            >
              {m === 'all'
                ? t.common.all
                : m === 'iran'
                ? lang === 'fa'
                  ? 'بازار ایران'
                  : 'Iran Market'
                : lang === 'fa'
                ? 'بازار جهانی'
                : 'International'}
            </button>
          ))}
        </div>
      </div>

      {/* Gold Table */}
      <div className="bg-[#121216] border border-[#24242B] rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-[#24242B] text-xs text-[#9A968E]">
            <tr>
              <th className="text-start py-3.5 px-4 font-medium">{lang === 'fa' ? 'نماد / ابزار' : 'Instrument'}</th>
              <th className="text-end py-3.5 px-4 font-medium">{lang === 'fa' ? 'نرخ' : 'Price'}</th>
              <th className="text-end py-3.5 px-4 font-medium">{lang === 'fa' ? 'تغییر ۲۴س' : '24h Change'}</th>
              <th className="text-start py-3.5 px-4 font-medium">{t.common.statusLabel}</th>
              <th className="text-start py-3.5 px-4 font-medium">{t.common.source}</th>
              {isAdmin && <th className="text-end py-3.5 px-4 font-medium">{t.common.edit}</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-[#24242B]">
            {filteredGold.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-sm text-[#7E7B74]">
                  {lang === 'fa'
                    ? 'هیچ نرخ زنده یا دمو فعال نیست. حالت دمو را فعال کنید یا از پنل مدیریت قیمت ثبت نمایید.'
                    : 'No live or demo rates active. Enable Demo Feed or enter manual prices as Administrator.'}
                </td>
              </tr>
            ) : (
              filteredGold.map((item) => (
                <tr key={item.id} className="hover:bg-[#18181D]/60">
                  <td className="py-3.5 px-4">
                    <div className="font-medium text-[#F5F2EB]">{lang === 'fa' ? item.labelFa : item.labelEn}</div>
                    <div className="text-xs text-[#7E7B74] font-mono-num">{item.symbol}</div>
                  </td>
                  <td className="py-3.5 px-4 text-end font-mono-num text-[#E5C76B]">
                    {formatNum(item.price, lang, item.price < 5000 ? 2 : 0)} {item.unit}
                  </td>
                  <td className="py-3.5 px-4 text-end font-mono-num">
                    <span className={`inline-flex items-center gap-0.5 ${item.change24hPct >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                      {item.change24hPct >= 0 ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                      {item.change24hPct}%
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <StatusLabel status={item.status} lang={lang} />
                  </td>
                  <td className="py-3.5 px-4 text-xs text-[#9A968E]">
                    <div>{item.source}</div>
                    <div className="text-[11px] text-[#7E7B74] font-mono-num">
                      {new Date(item.updatedAt).toLocaleString(lang === 'fa' ? 'fa-IR' : 'en-US')}
                    </div>
                  </td>
                  {isAdmin && (
                    <td className="py-3.5 px-4 text-end">
                      <button
                        type="button"
                        onClick={() => {
                          setEditingPrice(item);
                          setManualValue(String(item.price));
                        }}
                        className="p-1.5 text-[#9A968E] hover:text-[#E5C76B]"
                        title={t.common.edit}
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Currencies Table */}
      <div className="bg-[#121216] border border-[#24242B] rounded-xl overflow-x-auto">
        <div className="px-4 py-3 border-b border-[#24242B] text-sm font-semibold text-[#F5F2EB]">
          {lang === 'fa' ? 'نرخ ارزهای مرجع' : 'Currency Exchange Benchmarks'}
        </div>
        <table className="w-full text-sm">
          <thead className="border-b border-[#24242B] text-xs text-[#9A968E]">
            <tr>
              <th className="text-start py-3 px-4 font-medium">{lang === 'fa' ? 'جفت ارز' : 'Pair'}</th>
              <th className="text-end py-3 px-4 font-medium">{lang === 'fa' ? 'نرخ' : 'Rate'}</th>
              <th className="text-start py-3 px-4 font-medium">{t.common.statusLabel}</th>
              <th className="text-start py-3 px-4 font-medium">{t.common.source}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#24242B]">
            {currencyPrices.map((c) => (
              <tr key={c.id} className="hover:bg-[#18181D]/60">
                <td className="py-3 px-4 font-medium text-[#F5F2EB]">
                  {lang === 'fa' ? c.labelFa : c.labelEn} <span className="text-xs text-[#7E7B74] font-mono-num">({c.pair})</span>
                </td>
                <td className="py-3 px-4 text-end font-mono-num text-[#E5C76B]">
                  {formatNum(c.rate, lang, c.rate < 10 ? 4 : 0)}
                </td>
                <td className="py-3 px-4">
                  <StatusLabel status={c.status} lang={lang} />
                </td>
                <td className="py-3 px-4 text-xs text-[#9A968E]">{c.source}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Admin Manual Price Override Modal */}
      {editingPrice && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveManualPrice}
            className="bg-[#121216] border border-[#24242B] rounded-xl p-6 max-w-md w-full space-y-4"
          >
            <h3 className="text-base font-semibold text-[#E5C76B]">
              {lang === 'fa' ? 'ثبت دستی قیمت (ممیزی‌شده)' : 'Manual Admin Price Update'} — {editingPrice.symbol}
            </h3>
            <div>
              <label className="block text-xs text-[#9A968E] mb-1.5">
                {lang === 'fa' ? 'قیمت جدید' : 'New Price'} ({editingPrice.unit})
              </label>
              <input
                type="number"
                step="any"
                required
                value={manualValue}
                onChange={(e) => setManualValue(e.target.value)}
                className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm text-[#F5F2EB] font-mono-num"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingPrice(null)}
                className="px-4 py-2 text-xs text-[#9A968E] border border-[#24242B] rounded-lg"
              >
                {t.common.cancel}
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B]"
              >
                {t.common.save}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export const IranMarketAnalyticsView: React.FC = () => {
  const { lang, goldPrices, currencyPrices, marketHistory } = useApp();

  const default18k = goldPrices.find((g) => g.symbol === 'IR18K')?.price || 46850000;
  const defaultCoin = goldPrices.find((g) => g.symbol === 'EMAMI')?.price || 534000000;
  const defaultXau = goldPrices.find((g) => g.symbol === 'XAU/USD')?.price || 2684.5;
  const defaultUsd = currencyPrices.find((c) => c.pair === 'USD/IRR')?.rate || 712000;

  const [xauUsd, setXauUsd] = useState(defaultXau);
  const [usdIrr, setUsdIrr] = useState(defaultUsd);
  const [market18kIrr, setMarket18kIrr] = useState(default18k);
  const [marketCoinIrr, setMarketCoinIrr] = useState(defaultCoin);

  const parity = useMemo(
    () =>
      calculateIranGoldParity({
        xauUsd,
        usdIrr,
        market18kIrr,
        marketEmamiCoinIrr: marketCoinIrr,
      }),
    [xauUsd, usdIrr, market18kIrr, marketCoinIrr]
  );

  const history18k = marketHistory.filter((h) => h.symbol === 'IR18K').map((h) => ({ label: h.dateLabel, value: h.price }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">
          {lang === 'fa' ? 'تحلیل تخصصی بازار طلای ایران و حباب سکه' : 'Iranian Gold Market & Coin Bubble Analytics'}
        </h1>
        <p className="text-sm text-[#9A968E] mt-1">
          {lang === 'fa'
            ? 'محاسبه ارزش ذاتی طلای ۱۸ عیار، مثقال آب‌شده و حباب سکه امامی بر اساس انس جهانی و نرخ دلار'
            : 'Real-time intrinsic parity for 18K gram, Mithqal, and Emami coin premium (Habab) derived from XAU/USD and USD/IRR.'}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'ارزش ذاتی گرم ۱۸ عیار' : 'Intrinsic 18K Parity'}</div>
          <div className="text-xl font-semibold text-[#F5F2EB] font-mono-num mt-1">
            {formatNum(parity.intrinsic18kPerGramIrr, lang, 0)} IRR
          </div>
          <div className="text-xs text-[#D4AF37] font-mono-num mt-1">
            {lang === 'fa' ? 'حباب:' : 'Spread:'} {parity.gold18kBubblePct}%
          </div>
        </div>
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'ارزش ذاتی مثقال (۷۰۵)' : 'Intrinsic Mithqal'}</div>
          <div className="text-xl font-semibold text-[#F5F2EB] font-mono-num mt-1">
            {formatNum(parity.intrinsicMithqal17kIrr, lang, 0)} IRR
          </div>
        </div>
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'ارزش ذاتی سکه امامی' : 'Intrinsic Emami Coin'}</div>
          <div className="text-xl font-semibold text-[#F5F2EB] font-mono-num mt-1">
            {formatNum(parity.intrinsicEmamiIrr, lang, 0)} IRR
          </div>
        </div>
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'حباب سکه امامی' : 'Emami Coin Bubble (Habab)'}</div>
          <div className="text-xl font-semibold text-[#E5C76B] font-mono-num mt-1">
            {formatNum(parity.coinBubbleIrr, lang, 0)} IRR
          </div>
          <div className={`text-xs font-mono-num mt-1 ${parity.coinBubblePct > 15 ? 'text-[#F59E0B]' : 'text-[#10B981]'}`}>
            {parity.coinBubblePct}% {lang === 'fa' ? 'فاصله با ذاتی' : 'premium'}
          </div>
        </div>
      </div>

      {/* Interactive Sensitivity Inputs */}
      <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div>
          <label className="block text-xs text-[#9A968E] mb-1">XAU/USD ($)</label>
          <input
            type="number"
            step="0.1"
            value={xauUsd}
            onChange={(e) => setXauUsd(Number(e.target.value) || 0)}
            className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num text-[#F5F2EB]"
          />
        </div>
        <div>
          <label className="block text-xs text-[#9A968E] mb-1">USD/IRR</label>
          <input
            type="number"
            step="1000"
            value={usdIrr}
            onChange={(e) => setUsdIrr(Number(e.target.value) || 0)}
            className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num text-[#F5F2EB]"
          />
        </div>
        <div>
          <label className="block text-xs text-[#9A968E] mb-1">{lang === 'fa' ? 'قیمت بازار ۱۸ عیار' : 'Market 18K (IRR)'}</label>
          <input
            type="number"
            step="50000"
            value={market18kIrr}
            onChange={(e) => setMarket18kIrr(Number(e.target.value) || 0)}
            className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num text-[#F5F2EB]"
          />
        </div>
        <div>
          <label className="block text-xs text-[#9A968E] mb-1">{lang === 'fa' ? 'قیمت بازار سکه امامی' : 'Market Emami Coin (IRR)'}</label>
          <input
            type="number"
            step="500000"
            value={marketCoinIrr}
            onChange={(e) => setMarketCoinIrr(Number(e.target.value) || 0)}
            className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num text-[#F5F2EB]"
          />
        </div>
      </div>

      <LuxuryAreaChart
        title={lang === 'fa' ? 'نمودار تاریخی طلای ۱۸ عیار' : '18K Gold Historical Trajectory'}
        points={history18k}
        unit="IRR"
        lang={lang}
      />
    </div>
  );
};

export const IntlMarketAnalyticsView: React.FC = () => {
  const { lang, goldPrices, currencyPrices, marketHistory } = useApp();
  const xau = goldPrices.find((g) => g.symbol === 'XAU/USD')?.price || 2684.5;
  const eurUsd = currencyPrices.find((c) => c.pair === 'EUR/USD')?.rate || 1.0652;

  const gram24Usd = xau / 31.1034768;
  const gram18Usd = gram24Usd * 0.75;
  const xauEur = eurUsd > 0 ? xau / eurUsd : 0;

  const historyXau = marketHistory.filter((h) => h.symbol === 'XAU/USD').map((h) => ({ label: h.dateLabel, value: h.price }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">
          {lang === 'fa' ? 'تحلیل بازار جهانی طلا (XAU/USD)' : 'International Gold Market Analytics (XAU/USD)'}
        </h1>
        <p className="text-sm text-[#9A968E] mt-1">
          {lang === 'fa'
            ? 'نرخ جهانی اونس، معادل گرمی ۲۴ و ۱۸ عیار دلاری و برابری یورو'
            : 'Spot troy ounce benchmark, per-gram international 24K/18K parity, and EUR/USD cross valuation.'}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">XAU/USD (Troy Oz)</div>
          <div className="text-2xl font-semibold text-[#E5C76B] font-mono-num mt-1">${formatNum(xau, lang, 2)}</div>
        </div>
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">XAU/EUR (Troy Oz)</div>
          <div className="text-2xl font-semibold text-[#F5F2EB] font-mono-num mt-1">€{formatNum(xauEur, lang, 2)}</div>
        </div>
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'گرم ۲۴ عیار دلاری' : '24K Gram (USD)'}</div>
          <div className="text-2xl font-semibold text-[#F5F2EB] font-mono-num mt-1">${formatNum(gram24Usd, lang, 2)}</div>
        </div>
        <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
          <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'گرم ۱۸ عیار دلاری' : '18K Gram (USD)'}</div>
          <div className="text-2xl font-semibold text-[#F5F2EB] font-mono-num mt-1">${formatNum(gram18Usd, lang, 2)}</div>
        </div>
      </div>

      <LuxuryAreaChart
        title="XAU/USD Spot Historical Chart"
        points={historyXau}
        unit="USD"
        lang={lang}
      />

      <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5">
        <h3 className="text-sm font-semibold text-[#F5F2EB] mb-3">
          {lang === 'fa' ? 'شاخص‌های محبوب دسته‌بندی جواهر' : 'Category Liquidity Snapshot'}
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          {JEWELRY_CATEGORIES.map((c) => (
            <div key={c.id} className="p-3 rounded-lg bg-[#18181D] border border-[#24242B] text-[#D4CFC4]">
              {lang === 'fa' ? c.nameFa : c.nameEn}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
