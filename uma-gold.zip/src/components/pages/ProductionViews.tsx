import React, { useMemo, useState } from 'react';
import { BookmarkCheck, Calculator, Sparkles, AlertCircle } from 'lucide-react';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { useApp } from '../../context/AppContext';
import { db, OperationType, handleFirestoreError } from '../../firebase';
import { JEWELRY_CATEGORIES } from '../../data/demoData';
import { TRANSLATIONS, formatNum } from '../../i18n/translations';
import { calculateProductionEconomics } from '../../utils/goldMath';
import { JewelryCategorySlug, ProductionPlanScenario } from '../../types/domain';

export const ProductionPlannerView: React.FC = () => {
  const {
    lang,
    user,
    isVerified,
    inventory,
    goldPrices,
    catalogModels,
    appSettings,
    getAuthToken,
    pushToast,
    navigate,
  } = useApp();
  const t = TRANSLATIONS[lang];

  const default18k = goldPrices.find((g) => g.symbol === 'IR18K')?.price || 46850000;

  const [availableMeltedGrams, setAvailableMeltedGrams] = useState(
    inventory?.meltedGoldGrams && inventory.meltedGoldGrams > 0 ? String(inventory.meltedGoldGrams) : '120'
  );
  const [meltedPurity, setMeltedPurity] = useState(
    inventory?.meltedPurityPerMille ? String(inventory.meltedPurityPerMille) : '750'
  );
  const [budget, setBudget] = useState('350000000');
  const [targetKarat, setTargetKarat] = useState<18 | 21 | 24>(18);
  const [riskPreference, setRiskPreference] = useState<'low' | 'medium' | 'high'>('medium');
  const [profitObjective, setProfitObjective] = useState<'balanced' | 'turnover' | 'margin'>('balanced');
  const [maxUnits, setMaxUnits] = useState('40');
  const [selectedCategories, setSelectedCategories] = useState<JewelryCategorySlug[]>([
    'rings',
    'bangles',
    'chains',
    'bracelets',
  ]);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [plans, setPlans] = useState<ProductionPlanScenario[]>([]);
  const [selectedPlanIdx, setSelectedPlanIdx] = useState(0);

  const toggleCategory = (slug: JewelryCategorySlug) => {
    setSelectedCategories((prev) =>
      prev.includes(slug) ? prev.filter((c) => c !== slug) : [...prev, slug]
    );
  };

  const handleGeneratePlans = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !isVerified) {
      pushToast('info', t.common.signInRequired);
      navigate('auth');
      return;
    }

    setLoading(true);
    setErrorMsg('');
    try {
      const token = await getAuthToken();
      const activeModels = catalogModels.filter(
        (m) => m.isActive && (selectedCategories.length === 0 || selectedCategories.includes(m.categoryId))
      );
      const resp = await fetch('/api/ai/production-plan', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          language: lang,
          availableMeltedGrams: Number(availableMeltedGrams),
          meltedPurity: Number(meltedPurity),
          budget: Number(budget),
          targetPurityKarat: targetKarat,
          riskPreference,
          profitObjective,
          preferredCategories: selectedCategories,
          maxUnitsConstraint: Number(maxUnits) || 40,
          lossRatePct: appSettings.defaultLossPct,
          recoverableScrapPct: appSettings.recoverableScrapPct,
          gold18kPricePerGram: default18k,
          catalogModels: activeModels.length > 0 ? activeModels : catalogModels.filter((m) => m.isActive),
        }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        setErrorMsg(data.message || 'Unable to generate production plan.');
        return;
      }
      setPlans(data.plans || []);
      setSelectedPlanIdx(0);
      pushToast(
        'success',
        lang === 'fa' ? 'سه سناریوی تولید منطبق با موجودی شما محاسبه شد.' : '3 resource-verified production plans generated.'
      );
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Network error');
    } finally {
      setLoading(false);
    }
  };

  const handleSavePlan = async (plan: ProductionPlanScenario) => {
    if (!user || !isVerified) return;
    try {
      await addDoc(collection(db, 'production_plans'), {
        ownerId: user.uid,
        title: plan.planName.slice(0, 140),
        availableMeltedGrams: Number(availableMeltedGrams),
        meltedPurity: Number(meltedPurity),
        budget: Number(budget),
        totalGoldUsedGrams: plan.totals.totalGoldRequiredGrams,
        estimatedProfit: plan.totals.estimatedProfit,
        riskLevel: plan.riskLevel,
        summary: plan.explanation.slice(0, 1900),
        createdAt: serverTimestamp(),
      });
      pushToast('success', lang === 'fa' ? 'برنامه تولید در میز کار شما ذخیره شد.' : 'Production plan saved to your workspace.');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'production_plans');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{t.nav.productionPlanner}</h1>
          <p className="text-sm text-[#9A968E] mt-1">
            {lang === 'fa'
              ? 'تبدیل هوشمند طلای آب‌شده و بودجه کارگاه به سبد تولید بهینه با رعایت قطعی سقف موجودی و نرخ پرت'
              : 'Optimize melted gold, purity, and workshop budget into comparable production plans strictly capped by available resources.'}
          </p>
        </div>
        {inventory && inventory.meltedGoldGrams > 0 && (
          <button
            type="button"
            onClick={() => {
              setAvailableMeltedGrams(String(inventory.meltedGoldGrams));
              setMeltedPurity(String(inventory.meltedPurityPerMille));
            }}
            className="px-3.5 py-2 text-xs font-medium border border-[#D4AF37]/50 text-[#E5C76B] rounded-lg hover:bg-[#D4AF37]/10"
          >
            {lang === 'fa'
              ? `بارگذاری از موجودی (${inventory.meltedGoldGrams}g)`
              : `Load From Inventory (${inventory.meltedGoldGrams}g)`}
          </button>
        )}
      </div>

      {/* Planner Parameters Form */}
      <form onSubmit={handleGeneratePlans} className="bg-[#121216] border border-[#24242B] rounded-xl p-6 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs text-[#9A968E] mb-1.5">
              {lang === 'fa' ? 'وزن طلای آب‌شده موجود (گرم)' : 'Available Melted Gold (g)'}
            </label>
            <input
              type="number"
              step="0.1"
              min="1"
              required
              value={availableMeltedGrams}
              onChange={(e) => setAvailableMeltedGrams(e.target.value)}
              className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num text-[#F5F2EB]"
            />
          </div>
          <div>
            <label className="block text-xs text-[#9A968E] mb-1.5">
              {lang === 'fa' ? 'عیار طلای آب‌شده (در هزار)' : 'Melted Gold Purity (per mille)'}
            </label>
            <input
              type="number"
              step="0.1"
              min="100"
              max="999.9"
              required
              value={meltedPurity}
              onChange={(e) => setMeltedPurity(e.target.value)}
              className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num text-[#F5F2EB]"
            />
          </div>
          <div>
            <label className="block text-xs text-[#9A968E] mb-1.5">
              {lang === 'fa' ? 'بودجه ساخت و اجرت (ریال)' : 'Manufacturing Budget (IRR)'}
            </label>
            <input
              type="number"
              min="0"
              value={budget}
              onChange={(e) => setBudget(e.target.value)}
              className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num text-[#F5F2EB]"
            />
          </div>
          <div>
            <label className="block text-xs text-[#9A968E] mb-1.5">
              {lang === 'fa' ? 'سقف تعداد کل تولید' : 'Max Units Capacity'}
            </label>
            <input
              type="number"
              min="1"
              max="500"
              value={maxUnits}
              onChange={(e) => setMaxUnits(e.target.value)}
              className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num text-[#F5F2EB]"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs text-[#9A968E] mb-1.5">
              {lang === 'fa' ? 'عیار محصول نهایی' : 'Target Finished Karat'}
            </label>
            <select
              value={targetKarat}
              onChange={(e) => setTargetKarat(Number(e.target.value) as 18 | 21 | 24)}
              className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm text-[#F5F2EB]"
            >
              <option value={18}>18K (750)</option>
              <option value={21}>21K (875)</option>
              <option value={24}>24K (999.9)</option>
            </select>
          </div>
          <div>
            <label className="block text-xs text-[#9A968E] mb-1.5">
              {lang === 'fa' ? 'ترجیح ریسک' : 'Risk Preference'}
            </label>
            <select
              value={riskPreference}
              onChange={(e) => setRiskPreference(e.target.value as 'low' | 'medium' | 'high')}
              className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm text-[#F5F2EB]"
            >
              <option value="low">{lang === 'fa' ? 'کم‌ریسک (مدل‌های کلاسیک)' : 'Low Risk (High-Liquidity Staples)'}</option>
              <option value="medium">{lang === 'fa' ? 'متعادل' : 'Balanced'}</option>
              <option value="high">{lang === 'fa' ? 'حاشیه سود بالا' : 'Growth / Margin Focus'}</option>
            </select>
          </div>
          <div>
            <label className="block text-xs text-[#9A968E] mb-1.5">
              {lang === 'fa' ? 'هدف سودآوری' : 'Profit Objective'}
            </label>
            <select
              value={profitObjective}
              onChange={(e) => setProfitObjective(e.target.value as 'balanced' | 'turnover' | 'margin')}
              className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm text-[#F5F2EB]"
            >
              <option value="balanced">{lang === 'fa' ? 'توازن گردش و سود' : 'Balanced Yield & Turnover'}</option>
              <option value="turnover">{lang === 'fa' ? 'فروش سریع نقدی' : 'Fast Cashflow Turnover'}</option>
              <option value="margin">{lang === 'fa' ? 'حداکثر سود هر گرم' : 'Maximum Margin per Gram'}</option>
            </select>
          </div>
        </div>

        {/* Category Multi-Select */}
        <div>
          <div className="text-xs text-[#9A968E] mb-2">
            {lang === 'fa' ? 'رده‌های محصول مجاز در برنامه تولید' : 'Target Jewelry Categories'}
          </div>
          <div className="flex flex-wrap gap-2">
            {JEWELRY_CATEGORIES.map((c) => {
              const active = selectedCategories.includes(c.id);
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => toggleCategory(c.id)}
                  className={`px-3 py-1.5 text-xs rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-[#D4AF37]/20 border-[#D4AF37] text-[#E5C76B]'
                      : 'bg-[#09090B] border-[#24242B] text-[#9A968E] hover:text-[#F5F2EB]'
                  }`}
                >
                  {lang === 'fa' ? c.nameFa : c.nameEn}
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex items-center justify-between gap-4 pt-2 border-t border-[#24242B]">
          <span className="text-xs text-[#7E7B74]">
            {lang === 'fa'
              ? `نرخ پرت پایه: ${appSettings.defaultLossPct}% · ضایعات قابل بازیابی: ${appSettings.recoverableScrapPct}%`
              : `Configured permanent loss: ${appSettings.defaultLossPct}% · Recoverable scrap: ${appSettings.recoverableScrapPct}%`}
          </span>
          <button
            type="submit"
            disabled={loading}
            className="inline-flex items-center gap-2 px-6 py-2.5 text-sm font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B] disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4" />
            <span>{loading ? t.common.loading : lang === 'fa' ? 'تولید و مقایسه برنامه‌ها' : 'Generate & Compare Plans'}</span>
          </button>
        </div>
      </form>

      {errorMsg && (
        <div className="bg-[#1F1215] border border-[#EF4444]/40 text-[#FCA5A5] rounded-xl p-4 text-sm flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Comparable Production Plans */}
      {plans.length > 0 && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {plans.map((p, idx) => (
              <div
                key={p.planName + idx}
                onClick={() => setSelectedPlanIdx(idx)}
                className={`cursor-pointer rounded-xl p-5 border transition-colors ${
                  selectedPlanIdx === idx
                    ? 'bg-[#171614] border-[#D4AF37]'
                    : 'bg-[#121216] border-[#24242B] hover:border-[#D4AF37]/40'
                }`}
              >
                <div className="flex items-center justify-between gap-2 text-xs text-[#9A968E] mb-1">
                  <span className="uppercase">{p.strategyType}</span>
                  <span>
                    {t.common.risk}: {p.riskLevel}
                  </span>
                </div>
                <h3 className="text-base font-semibold text-[#F5F2EB]">{p.planName}</h3>
                <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-[#24242B] text-xs">
                  <div>
                    <div className="text-[#7E7B74]">{lang === 'fa' ? 'طلای مصرفی' : 'Gold Used'}</div>
                    <div className="font-mono-num text-[#E5C76B] font-semibold">
                      {p.totals.totalGoldRequiredGrams} g
                    </div>
                  </div>
                  <div>
                    <div className="text-[#7E7B74]">{lang === 'fa' ? 'باقی‌مانده' : 'Remaining'}</div>
                    <div className="font-mono-num text-[#F5F2EB]">{p.totals.remainingGoldGrams} g</div>
                  </div>
                  <div>
                    <div className="text-[#7E7B74]">{lang === 'fa' ? 'تعداد کل' : 'Total Units'}</div>
                    <div className="font-mono-num text-[#F5F2EB]">{p.totals.totalUnits}</div>
                  </div>
                  <div>
                    <div className="text-[#7E7B74]">{lang === 'fa' ? 'سود برآوردی' : 'Est. Profit'}</div>
                    <div className="font-mono-num text-[#10B981]">
                      {formatNum(p.totals.estimatedProfit, lang, 0)}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {plans[selectedPlanIdx] && (
            <div className="bg-[#121216] border border-[#24242B] rounded-xl p-6 space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h3 className="text-lg font-semibold text-[#E5C76B]">
                    {plans[selectedPlanIdx].planName}
                  </h3>
                  <p className="text-xs text-[#B8B3A8] mt-1 max-w-3xl">
                    {plans[selectedPlanIdx].explanation}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => void handleSavePlan(plans[selectedPlanIdx])}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B]"
                >
                  <BookmarkCheck className="w-4 h-4" />
                  <span>{lang === 'fa' ? 'ذخیره برنامه تولید' : 'Save Plan'}</span>
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b border-[#24242B] text-xs text-[#9A968E]">
                    <tr>
                      <th className="text-start py-3 px-3 font-medium">{lang === 'fa' ? 'مدل جواهر' : 'Catalog Model'}</th>
                      <th className="text-end py-3 px-3 font-medium">{t.common.units}</th>
                      <th className="text-end py-3 px-3 font-medium">{lang === 'fa' ? 'وزن واحد' : 'Unit Weight'}</th>
                      <th className="text-end py-3 px-3 font-medium">{lang === 'fa' ? 'کل طلا' : 'Total Gold'}</th>
                      <th className="text-end py-3 px-3 font-medium">{t.common.confidence}</th>
                      <th className="text-start py-3 px-3 font-medium">{lang === 'fa' ? 'دلیل انتخاب' : 'Rationale'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#24242B]">
                    {plans[selectedPlanIdx].items.map((item, idx) => (
                      <tr key={item.modelId + idx}>
                        <td className="py-3 px-3 font-medium text-[#F5F2EB]">{item.modelName}</td>
                        <td className="py-3 px-3 text-end font-mono-num text-[#E5C76B]">{item.units}</td>
                        <td className="py-3 px-3 text-end font-mono-num">{item.unitWeightGrams} g</td>
                        <td className="py-3 px-3 text-end font-mono-num">{item.totalGoldGrams} g</td>
                        <td className="py-3 px-3 text-end font-mono-num">{item.demandConfidence}%</td>
                        <td className="py-3 px-3 text-xs text-[#B8B3A8]">{item.rationale}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export const PurityCalculatorView: React.FC = () => {
  const { lang, goldPrices, appSettings } = useApp();
  const t = TRANSLATIONS[lang];
  const default18k = goldPrices.find((g) => g.symbol === 'IR18K')?.price || 46850000;

  const [meltedWeight, setMeltedWeight] = useState(100);
  const [meltedPurity, setMeltedPurity] = useState(750);
  const [targetPurity, setTargetPurity] = useState(750);
  const [units, setUnits] = useState(15);
  const [unitWeight, setUnitWeight] = useState(5.2);
  const [recoverableScrapPct, setRecoverableScrapPct] = useState(appSettings.recoverableScrapPct);
  const [actualLossPct, setActualLossPct] = useState(appSettings.defaultLossPct);
  const [goldPrice18k, setGoldPrice18k] = useState(default18k);
  const [laborFeePct, setLaborFeePct] = useState(12);
  const [additionalCosts, setAdditionalCosts] = useState(15000000);
  const [retailMarkupPct, setRetailMarkupPct] = useState(7);

  const calc = useMemo(
    () =>
      calculateProductionEconomics({
        meltedWeightGrams: meltedWeight,
        meltedPurityPerMille: meltedPurity,
        targetPurityPerMille: targetPurity,
        unitsToProduce: units,
        unitFinishedWeightGrams: unitWeight,
        recoverableScrapPct,
        actualLossPct,
        goldPricePerGram18K: goldPrice18k,
        laborFeePct,
        additionalWorkshopCosts: additionalCosts,
        retailMarkupPct,
      }),
    [
      meltedWeight,
      meltedPurity,
      targetPurity,
      units,
      unitWeight,
      recoverableScrapPct,
      actualLossPct,
      goldPrice18k,
      laborFeePct,
      additionalCosts,
      retailMarkupPct,
    ]
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold text-[#F5F2EB] flex items-center gap-3">
          <Calculator className="w-7 h-7 text-[#D4AF37]" />
          <span>{t.nav.calculator}</span>
        </h1>
        <p className="text-sm text-[#9A968E] mt-1">
          {lang === 'fa'
            ? 'محاسبه دقیق عیار، طلای خالص ۲۴، آلیاژ مورد نیاز، تفکیک سوهان‌کاری قابل بازیافت از پرت دائمی و سود خالص'
            : 'Transparent purity, alloy, recoverable scrap vs permanent loss, manufacturing fees, and profit margin calculations.'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Inputs */}
        <div className="lg:col-span-5 bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-semibold text-[#E5C76B]">
            {lang === 'fa' ? 'پارامترهای ذوب و تولید' : 'Input Parameters'}
          </h3>
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block text-[#9A968E] mb-1">{lang === 'fa' ? 'موجودی آب‌شده (g)' : 'Melted Stock (g)'}</label>
              <input type="number" step="0.1" value={meltedWeight} onChange={(e) => setMeltedWeight(Number(e.target.value) || 0)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num" />
            </div>
            <div>
              <label className="block text-[#9A968E] mb-1">{lang === 'fa' ? 'عیار آب‌شده' : 'Source Purity'}</label>
              <input type="number" step="0.1" value={meltedPurity} onChange={(e) => setMeltedPurity(Number(e.target.value) || 750)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num" />
            </div>
            <div>
              <label className="block text-[#9A968E] mb-1">{lang === 'fa' ? 'عیار هدف' : 'Target Purity'}</label>
              <select value={targetPurity} onChange={(e) => setTargetPurity(Number(e.target.value))} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num">
                <option value={750}>18K (750)</option>
                <option value={875}>21K (875)</option>
                <option value={999.9}>24K (999.9)</option>
              </select>
            </div>
            <div>
              <label className="block text-[#9A968E] mb-1">{lang === 'fa' ? 'تعداد قطعه' : 'Units Count'}</label>
              <input type="number" min="1" value={units} onChange={(e) => setUnits(Number(e.target.value) || 0)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num" />
            </div>
            <div>
              <label className="block text-[#9A968E] mb-1">{lang === 'fa' ? 'وزن هر قطعه (g)' : 'Unit Weight (g)'}</label>
              <input type="number" step="0.1" value={unitWeight} onChange={(e) => setUnitWeight(Number(e.target.value) || 0)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num" />
            </div>
            <div>
              <label className="block text-[#9A968E] mb-1">{lang === 'fa' ? 'پرت دائمی (%)' : 'Permanent Loss (%)'}</label>
              <input type="number" step="0.1" value={actualLossPct} onChange={(e) => setActualLossPct(Number(e.target.value) || 0)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num" />
            </div>
            <div>
              <label className="block text-[#9A968E] mb-1">{lang === 'fa' ? 'ضایعات قابل بازیافت (%)' : 'Recoverable Scrap (%)'}</label>
              <input type="number" step="0.1" value={recoverableScrapPct} onChange={(e) => setRecoverableScrapPct(Number(e.target.value) || 0)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num" />
            </div>
            <div>
              <label className="block text-[#9A968E] mb-1">{lang === 'fa' ? 'اجرت ساخت (%)' : 'Labor Fee (%)'}</label>
              <input type="number" step="0.5" value={laborFeePct} onChange={(e) => setLaborFeePct(Number(e.target.value) || 0)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num" />
            </div>
            <div>
              <label className="block text-[#9A968E] mb-1">{lang === 'fa' ? 'نرخ گرم ۱۸ عیار' : '18K Price / Gram'}</label>
              <input type="number" value={goldPrice18k} onChange={(e) => setGoldPrice18k(Number(e.target.value) || 0)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num" />
            </div>
            <div>
              <label className="block text-[#9A968E] mb-1">{lang === 'fa' ? 'سود فروش (%)' : 'Retail Markup (%)'}</label>
              <input type="number" step="0.5" value={retailMarkupPct} onChange={(e) => setRetailMarkupPct(Number(e.target.value) || 0)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num" />
            </div>
            <div className="col-span-2">
              <label className="block text-[#9A968E] mb-1">{lang === 'fa' ? 'هزینه‌های جانبی کارگاه (ریال)' : 'Additional Costs (IRR)'}</label>
              <input type="number" value={additionalCosts} onChange={(e) => setAdditionalCosts(Number(e.target.value) || 0)} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm font-mono-num" />
            </div>
          </div>
        </div>

        {/* Breakdown Results */}
        <div className="lg:col-span-7 space-y-4">
          {calc.exceedsAvailableInventory && (
            <div className="bg-[#1F1215] border border-[#EF4444]/40 text-[#FCA5A5] rounded-xl p-4 text-xs">
              {lang === 'fa'
                ? 'هشدار: طلای مصرفی مورد نیاز از موجودی آب‌شده شما بیشتر است!'
                : 'Warning: Required melted gold exceeds your available stock.'}
            </div>
          )}

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
              <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'وزن خالص محصول' : 'Gross Finished Weight'}</div>
              <div className="text-xl font-semibold text-[#F5F2EB] font-mono-num mt-1">{calc.grossFinishedWeightGrams} g</div>
            </div>
            <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
              <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'طلای ۲۴ عیار خالص' : 'Pure Fine Gold (24K)'}</div>
              <div className="text-xl font-semibold text-[#E5C76B] font-mono-num mt-1">{calc.pureGoldInFinishedGrams} g</div>
            </div>
            <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
              <div className="text-xs text-[#9A968E]">{calc.needsFineGoldUpgrade ? (lang === 'fa' ? 'طلای ۲۴ عیار افزایشی' : 'Fine 24K Upgrade') : (lang === 'fa' ? 'بار / آلیاژ' : 'Alloy Required')}</div>
              <div className="text-xl font-semibold text-[#F5F2EB] font-mono-num mt-1">
                {calc.needsFineGoldUpgrade ? calc.fineGoldToAddGrams : calc.alloyAdjustmentGrams} g
              </div>
            </div>
            <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
              <div className="text-xs text-[#10B981]">{lang === 'fa' ? 'ضایعات قابل بازیافت' : 'Recoverable Scrap'}</div>
              <div className="text-xl font-semibold text-[#10B981] font-mono-num mt-1">{calc.recoverableScrapGrams} g</div>
            </div>
            <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
              <div className="text-xs text-[#F59E0B]">{lang === 'fa' ? 'پرت واقعی ذوب/ساخت' : 'Permanent Production Loss'}</div>
              <div className="text-xl font-semibold text-[#F59E0B] font-mono-num mt-1">{calc.permanentLossGrams} g</div>
            </div>
            <div className="bg-[#121216] border border-[#24242B] rounded-xl p-4">
              <div className="text-xs text-[#9A968E]">{lang === 'fa' ? 'موجودی آب‌شده باقی‌مانده' : 'Remaining Melted Stock'}</div>
              <div className="text-xl font-semibold text-[#F5F2EB] font-mono-num mt-1">{calc.remainingMeltedInventoryGrams} g</div>
            </div>
          </div>

          {/* Financial Summary & Formulas */}
          <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-3 text-sm">
            <div className="flex justify-between py-1.5 border-b border-[#24242B]">
              <span className="text-[#9A968E]">{lang === 'fa' ? 'ارزش طلای مصرفی' : 'Gold Value Consumed'}</span>
              <span className="font-mono-num">{formatNum(calc.goldCostValue, lang, 0)} IRR</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-[#24242B]">
              <span className="text-[#9A968E]">{lang === 'fa' ? 'اجرت ساخت و هزینه‌ها' : 'Labor & Workshop Costs'}</span>
              <span className="font-mono-num">{formatNum(calc.laborFeeCost + additionalCosts, lang, 0)} IRR</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-[#24242B]">
              <span className="text-[#9A968E]">{lang === 'fa' ? 'درآمد فروش برآوردی' : 'Estimated Selling Revenue'}</span>
              <span className="font-mono-num text-[#E5C76B]">{formatNum(calc.estimatedSellingRevenue, lang, 0)} IRR</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="font-semibold text-[#F5F2EB]">{lang === 'fa' ? 'سود خالص برآوردی' : 'Estimated Net Profit'}</span>
              <span className={`font-mono-num font-semibold ${calc.estimatedNetProfit >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                {formatNum(calc.estimatedNetProfit, lang, 0)} IRR ({calc.profitMarginPct}%)
              </span>
            </div>
          </div>

          <div className="bg-[#0D0D10] border border-[#24242B] rounded-xl p-4 space-y-1.5 text-xs font-mono-num text-[#9A968E]">
            <div className="text-[#E5C76B] font-sans font-medium mb-1">
              {lang === 'fa' ? 'فرمول‌های شفاف محاسبه' : 'Transparent Calculation Formulas'}
            </div>
            <div>{calc.formulas.fineGoldFormula}</div>
            <div>{calc.formulas.alloyFormula}</div>
            <div>{calc.formulas.scrapVsLossFormula}</div>
            <div>{calc.formulas.profitFormula}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
