import React, { useEffect, useState } from 'react';
import { HelpCircle, Mail, MessageSquare, Send, Ticket } from 'lucide-react';
import { addDoc, collection, doc, getDoc, onSnapshot, orderBy, query, serverTimestamp, updateDoc, where } from 'firebase/firestore';
import { useApp } from '../../context/AppContext';
import { db, OperationType, handleFirestoreError } from '../../firebase';
import { DEFAULT_FAQS, DEFAULT_LEGAL_DOCS } from '../../data/demoData';
import { TRANSLATIONS } from '../../i18n/translations';
import { SupportMessage } from '../../types/domain';

export const SupportCenterView: React.FC = () => {
  const { lang, navigate } = useApp();
  const t = TRANSLATIONS[lang];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{t.nav.supportCenter}</h1>
        <p className="text-sm text-[#9A968E] mt-1">
          {lang === 'fa'
            ? 'پشتیبانی تخصصی کارگاه‌ها و سرمایه‌گذاران · amirhossinbasirpor@gmail.com'
            : 'Dedicated support desk for workshops, retailers, and traders · amirhossinbasirpor@gmail.com'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { route: 'support-chat' as const, title: t.nav.supportChat, desc: lang === 'fa' ? 'گفتگوی زنده با کارشناسان پشتیبانی' : 'Real-time thread with UMA Gold support', icon: <MessageSquare className="w-5 h-5 text-[#D4AF37]" /> },
          { route: 'support-tickets' as const, title: t.nav.supportTickets, desc: lang === 'fa' ? 'ثبت و پیگیری تیکت‌های فنی و مالی' : 'Create and track structured support tickets', icon: <Ticket className="w-5 h-5 text-[#D4AF37]" /> },
          { route: 'faq' as const, title: t.nav.faq, desc: lang === 'fa' ? 'پاسخ سوالات رایج عیار، پرت و API' : 'Answers on purity math, scrap & feeds', icon: <HelpCircle className="w-5 h-5 text-[#D4AF37]" /> },
          { route: 'contact' as const, title: t.nav.contact, desc: 'amirhossinbasirpor@gmail.com', icon: <Mail className="w-5 h-5 text-[#D4AF37]" /> },
        ].map((card) => (
          <button
            key={card.route}
            type="button"
            onClick={() => navigate(card.route)}
            className="text-start bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-3 hover:border-[#D4AF37]/60 transition-colors"
          >
            {card.icon}
            <div className="text-base font-semibold text-[#F5F2EB]">{card.title}</div>
            <div className="text-xs text-[#9A968E]">{card.desc}</div>
          </button>
        ))}
      </div>
    </div>
  );
};

export const SupportChatView: React.FC = () => {
  const { lang, user, isVerified, tickets, pushToast, navigate } = useApp();
  const t = TRANSLATIONS[lang];
  const [activeTicketId, setActiveTicketId] = useState<string>('');
  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const [text, setText] = useState('');

  useEffect(() => {
    if (!activeTicketId && tickets.length > 0) {
      setActiveTicketId(tickets[0].id);
    }
  }, [tickets, activeTicketId]);

  useEffect(() => {
    if (!user || !isVerified || !activeTicketId) {
      setMessages([]);
      return;
    }
    const unsub = onSnapshot(
      query(
        collection(db, 'support_messages'),
        where('ownerId', '==', user.uid),
        orderBy('createdAt', 'asc')
      ),
      (snap) => {
        setMessages(
          snap.docs
            .map((d) => {
              const data = d.data();
              return {
                id: d.id,
                ownerId: String(data.ownerId),
                ticketId: String(data.ticketId),
                senderUid: String(data.senderUid),
                senderRole: data.senderRole,
                body: String(data.body),
                createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
              };
            })
            .filter((m) => m.ticketId === activeTicketId)
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'support_messages')
    );
    return () => unsub();
  }, [user, isVerified, activeTicketId]);

  if (!user || !isVerified) {
    return (
      <div className="bg-[#121216] border border-[#24242B] rounded-xl p-8 text-center space-y-4">
        <h2 className="font-display text-2xl text-[#F5F2EB]">{t.nav.supportChat}</h2>
        <p className="text-sm text-[#9A968E]">{t.common.signInRequired}</p>
        <button type="button" onClick={() => navigate('auth')} className="px-5 py-2.5 text-sm font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg">
          {t.common.goToAuth}
        </button>
      </div>
    );
  }

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    try {
      let ticketId = activeTicketId;
      if (!ticketId) {
        const created = await addDoc(collection(db, 'support_tickets'), {
          ownerId: user.uid,
          subject: lang === 'fa' ? 'گفتگوی پشتیبانی زنده' : 'Live Support Conversation',
          category: 'general',
          priority: 'medium',
          status: 'open',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        ticketId = created.id;
        setActiveTicketId(ticketId);
      }
      await addDoc(collection(db, 'support_messages'), {
        ownerId: user.uid,
        ticketId,
        senderUid: user.uid,
        senderRole: 'user',
        body: text.trim().slice(0, 1900),
        createdAt: serverTimestamp(),
      });
      setText('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'support_messages');
      pushToast('error', 'Failed to send message');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{t.nav.supportChat}</h1>
        {tickets.length > 0 && (
          <select
            value={activeTicketId}
            onChange={(e) => setActiveTicketId(e.target.value)}
            className="bg-[#121216] border border-[#24242B] rounded-lg px-3 py-2 text-xs"
          >
            {tickets.map((tk) => (
              <option key={tk.id} value={tk.id}>{tk.subject} ({tk.status})</option>
            ))}
          </select>
        )}
      </div>

      <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5 flex flex-col h-[460px]">
        <div className="flex-1 overflow-y-auto space-y-3 pe-2">
          {messages.length === 0 ? (
            <div className="text-xs text-[#7E7B74] text-center pt-16">
              {lang === 'fa'
                ? 'پیام خود را بنویسید تا مستقیماً به تیم پشتیبانی ارسال شود.'
                : 'Send a message below to start your conversation with UMA Gold support.'}
            </div>
          ) : (
            messages.map((m) => {
              const isUser = m.senderRole === 'user';
              return (
                <div key={m.id} className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
                  <div
                    className={`max-w-md rounded-xl px-4 py-2.5 text-sm ${
                      isUser ? 'bg-[#D4AF37] text-[#09090B]' : 'bg-[#18181D] border border-[#24242B] text-[#F5F2EB]'
                    }`}
                  >
                    <div className="text-[10px] opacity-70 mb-0.5 uppercase">{m.senderRole}</div>
                    <div>{m.body}</div>
                  </div>
                </div>
              );
            })
          )}
        </div>
        <form onSubmit={handleSend} className="pt-3 border-t border-[#24242B] flex gap-2">
          <input
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={lang === 'fa' ? 'پیام خود را بنویسید...' : 'Write your message...'}
            className="flex-1 bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm"
          />
          <button type="submit" className="px-4 py-2 bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B]">
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};

export const SupportTicketsView: React.FC = () => {
  const { lang, user, isVerified, tickets, pushToast, navigate } = useApp();
  const t = TRANSLATIONS[lang];
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState<'billing' | 'technical' | 'market_data' | 'production_ai' | 'general'>('general');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [initialMsg, setInitialMsg] = useState('');

  if (!user || !isVerified) {
    return (
      <div className="bg-[#121216] border border-[#24242B] rounded-xl p-8 text-center space-y-4">
        <h2 className="font-display text-2xl text-[#F5F2EB]">{t.nav.supportTickets}</h2>
        <p className="text-sm text-[#9A968E]">{t.common.signInRequired}</p>
        <button type="button" onClick={() => navigate('auth')} className="px-5 py-2.5 text-sm font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg">
          {t.common.goToAuth}
        </button>
      </div>
    );
  }

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const ticketRef = await addDoc(collection(db, 'support_tickets'), {
        ownerId: user.uid,
        subject: subject.trim(),
        category,
        priority,
        status: 'open',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      if (initialMsg.trim()) {
        await addDoc(collection(db, 'support_messages'), {
          ownerId: user.uid,
          ticketId: ticketRef.id,
          senderUid: user.uid,
          senderRole: 'user',
          body: initialMsg.trim(),
          createdAt: serverTimestamp(),
        });
      }
      setSubject('');
      setInitialMsg('');
      pushToast('success', lang === 'fa' ? 'تیکت پشتیبانی ثبت شد.' : 'Support ticket created.');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'support_tickets');
    }
  };

  const closeTicket = async (id: string) => {
    try {
      await updateDoc(doc(db, 'support_tickets', id), {
        status: 'closed',
        updatedAt: serverTimestamp(),
      });
      pushToast('info', lang === 'fa' ? 'تیکت بسته شد.' : 'Ticket closed.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `support_tickets/${id}`);
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{t.nav.supportTickets}</h1>

      <form onSubmit={handleCreate} className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-3">
        <h3 className="text-sm font-semibold text-[#E5C76B]">{lang === 'fa' ? 'ثبت تیکت جدید' : 'Open New Ticket'}</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <input type="text" required minLength={3} value={subject} onChange={(e) => setSubject(e.target.value)} placeholder={lang === 'fa' ? 'موضوع تیکت' : 'Subject'} className="bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm" />
          <select value={category} onChange={(e) => setCategory(e.target.value as typeof category)} className="bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm">
            <option value="general">General</option>
            <option value="billing">Billing & Refund</option>
            <option value="market_data">Market Data Feeds</option>
            <option value="production_ai">Production AI</option>
            <option value="technical">Technical</option>
          </select>
          <select value={priority} onChange={(e) => setPriority(e.target.value as typeof priority)} className="bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm">
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </div>
        <textarea rows={3} value={initialMsg} onChange={(e) => setInitialMsg(e.target.value)} placeholder={lang === 'fa' ? 'توضیحات...' : 'Describe your request...'} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm" />
        <button type="submit" className="px-5 py-2 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B]">
          {t.common.submit}
        </button>
      </form>

      <div className="bg-[#121216] border border-[#24242B] rounded-xl divide-y divide-[#24242B]">
        {tickets.length === 0 ? (
          <div className="p-6 text-center text-xs text-[#7E7B74]">{t.common.empty}</div>
        ) : (
          tickets.map((tk) => (
            <div key={tk.id} className="p-4 flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="text-sm font-medium text-[#F5F2EB]">{tk.subject}</div>
                <div className="text-xs text-[#9A968E]">{tk.category} · {tk.priority} · {tk.status}</div>
              </div>
              <div className="flex items-center gap-2">
                <button type="button" onClick={() => navigate('support-chat')} className="px-3 py-1.5 text-xs border border-[#24242B] rounded-lg hover:border-[#D4AF37]">
                  {t.nav.supportChat}
                </button>
                {tk.status !== 'closed' && (
                  <button type="button" onClick={() => void closeTicket(tk.id)} className="px-3 py-1.5 text-xs text-[#9A968E] hover:text-[#EF4444]">
                    {lang === 'fa' ? 'بستن' : 'Close'}
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export const FaqView: React.FC = () => {
  const { lang } = useApp();
  const [search, setSearch] = useState('');
  const items = DEFAULT_FAQS.filter((f) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return f.questionEn.toLowerCase().includes(q) || f.questionFa.includes(search);
  });

  return (
    <div className="max-w-3xl space-y-6">
      <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">
        {lang === 'fa' ? 'سوالات متداول' : 'Frequently Asked Questions'}
      </h1>
      <input
        type="text"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder={lang === 'fa' ? 'جستجو در سوالات...' : 'Search FAQ...'}
        className="w-full bg-[#121216] border border-[#24242B] rounded-lg px-4 py-2.5 text-sm"
      />
      <div className="space-y-4">
        {items.map((f) => (
          <div key={f.id} className="bg-[#121216] border border-[#24242B] rounded-xl p-5 space-y-2">
            <h3 className="text-sm font-semibold text-[#E5C76B]">{lang === 'fa' ? f.questionFa : f.questionEn}</h3>
            <p className="text-xs text-[#D4CFC4] leading-relaxed">{lang === 'fa' ? f.answerFa : f.answerEn}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export const ContactView: React.FC = () => {
  const { lang, user, isVerified, pushToast, navigate } = useApp();
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !isVerified) {
      pushToast('info', TRANSLATIONS[lang].common.signInRequired);
      navigate('auth');
      return;
    }
    try {
      const tk = await addDoc(collection(db, 'support_tickets'), {
        ownerId: user.uid,
        subject: subject.trim(),
        category: 'general',
        priority: 'medium',
        status: 'open',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await addDoc(collection(db, 'support_messages'), {
        ownerId: user.uid,
        ticketId: tk.id,
        senderUid: user.uid,
        senderRole: 'user',
        body: message.trim(),
        createdAt: serverTimestamp(),
      });
      setSubject('');
      setMessage('');
      pushToast('success', lang === 'fa' ? 'پیام شما ثبت و به پشتیبانی ارسال شد.' : 'Inquiry logged with support.');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'support_tickets');
    }
  };

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold text-[#F5F2EB]">{TRANSLATIONS[lang].nav.contact}</h1>
        <p className="text-sm text-[#9A968E] mt-1">
          {lang === 'fa' ? 'ایمیل مستقیم پشتیبانی:' : 'Direct Support Email:'}{' '}
          <a href="mailto:amirhossinbasirpor@gmail.com" className="text-[#E5C76B] hover:underline">
            amirhossinbasirpor@gmail.com
          </a>
        </p>
      </div>
      <form onSubmit={handleSend} className="bg-[#121216] border border-[#24242B] rounded-xl p-6 space-y-4">
        <input type="text" required minLength={3} value={subject} onChange={(e) => setSubject(e.target.value)} placeholder={lang === 'fa' ? 'موضوع' : 'Subject'} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm" />
        <textarea required rows={4} value={message} onChange={(e) => setMessage(e.target.value)} placeholder={lang === 'fa' ? 'متن پیام...' : 'Your message...'} className="w-full bg-[#09090B] border border-[#24242B] rounded-lg px-3 py-2 text-sm" />
        <button type="submit" className="px-5 py-2.5 text-xs font-semibold bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B]">
          {TRANSLATIONS[lang].common.submit}
        </button>
      </form>
    </div>
  );
};

export const LegalPageView: React.FC<{ slug: 'privacy' | 'terms' | 'subscription-refund' | 'ai-disclaimer' }> = ({ slug }) => {
  const { lang } = useApp();
  const fallback = DEFAULT_LEGAL_DOCS[slug];
  const [docData, setDocData] = useState(fallback);

  useEffect(() => {
    setDocData(DEFAULT_LEGAL_DOCS[slug]);
    getDoc(doc(db, 'legal_pages', slug))
      .then((snap) => {
        if (snap.exists()) {
          const d = snap.data();
          setDocData({
            slug,
            titleEn: String(d.titleEn || fallback.titleEn),
            titleFa: String(d.titleFa || fallback.titleFa),
            bodyEn: String(d.bodyEn || fallback.bodyEn),
            bodyFa: String(d.bodyFa || fallback.bodyFa),
          });
        }
      })
      .catch(() => {});
  }, [slug, fallback]);

  return (
    <div className="max-w-3xl bg-[#121216] border border-[#24242B] rounded-xl p-7 space-y-5">
      <h1 className="font-display text-3xl font-semibold text-[#E5C76B]">
        {lang === 'fa' ? docData.titleFa : docData.titleEn}
      </h1>
      <div className="text-sm text-[#D4CFC4] leading-relaxed whitespace-pre-line">
        {lang === 'fa' ? docData.bodyFa : docData.bodyEn}
      </div>
    </div>
  );
};
