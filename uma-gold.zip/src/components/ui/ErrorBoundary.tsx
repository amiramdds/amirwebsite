import React from 'react';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message || 'Unexpected application error' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#09090B] text-[#F5F2EB] flex items-center justify-center p-6">
          <div className="max-w-lg w-full bg-[#121216] border border-[#24242B] rounded-xl p-6 space-y-4">
            <h2 className="text-xl font-semibold text-[#E5C76B]">UMA Gold — System Notice</h2>
            <p className="text-sm text-[#B8B3A8] break-words">{this.state.message}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-4 py-2 text-sm font-medium bg-[#D4AF37] text-[#09090B] rounded-lg hover:bg-[#E5C76B] transition-colors"
            >
              Reload Application
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
