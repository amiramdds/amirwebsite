import React, { useMemo, useState } from 'react';
import { formatNum } from '../../i18n/translations';
import { Language } from '../../types/domain';

interface Point {
  label: string;
  value: number;
}

interface LuxuryChartProps {
  title: string;
  subtitle?: string;
  points: Point[];
  unit?: string;
  lang: Language;
  height?: number;
}

export const LuxuryAreaChart: React.FC<LuxuryChartProps> = ({
  title,
  subtitle,
  points,
  unit = '',
  lang,
  height = 240,
}) => {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);

  const metrics = useMemo(() => {
    if (points.length === 0) return null;
    const vals = points.map((p) => p.value);
    const min = Math.min(...vals);
    const max = Math.max(...vals);
    const pad = (max - min) * 0.14 || max * 0.05 || 1;
    const yMin = min - pad;
    const yMax = max + pad;
    const width = 720;
    const chartH = height;
    const padX = 16;
    const padY = 18;

    const coords = points.map((p, i) => {
      const x =
        points.length === 1
          ? width / 2
          : padX + (i / (points.length - 1)) * (width - padX * 2);
      const y =
        padY + (1 - (p.value - yMin) / (yMax - yMin)) * (chartH - padY * 2);
      return { ...p, x, y };
    });

    const linePath = coords
      .map((c, i) => `${i === 0 ? 'M' : 'L'} ${c.x.toFixed(1)} ${c.y.toFixed(1)}`)
      .join(' ');

    const areaPath =
      coords.length > 0
        ? `${linePath} L ${coords[coords.length - 1].x.toFixed(1)} ${chartH - padY} L ${coords[0].x.toFixed(1)} ${chartH - padY} Z`
        : '';

    return { width, chartH, coords, linePath, areaPath, min, max };
  }, [points, height]);

  const activePoint =
    hoverIdx !== null && metrics?.coords[hoverIdx]
      ? metrics.coords[hoverIdx]
      : metrics?.coords[metrics.coords.length - 1];

  return (
    <div className="bg-[#121216] border border-[#24242B] rounded-xl p-5">
      <div className="flex flex-wrap items-baseline justify-between gap-4 mb-4">
        <div>
          <h3 className="text-sm font-semibold text-[#F5F2EB]">{title}</h3>
          {subtitle && <p className="text-xs text-[#9A968E] mt-0.5">{subtitle}</p>}
        </div>
        {activePoint && (
          <div className="text-end">
            <span className="text-xs text-[#9A968E] me-2">{activePoint.label}</span>
            <span className="text-base font-semibold text-[#E5C76B] font-mono-num">
              {formatNum(activePoint.value, lang, activePoint.value < 5000 ? 2 : 0)} {unit}
            </span>
          </div>
        )}
      </div>

      {!metrics || points.length === 0 ? (
        <div className="h-48 flex items-center justify-center text-sm text-[#7E7B74] border border-dashed border-[#24242B] rounded-lg">
          {lang === 'fa' ? 'داده تاریخی کافی برای رسم نمودار موجود نیست.' : 'No historical market points available yet.'}
        </div>
      ) : (
        <div className="relative w-full" dir="ltr">
          <svg
            viewBox={`0 0 ${metrics.width} ${metrics.chartH}`}
            className="w-full h-auto overflow-visible"
            onMouseLeave={() => setHoverIdx(null)}
          >
            <defs>
              <linearGradient id="goldAreaGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#D4AF37" stopOpacity="0.28" />
                <stop offset="100%" stopColor="#D4AF37" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {[0.25, 0.5, 0.75].map((ratio) => (
              <line
                key={ratio}
                x1={16}
                x2={metrics.width - 16}
                y1={metrics.chartH * ratio}
                y2={metrics.chartH * ratio}
                stroke="#24242B"
                strokeDasharray="3 4"
                strokeWidth="1"
              />
            ))}

            <path d={metrics.areaPath} fill="url(#goldAreaGrad)" />
            <path d={metrics.linePath} fill="none" stroke="#D4AF37" strokeWidth="2.2" strokeLinejoin="round" />

            {activePoint && (
              <>
                <line
                  x1={activePoint.x}
                  x2={activePoint.x}
                  y1={14}
                  y2={metrics.chartH - 14}
                  stroke="#D4AF37"
                  strokeOpacity="0.35"
                  strokeWidth="1"
                />
                <circle
                  cx={activePoint.x}
                  cy={activePoint.y}
                  r="4.5"
                  fill="#09090B"
                  stroke="#E5C76B"
                  strokeWidth="2.2"
                />
              </>
            )}

            {metrics.coords.map((c, idx) => (
              <rect
                key={c.label + idx}
                x={c.x - metrics.width / (metrics.coords.length * 2)}
                y={0}
                width={metrics.width / metrics.coords.length}
                height={metrics.chartH}
                fill="transparent"
                className="cursor-crosshair"
                onMouseEnter={() => setHoverIdx(idx)}
              />
            ))}
          </svg>
          <div className="flex items-center justify-between text-[11px] text-[#7E7B74] font-mono-num mt-2 px-2">
            <span>{points[0]?.label}</span>
            <span>{points[Math.floor(points.length / 2)]?.label}</span>
            <span>{points[points.length - 1]?.label}</span>
          </div>
        </div>
      )}
    </div>
  );
};
