import React, { useState } from 'react';
import { Gem } from 'lucide-react';

interface SafeImageProps {
  src?: string;
  alt: string;
  className?: string;
}

export const SafeImage: React.FC<SafeImageProps> = ({ src, alt, className = '' }) => {
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-[#18181D] text-[#D4AF37]/60 border border-[#24242B] ${className}`}
        role="img"
        aria-label={alt}
      >
        <Gem className="w-8 h-8 mb-2" />
        <span className="text-xs text-[#9A968E] px-3 text-center truncate max-w-full">{alt}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
};
