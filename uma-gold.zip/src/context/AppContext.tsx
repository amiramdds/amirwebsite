import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  User,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  where,
} from 'firebase/firestore';
import {
  BOOTSTRAPPED_ADMIN_EMAILS,
  OperationType,
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  testConnection,
} from '../firebase';
import {
  DEFAULT_APP_SETTINGS,
  DEMO_CURRENCY_PRICES,
  DEMO_GOLD_PRICES,
  DEMO_JEWELRY_MODELS,
  DEMO_MARKET_HISTORY,
} from '../data/demoData';
import {
  AppSettings,
  CurrencyPriceItem,
  GoldPriceItem,
  InventoryBalance,
  InventoryTransaction,
  JewelryModel,
  Language,
  MarketHistoryPoint,
  PageRoute,
  PaymentRecord,
  ReturnedGoldRecord,
  SalesRecord,
  SavedProductionPlan,
  ScrapRecord,
  SupportTicket,
  UserRole,
} from '../types/domain';

interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  text: string;
}

interface AppContextValue {
  lang: Language;
  setLang: (lang: Language) => void;
  route: PageRoute;
  navigate: (route: PageRoute) => void;
  user: User | null;
  authReady: boolean;
  userRole: UserRole;
  subscriptionTier: 'free' | 'pro' | 'organization';
  isAdmin: boolean;
  isSupportOrAdmin: boolean;
  isVerified: boolean;
  signInGoogle: () => Promise<void>;
  signInEmail: (email: string, pass: string) => Promise<void>;
  registerEmail: (name: string, email: string, pass: string) => Promise<void>;
  resendVerification: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  // Market state
  goldPrices: GoldPriceItem[];
  currencyPrices: CurrencyPriceItem[];
  marketHistory: MarketHistoryPoint[];
  marketProviderStatus: { configured: boolean; provider: string; status: string; fetchedAt?: string; message?: string };
  refreshMarketSnapshot: () => Promise<void>;
  demoMode: boolean;
  setDemoMode: (val: boolean) => void;
  // Catalog & Settings
  catalogModels: JewelryModel[];
  appSettings: AppSettings;
  // User private data
  inventory: InventoryBalance | null;
  inventoryTx: InventoryTransaction[];
  scrapRecords: ScrapRecord[];
  returnedGold: ReturnedGoldRecord[];
  salesRecords: SalesRecord[];
  savedPlans: SavedProductionPlan[];
  payments: PaymentRecord[];
  tickets: SupportTicket[];
  // UI helpers
  toasts: ToastMessage[];
  pushToast: (type: 'success' | 'error' | 'info', text: string) => void;
  dismissToast: (id: string) => void;
  getAuthToken: () => Promise<string>;
}

const ROUTE_PATHS: Record<PageRoute, string> = {
  landing: '/',
  overview: '/dashboard',
  prices: '/prices',
  'iran-market': '/analytics/iran',
  'intl-market': '/analytics/international',
  'ai-predictions': '/intelligence/forecasts',
  'demand-analysis': '/intelligence/demand',
  'production-planner': '/planner',
  inventory: '/inventory',
  catalog: '/catalog',
  calculator: '/calculator',
  'user-dashboard': '/workspace',
  pricing: '/pricing',
  payments: '/billing/history',
  'support-center': '/support',
  'support-chat': '/support/chat',
  'support-tickets': '/support/tickets',
  faq: '/support/faq',
  contact: '/contact',
  auth: '/auth',
  profile: '/settings/profile',
  'legal-privacy': '/legal/privacy',
  'legal-terms': '/legal/terms',
  'legal-refund': '/legal/refund',
  'legal-ai': '/legal/ai-disclaimer',
  admin: '/admin',
};

function resolveRouteFromPath(pathname: string): PageRoute {
  const entry = (Object.entries(ROUTE_PATHS) as [PageRoute, string][]).find(([, p]) => p === pathname);
  return entry ? entry[0] : 'landing';
}

const AppContext = createContext<AppContextValue | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [lang, setLangState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('uma_gold_lang');
      return saved === 'fa' ? 'fa' : 'en';
    } catch {
      return 'en';
    }
  });

  const [route, setRoute] = useState<PageRoute>(() => resolveRouteFromPath(window.location.pathname));
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [userRole, setUserRole] = useState<UserRole>('guest');
  const [subscriptionTier, setSubscriptionTier] = useState<'free' | 'pro' | 'organization'>('free');

  const [demoMode, setDemoMode] = useState<boolean>(true);
  const [appSettings, setAppSettings] = useState<AppSettings>(DEFAULT_APP_SETTINGS);

  const [apiGoldPrices, setApiGoldPrices] = useState<GoldPriceItem[]>([]);
  const [apiCurrencyPrices, setApiCurrencyPrices] = useState<CurrencyPriceItem[]>([]);
  const [manualGoldPrices, setManualGoldPrices] = useState<GoldPriceItem[]>([]);
  const [manualCurrencyPrices, setManualCurrencyPrices] = useState<CurrencyPriceItem[]>([]);
  const [firestoreHistory, setFirestoreHistory] = useState<MarketHistoryPoint[]>([]);
  const [marketProviderStatus, setMarketProviderStatus] = useState<{
    configured: boolean;
    provider: string;
    status: string;
    fetchedAt?: string;
    message?: string;
  }>({ configured: false, provider: 'none', status: 'unavailable' });

  const [firestoreModels, setFirestoreModels] = useState<JewelryModel[]>([]);
  const [inventory, setInventory] = useState<InventoryBalance | null>(null);
  const [inventoryTx, setInventoryTx] = useState<InventoryTransaction[]>([]);
  const [scrapRecords, setScrapRecords] = useState<ScrapRecord[]>([]);
  const [returnedGold, setReturnedGold] = useState<ReturnedGoldRecord[]>([]);
  const [salesRecords, setSalesRecords] = useState<SalesRecord[]>([]);
  const [savedPlans, setSavedPlans] = useState<SavedProductionPlan[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const pushToast = useCallback((type: 'success' | 'error' | 'info', text: string) => {
    const id = `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [...prev.slice(-3), { id, type, text }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const setLang = useCallback((next: Language) => {
    setLangState(next);
    try {
      localStorage.setItem('uma_gold_lang', next);
    } catch {
      // ignore storage failure
    }
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
  }, [lang]);

  const navigate = useCallback((nextRoute: PageRoute) => {
    setRoute(nextRoute);
    const nextPath = ROUTE_PATHS[nextRoute] || '/';
    if (window.location.pathname !== nextPath) {
      window.history.pushState({}, '', nextPath);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    const onPopState = () => setRoute(resolveRouteFromPath(window.location.pathname));
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const refreshMarketSnapshot = useCallback(async () => {
    try {
      const resp = await fetch('/api/market/snapshot');
      const data = await resp.json();
      setMarketProviderStatus({
        configured: Boolean(data.configured),
        provider: String(data.provider || 'none'),
        status: String(data.status || 'unavailable'),
        fetchedAt: data.fetchedAt,
        message: data.message || data.error,
      });
      if (Array.isArray(data.goldPrices)) {
        setApiGoldPrices(
          data.goldPrices.map((g: Partial<GoldPriceItem>, idx: number) => ({
            id: `api-${g.symbol || idx}`,
            symbol: String(g.symbol || 'XAU/USD'),
            labelEn: g.symbol === 'XAU/USD' ? 'Spot Gold (Troy Oz)' : String(g.symbol),
            labelFa: g.symbol === 'XAU/USD' ? 'انس جهانی طلا' : String(g.symbol),
            market: g.market === 'iran' ? 'iran' : 'international',
            unit: String(g.unit || 'USD/oz'),
            price: Number(g.price || 0),
            change24hPct: Number(g.change24hPct || 0),
            status: (g.status as GoldPriceItem['status']) || 'live',
            source: String(g.source || 'External API'),
            updatedAt: String(g.updatedAt || new Date().toISOString()),
            isDemo: false,
          }))
        );
      }
      if (Array.isArray(data.currencyPrices)) {
        setApiCurrencyPrices(
          data.currencyPrices.map((c: Partial<CurrencyPriceItem>, idx: number) => ({
            id: `api-fx-${c.pair || idx}`,
            pair: String(c.pair || 'EUR/USD'),
            labelEn: String(c.pair || 'FX'),
            labelFa: String(c.pair || 'ارز'),
            rate: Number(c.rate || 0),
            change24hPct: Number(c.change24hPct || 0),
            status: (c.status as CurrencyPriceItem['status']) || 'live',
            source: String(c.source || 'External API'),
            updatedAt: String(c.updatedAt || new Date().toISOString()),
            isDemo: false,
          }))
        );
      }
    } catch {
      setMarketProviderStatus({
        configured: false,
        provider: 'none',
        status: 'unavailable',
        message: 'Failed to reach market data adapter endpoint.',
      });
    }
  }, []);

  // Boot: test Firestore connection & initial market fetch
  useEffect(() => {
    void testConnection();
    void refreshMarketSnapshot();
  }, [refreshMarketSnapshot]);

  // Public Firestore listeners (gold_prices, currency_prices, jewelry_models, market_history, application_settings)
  useEffect(() => {
    const unsubGold = onSnapshot(
      collection(db, 'gold_prices'),
      (snap) => {
        const list: GoldPriceItem[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            symbol: String(data.symbol || d.id),
            labelEn: String(data.symbol || d.id),
            labelFa: String(data.symbol || d.id),
            market: data.market === 'international' ? 'international' : 'iran',
            unit: String(data.unit || 'IRR/g'),
            price: Number(data.price || 0),
            change24hPct: Number(data.change24hPct || 0),
            status: (data.status as GoldPriceItem['status']) || 'manual',
            source: String(data.source || 'Admin Entry'),
            updatedBy: data.updatedBy ? String(data.updatedBy) : undefined,
            updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate().toISOString() : new Date().toISOString(),
            isDemo: false,
          };
        });
        setManualGoldPrices(list);
      },
      (err) => console.warn('gold_prices listener:', err.message)
    );

    const unsubFx = onSnapshot(
      collection(db, 'currency_prices'),
      (snap) => {
        const list: CurrencyPriceItem[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            pair: String(data.pair || d.id),
            labelEn: String(data.pair || d.id),
            labelFa: String(data.pair || d.id),
            rate: Number(data.rate || 0),
            change24hPct: Number(data.change24hPct || 0),
            status: (data.status as CurrencyPriceItem['status']) || 'manual',
            source: String(data.source || 'Admin Entry'),
            updatedBy: data.updatedBy ? String(data.updatedBy) : undefined,
            updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate().toISOString() : new Date().toISOString(),
            isDemo: false,
          };
        });
        setManualCurrencyPrices(list);
      },
      (err) => console.warn('currency_prices listener:', err.message)
    );

    const unsubModels = onSnapshot(
      collection(db, 'jewelry_models'),
      (snap) => {
        const list: JewelryModel[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            nameEn: String(data.nameEn || ''),
            nameFa: String(data.nameFa || ''),
            categoryId: data.categoryId || 'rings',
            descriptionEn: String(data.descriptionEn || ''),
            descriptionFa: String(data.descriptionFa || ''),
            imageUrl: String(data.imageUrl || ''),
            minWeightGrams: Number(data.minWeightGrams || 1),
            maxWeightGrams: Number(data.maxWeightGrams || 5),
            purityKarat: Number(data.purityKarat || 18),
            laborFeePct: Number(data.laborFeePct || 10),
            additionalCostPerUnit: Number(data.additionalCostPerUnit || 0),
            productionHours: Number(data.productionHours || 3),
            demandIndex: Number(data.demandIndex || 75),
            isActive: Boolean(data.isActive),
            isDemo: false,
          };
        });
        setFirestoreModels(list);
      },
      (err) => console.warn('jewelry_models listener:', err.message)
    );

    const unsubHistory = onSnapshot(
      collection(db, 'market_history'),
      (snap) => {
        const list: MarketHistoryPoint[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            symbol: String(data.symbol || 'IR18K'),
            dateLabel: String(data.dateLabel || ''),
            price: Number(data.price || 0),
            sourceType: (data.sourceType as MarketHistoryPoint['sourceType']) || 'manual',
          };
        });
        setFirestoreHistory(list);
      },
      (err) => console.warn('market_history listener:', err.message)
    );

    const unsubSettings = onSnapshot(
      doc(db, 'application_settings', 'global'),
      (snap) => {
        if (snap.exists()) {
          const data = snap.data();
          setAppSettings({
            defaultLossPct: Number(data.defaultLossPct ?? DEFAULT_APP_SETTINGS.defaultLossPct),
            recoverableScrapPct: Number(data.recoverableScrapPct ?? DEFAULT_APP_SETTINGS.recoverableScrapPct),
            proMonthlyIrr: Number(data.proMonthlyIrr ?? DEFAULT_APP_SETTINGS.proMonthlyIrr),
            proAnnualIrr: Number(data.proAnnualIrr ?? DEFAULT_APP_SETTINGS.proAnnualIrr),
            proMonthlyUsd: Number(data.proMonthlyUsd ?? DEFAULT_APP_SETTINGS.proMonthlyUsd),
            proAnnualUsd: Number(data.proAnnualUsd ?? DEFAULT_APP_SETTINGS.proAnnualUsd),
            demoModeEnabled: Boolean(data.demoModeEnabled ?? true),
          });
        }
      },
      (err) => console.warn('application_settings listener:', err.message)
    );

    return () => {
      unsubGold();
      unsubFx();
      unsubModels();
      unsubHistory();
      unsubSettings();
    };
  }, []);

  // Auth state & user bootstrap
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      setAuthReady(true);

      if (!firebaseUser) {
        setUserRole('guest');
        setSubscriptionTier('free');
        setInventory(null);
        setInventoryTx([]);
        setScrapRecords([]);
        setReturnedGold([]);
        setSalesRecords([]);
        setSavedPlans([]);
        setPayments([]);
        setTickets([]);
        return;
      }

      const emailLower = (firebaseUser.email || '').toLowerCase();
      const isBootstrappedAdmin =
        firebaseUser.emailVerified && BOOTSTRAPPED_ADMIN_EMAILS.includes(emailLower);

      if (firebaseUser.emailVerified) {
        try {
          const userRef = doc(db, 'users', firebaseUser.uid);
          const snap = await getDoc(userRef);
          if (!snap.exists()) {
            const initialRole: UserRole = isBootstrappedAdmin ? 'super_admin' : 'free';
            await setDoc(userRef, {
              uid: firebaseUser.uid,
              displayName: firebaseUser.displayName || emailLower.split('@')[0] || 'UMA Member',
              role: initialRole,
              subscriptionTier: isBootstrappedAdmin ? 'organization' : 'free',
              language: lang,
              status: 'active',
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
            await setDoc(doc(db, 'user_profiles', firebaseUser.uid), {
              ownerId: firebaseUser.uid,
              email: firebaseUser.email || '',
              phone: '',
              workshopName: '',
              city: '',
              businessType: 'workshop',
              updatedAt: serverTimestamp(),
            });
            setUserRole(initialRole);
            setSubscriptionTier(isBootstrappedAdmin ? 'organization' : 'free');
          } else {
            const data = snap.data();
            const resolvedRole: UserRole = isBootstrappedAdmin ? 'super_admin' : (data.role || 'free');
            setUserRole(resolvedRole);
            setSubscriptionTier(data.subscriptionTier || 'free');
          }
        } catch (err) {
          console.warn('User profile bootstrap note:', err);
          if (isBootstrappedAdmin) {
            setUserRole('super_admin');
            setSubscriptionTier('organization');
          } else {
            setUserRole('free');
          }
        }
      } else {
        setUserRole('free');
      }
    });
    return () => unsub();
  }, [lang]);

  // Private user-isolated Firestore listeners (only attached when authReady && verified user)
  useEffect(() => {
    if (!authReady || !user || !user.emailVerified) return;
    const uid = user.uid;

    const unsubInv = onSnapshot(
      doc(db, 'inventory', uid),
      (snap) => {
        if (snap.exists()) {
          const d = snap.data();
          setInventory({
            ownerId: String(d.ownerId),
            meltedGoldGrams: Number(d.meltedGoldGrams || 0),
            meltedPurityPerMille: Number(d.meltedPurityPerMille || 750),
            scrapGoldGrams: Number(d.scrapGoldGrams || 0),
            returnedGoldGrams: Number(d.returnedGoldGrams || 0),
            updatedAt: d.updatedAt?.toDate ? d.updatedAt.toDate().toISOString() : new Date().toISOString(),
          });
        } else {
          setInventory({
            ownerId: uid,
            meltedGoldGrams: 0,
            meltedPurityPerMille: 750,
            scrapGoldGrams: 0,
            returnedGoldGrams: 0,
            updatedAt: new Date().toISOString(),
          });
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `inventory/${uid}`)
    );

    const unsubTx = onSnapshot(
      query(collection(db, 'inventory_transactions'), where('ownerId', '==', uid), orderBy('createdAt', 'desc')),
      (snap) => {
        setInventoryTx(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              ownerId: String(data.ownerId),
              txType: data.txType,
              grossGrams: Number(data.grossGrams || 0),
              purityPerMille: Number(data.purityPerMille || 750),
              fineGoldGrams: Number(data.fineGoldGrams || 0),
              note: String(data.note || ''),
              createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'inventory_transactions')
    );

    const unsubScrap = onSnapshot(
      query(collection(db, 'scrap_records'), where('ownerId', '==', uid), orderBy('createdAt', 'desc')),
      (snap) => {
        setScrapRecords(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              ownerId: String(data.ownerId),
              sourceLabel: String(data.sourceLabel || ''),
              grossGrams: Number(data.grossGrams || 0),
              purityPerMille: Number(data.purityPerMille || 750),
              estimatedRecoveryPct: Number(data.estimatedRecoveryPct || 95),
              status: data.status || 'stored',
              createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'scrap_records')
    );

    const unsubReturned = onSnapshot(
      query(collection(db, 'returned_gold'), where('ownerId', '==', uid), orderBy('createdAt', 'desc')),
      (snap) => {
        setReturnedGold(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              ownerId: String(data.ownerId),
              itemLabel: String(data.itemLabel || ''),
              grossGrams: Number(data.grossGrams || 0),
              purityPerMille: Number(data.purityPerMille || 750),
              condition: data.condition || 'reusable',
              createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'returned_gold')
    );

    const unsubSales = onSnapshot(
      query(collection(db, 'sales_records'), where('ownerId', '==', uid), orderBy('createdAt', 'desc')),
      (snap) => {
        setSalesRecords(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              ownerId: String(data.ownerId),
              categoryId: data.categoryId || 'rings',
              modelName: String(data.modelName || ''),
              unitsSold: Number(data.unitsSold || 1),
              totalWeightGrams: Number(data.totalWeightGrams || 0),
              saleDate: String(data.saleDate || ''),
              isDemo: Boolean(data.isDemo),
              createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'sales_records')
    );

    const unsubPlans = onSnapshot(
      query(collection(db, 'production_plans'), where('ownerId', '==', uid), orderBy('createdAt', 'desc')),
      (snap) => {
        setSavedPlans(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              ownerId: String(data.ownerId),
              title: String(data.title || ''),
              availableMeltedGrams: Number(data.availableMeltedGrams || 0),
              meltedPurity: Number(data.meltedPurity || 750),
              budget: Number(data.budget || 0),
              totalGoldUsedGrams: Number(data.totalGoldUsedGrams || 0),
              estimatedProfit: Number(data.estimatedProfit || 0),
              riskLevel: data.riskLevel || 'medium',
              summary: String(data.summary || ''),
              createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'production_plans')
    );

    const unsubPayments = onSnapshot(
      query(collection(db, 'payments'), where('ownerId', '==', uid), orderBy('createdAt', 'desc')),
      (snap) => {
        setPayments(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              ownerId: String(data.ownerId),
              planId: data.planId || 'pro',
              billingCycle: data.billingCycle || 'monthly',
              amount: Number(data.amount || 0),
              currency: data.currency || 'IRR',
              gateway: data.gateway || 'zarinpal',
              authority: data.authority ? String(data.authority) : undefined,
              refId: data.refId ? String(data.refId) : undefined,
              status: data.status || 'pending',
              isTestMode: Boolean(data.isTestMode),
              createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'payments')
    );

    const unsubTickets = onSnapshot(
      query(collection(db, 'support_tickets'), where('ownerId', '==', uid), orderBy('createdAt', 'desc')),
      (snap) => {
        setTickets(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              ownerId: String(data.ownerId),
              subject: String(data.subject || ''),
              category: data.category || 'general',
              priority: data.priority || 'medium',
              status: data.status || 'open',
              createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
              updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate().toISOString() : new Date().toISOString(),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'support_tickets')
    );

    return () => {
      unsubInv();
      unsubTx();
      unsubScrap();
      unsubReturned();
      unsubSales();
      unsubPlans();
      unsubPayments();
      unsubTickets();
    };
  }, [authReady, user]);

  // Auth actions
  const signInGoogle = useCallback(async () => {
    await signInWithPopup(auth, googleProvider);
    pushToast('success', lang === 'fa' ? 'ورود با حساب گوگل انجام شد.' : 'Signed in with Google.');
  }, [lang, pushToast]);

  const signInEmail = useCallback(
    async (email: string, pass: string) => {
      await signInWithEmailAndPassword(auth, email, pass);
      pushToast('success', lang === 'fa' ? 'خوش آمدید.' : 'Signed in successfully.');
    },
    [lang, pushToast]
  );

  const registerEmail = useCallback(
    async (name: string, email: string, pass: string) => {
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      await updateProfile(cred.user, { displayName: name });
      await sendEmailVerification(cred.user);
      pushToast(
        'info',
        lang === 'fa'
          ? 'حساب ایجاد شد. لینک تایید ایمیل برای شما ارسال گردید.'
          : 'Account created. Verification email sent—please verify your inbox.'
      );
    },
    [lang, pushToast]
  );

  const resendVerification = useCallback(async () => {
    if (auth.currentUser) {
      await sendEmailVerification(auth.currentUser);
      pushToast('info', lang === 'fa' ? 'ایمیل تایید مجدداً ارسال شد.' : 'Verification email re-sent.');
    }
  }, [lang, pushToast]);

  const resetPassword = useCallback(
    async (email: string) => {
      await sendPasswordResetEmail(auth, email);
      pushToast('success', lang === 'fa' ? 'لینک بازیابی رمز عبور ارسال شد.' : 'Password reset email sent.');
    },
    [lang, pushToast]
  );

  const logout = useCallback(async () => {
    await signOut(auth);
    pushToast('info', lang === 'fa' ? 'از حساب خود خارج شدید.' : 'Signed out.');
    navigate('landing');
  }, [lang, navigate, pushToast]);

  const getAuthToken = useCallback(async () => {
    if (!auth.currentUser) throw new Error('Not signed in');
    return auth.currentUser.getIdToken(true);
  }, []);

  // Combine Real API + Manual Admin Overrides + Demo Mode (explicitly separated)
  const goldPrices = useMemo<GoldPriceItem[]>(() => {
    const merged = new Map<string, GoldPriceItem>();
    if (demoMode) {
      for (const item of DEMO_GOLD_PRICES) merged.set(item.symbol, item);
    }
    for (const item of apiGoldPrices) merged.set(item.symbol, item);
    for (const item of manualGoldPrices) merged.set(item.symbol, item);
    return Array.from(merged.values());
  }, [apiGoldPrices, manualGoldPrices, demoMode]);

  const currencyPrices = useMemo<CurrencyPriceItem[]>(() => {
    const merged = new Map<string, CurrencyPriceItem>();
    if (demoMode) {
      for (const item of DEMO_CURRENCY_PRICES) merged.set(item.pair, item);
    }
    for (const item of apiCurrencyPrices) merged.set(item.pair, item);
    for (const item of manualCurrencyPrices) merged.set(item.pair, item);
    return Array.from(merged.values());
  }, [apiCurrencyPrices, manualCurrencyPrices, demoMode]);

  const marketHistory = useMemo<MarketHistoryPoint[]>(() => {
    if (firestoreHistory.length > 0) return firestoreHistory;
    return demoMode ? DEMO_MARKET_HISTORY : [];
  }, [firestoreHistory, demoMode]);

  const catalogModels = useMemo<JewelryModel[]>(() => {
    if (firestoreModels.length > 0) return firestoreModels;
    return DEMO_JEWELRY_MODELS;
  }, [firestoreModels]);

  const isAdmin = useMemo(() => {
    if (!user || !user.emailVerified) return false;
    if (BOOTSTRAPPED_ADMIN_EMAILS.includes((user.email || '').toLowerCase())) return true;
    return userRole === 'admin' || userRole === 'super_admin';
  }, [user, userRole]);

  const isSupportOrAdmin = useMemo(() => {
    if (isAdmin) return true;
    return Boolean(user?.emailVerified && userRole === 'support_agent');
  }, [isAdmin, user, userRole]);

  const value: AppContextValue = {
    lang,
    setLang,
    route,
    navigate,
    user,
    authReady,
    userRole,
    subscriptionTier,
    isAdmin,
    isSupportOrAdmin,
    isVerified: Boolean(user?.emailVerified),
    signInGoogle,
    signInEmail,
    registerEmail,
    resendVerification,
    resetPassword,
    logout,
    goldPrices,
    currencyPrices,
    marketHistory,
    marketProviderStatus,
    refreshMarketSnapshot,
    demoMode,
    setDemoMode,
    catalogModels,
    appSettings,
    inventory,
    inventoryTx,
    scrapRecords,
    returnedGold,
    salesRecords,
    savedPlans,
    payments,
    tickets,
    toasts,
    pushToast,
    dismissToast,
    getAuthToken,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
