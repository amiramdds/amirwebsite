import {
  AppSettings,
  CurrencyPriceItem,
  GoldPriceItem,
  JewelryCategory,
  JewelryModel,
  MarketHistoryPoint,
} from '../types/domain';

export const GENERATED_IMAGES = {
  heroAtelier: '/src/assets/images/hero_gold_atelier_1795297858753.jpg',
  ring: '/src/assets/images/model_imperial_ring_1795297857877.jpg',
  bangle: '/src/assets/images/model_persian_bangle_1795297857798.jpg',
  necklace: '/src/assets/images/model_heritage_necklace_1795297857845.jpg',
  earrings: '/src/assets/images/model_atelier_earrings_1795297857718.jpg',
};

export const JEWELRY_CATEGORIES: JewelryCategory[] = [
  { id: 'rings', slug: 'rings', nameEn: 'Rings', nameFa: 'انگشتر', sortOrder: 1 },
  { id: 'bracelets', slug: 'bracelets', nameEn: 'Bracelets', nameFa: 'دستبند', sortOrder: 2 },
  { id: 'bangles', slug: 'bangles', nameEn: 'Bangles', nameFa: 'النگو', sortOrder: 3 },
  { id: 'chains', slug: 'chains', nameEn: 'Chains', nameFa: 'زنجیر', sortOrder: 4 },
  { id: 'necklaces', slug: 'necklaces', nameEn: 'Necklaces', nameFa: 'گردنبند', sortOrder: 5 },
  { id: 'earrings', slug: 'earrings', nameEn: 'Earrings', nameFa: 'گوشواره', sortOrder: 6 },
  { id: 'pendants', slug: 'pendants', nameEn: 'Pendants', nameFa: 'پلاک و آویز', sortOrder: 7 },
  { id: 'jewelry_sets', slug: 'jewelry_sets', nameEn: 'Jewelry Sets', nameFa: 'سرویس و نیم‌ست', sortOrder: 8 },
];

export const DEFAULT_APP_SETTINGS: AppSettings = {
  defaultLossPct: 1.5,
  recoverableScrapPct: 4.0,
  proMonthlyIrr: 18500000,
  proAnnualIrr: 175000000,
  proMonthlyUsd: 39,
  proAnnualUsd: 390,
  demoModeEnabled: true,
};

/**
 * DEMO / EVALUATION MARKET DATASET
 * Strictly isolated from live feeds and always labeled as Demo Evaluation Data.
 */
export const DEMO_GOLD_PRICES: GoldPriceItem[] = [
  {
    id: 'demo-iran-18k',
    symbol: 'IR18K',
    labelEn: '18K Gold (Gram)',
    labelFa: 'طلای ۱۸ عیار (هر گرم)',
    market: 'iran',
    unit: 'IRR/g',
    price: 46850000,
    change24hPct: 1.42,
    status: 'delayed',
    source: 'Demo Evaluation Feed',
    updatedAt: '2026-11-21T13:30:00Z',
    isDemo: true,
  },
  {
    id: 'demo-iran-24k',
    symbol: 'IR24K',
    labelEn: '24K Gold (Gram)',
    labelFa: 'طلای ۲۴ عیار (هر گرم)',
    market: 'iran',
    unit: 'IRR/g',
    price: 62466000,
    change24hPct: 1.38,
    status: 'delayed',
    source: 'Demo Evaluation Feed',
    updatedAt: '2026-11-21T13:30:00Z',
    isDemo: true,
  },
  {
    id: 'demo-iran-melted',
    symbol: 'MELTED',
    labelEn: 'Melted Gold (750 Base)',
    labelFa: 'طلای آب‌شده (پایه ۷۵۰)',
    market: 'iran',
    unit: 'IRR/g',
    price: 46520000,
    change24hPct: 1.15,
    status: 'delayed',
    source: 'Demo Evaluation Feed',
    updatedAt: '2026-11-21T13:30:00Z',
    isDemo: true,
  },
  {
    id: 'demo-iran-mithqal',
    symbol: 'MITHQAL',
    labelEn: 'Iranian Mithqal (4.608g)',
    labelFa: 'مثقال طلای آب‌شده',
    market: 'iran',
    unit: 'IRR/mithqal',
    price: 202950000,
    change24hPct: 1.24,
    status: 'delayed',
    source: 'Demo Evaluation Feed',
    updatedAt: '2026-11-21T13:30:00Z',
    isDemo: true,
  },
  {
    id: 'demo-iran-emami',
    symbol: 'EMAMI',
    labelEn: 'Emami Gold Coin',
    labelFa: 'سکه امامی (طرح جدید)',
    market: 'iran',
    unit: 'IRR/coin',
    price: 534000000,
    change24hPct: 2.05,
    status: 'delayed',
    source: 'Demo Evaluation Feed',
    updatedAt: '2026-11-21T13:30:00Z',
    isDemo: true,
  },
  {
    id: 'demo-iran-half',
    symbol: 'HALF_COIN',
    labelEn: 'Half Bahar Azadi Coin',
    labelFa: 'نیم‌سکه بهار آزادی',
    market: 'iran',
    unit: 'IRR/coin',
    price: 286000000,
    change24hPct: 0.92,
    status: 'delayed',
    source: 'Demo Evaluation Feed',
    updatedAt: '2026-11-21T13:30:00Z',
    isDemo: true,
  },
  {
    id: 'demo-intl-xauusd',
    symbol: 'XAU/USD',
    labelEn: 'Spot Gold (Troy Oz)',
    labelFa: 'انس جهانی طلا',
    market: 'international',
    unit: 'USD/oz',
    price: 2684.5,
    change24hPct: 0.64,
    status: 'delayed',
    source: 'Demo Evaluation Feed',
    updatedAt: '2026-11-21T13:30:00Z',
    isDemo: true,
  },
  {
    id: 'demo-intl-xaugram',
    symbol: 'XAU_G_USD',
    labelEn: 'International 24K (Gram)',
    labelFa: 'طلای ۲۴ عیار جهانی (گرم)',
    market: 'international',
    unit: 'USD/g',
    price: 86.31,
    change24hPct: 0.64,
    status: 'delayed',
    source: 'Demo Evaluation Feed',
    updatedAt: '2026-11-21T13:30:00Z',
    isDemo: true,
  },
];

export const DEMO_CURRENCY_PRICES: CurrencyPriceItem[] = [
  {
    id: 'demo-fx-usdirr',
    pair: 'USD/IRR',
    labelEn: 'US Dollar / Iranian Rial',
    labelFa: 'دلار آمریکا / ریال',
    rate: 712000,
    change24hPct: 0.78,
    status: 'delayed',
    source: 'Demo Evaluation Feed',
    updatedAt: '2026-11-21T13:30:00Z',
    isDemo: true,
  },
  {
    id: 'demo-fx-eurirr',
    pair: 'EUR/IRR',
    labelEn: 'Euro / Iranian Rial',
    labelFa: 'یورو / ریال',
    rate: 758500,
    change24hPct: 0.52,
    status: 'delayed',
    source: 'Demo Evaluation Feed',
    updatedAt: '2026-11-21T13:30:00Z',
    isDemo: true,
  },
  {
    id: 'demo-fx-aedirr',
    pair: 'AED/IRR',
    labelEn: 'UAE Dirham / Iranian Rial',
    labelFa: 'درهم امارات / ریال',
    rate: 193900,
    change24hPct: 0.61,
    status: 'delayed',
    source: 'Demo Evaluation Feed',
    updatedAt: '2026-11-21T13:30:00Z',
    isDemo: true,
  },
  {
    id: 'demo-fx-eurusd',
    pair: 'EUR/USD',
    labelEn: 'Euro / US Dollar',
    labelFa: 'یورو / دلار آمریکا',
    rate: 1.0652,
    change24hPct: -0.18,
    status: 'delayed',
    source: 'Demo Evaluation Feed',
    updatedAt: '2026-11-21T13:30:00Z',
    isDemo: true,
  },
];

export const DEMO_MARKET_HISTORY: MarketHistoryPoint[] = [
  { id: 'h1', symbol: 'IR18K', dateLabel: 'D-13', price: 43200000, sourceType: 'demo' },
  { id: 'h2', symbol: 'IR18K', dateLabel: 'D-12', price: 43550000, sourceType: 'demo' },
  { id: 'h3', symbol: 'IR18K', dateLabel: 'D-11', price: 43900000, sourceType: 'demo' },
  { id: 'h4', symbol: 'IR18K', dateLabel: 'D-10', price: 43650000, sourceType: 'demo' },
  { id: 'h5', symbol: 'IR18K', dateLabel: 'D-09', price: 44150000, sourceType: 'demo' },
  { id: 'h6', symbol: 'IR18K', dateLabel: 'D-08', price: 44800000, sourceType: 'demo' },
  { id: 'h7', symbol: 'IR18K', dateLabel: 'D-07', price: 44600000, sourceType: 'demo' },
  { id: 'h8', symbol: 'IR18K', dateLabel: 'D-06', price: 45100000, sourceType: 'demo' },
  { id: 'h9', symbol: 'IR18K', dateLabel: 'D-05', price: 45450000, sourceType: 'demo' },
  { id: 'h10', symbol: 'IR18K', dateLabel: 'D-04', price: 45800000, sourceType: 'demo' },
  { id: 'h11', symbol: 'IR18K', dateLabel: 'D-03', price: 46100000, sourceType: 'demo' },
  { id: 'h12', symbol: 'IR18K', dateLabel: 'D-02', price: 46200000, sourceType: 'demo' },
  { id: 'h13', symbol: 'IR18K', dateLabel: 'D-01', price: 46550000, sourceType: 'demo' },
  { id: 'h14', symbol: 'IR18K', dateLabel: 'Today', price: 46850000, sourceType: 'demo' },
  { id: 'x1', symbol: 'XAU/USD', dateLabel: 'D-13', price: 2592, sourceType: 'demo' },
  { id: 'x2', symbol: 'XAU/USD', dateLabel: 'D-12', price: 2605, sourceType: 'demo' },
  { id: 'x3', symbol: 'XAU/USD', dateLabel: 'D-11', price: 2618, sourceType: 'demo' },
  { id: 'x4', symbol: 'XAU/USD', dateLabel: 'D-10', price: 2610, sourceType: 'demo' },
  { id: 'x5', symbol: 'XAU/USD', dateLabel: 'D-09', price: 2624, sourceType: 'demo' },
  { id: 'x6', symbol: 'XAU/USD', dateLabel: 'D-08', price: 2641, sourceType: 'demo' },
  { id: 'x7', symbol: 'XAU/USD', dateLabel: 'D-07', price: 2635, sourceType: 'demo' },
  { id: 'x8', symbol: 'XAU/USD', dateLabel: 'D-06', price: 2648, sourceType: 'demo' },
  { id: 'x9', symbol: 'XAU/USD', dateLabel: 'D-05', price: 2655, sourceType: 'demo' },
  { id: 'x10', symbol: 'XAU/USD', dateLabel: 'D-04', price: 2662, sourceType: 'demo' },
  { id: 'x11', symbol: 'XAU/USD', dateLabel: 'D-03', price: 2670, sourceType: 'demo' },
  { id: 'x12', symbol: 'XAU/USD', dateLabel: 'D-02', price: 2668, sourceType: 'demo' },
  { id: 'x13', symbol: 'XAU/USD', dateLabel: 'D-01', price: 2679, sourceType: 'demo' },
  { id: 'x14', symbol: 'XAU/USD', dateLabel: 'Today', price: 2684.5, sourceType: 'demo' },
];

export const DEMO_JEWELRY_MODELS: JewelryModel[] = [
  {
    id: 'uma-ring-octa',
    nameEn: 'Octagon Filigree Signet Ring',
    nameFa: 'انگشتر مُهردار هشت‌ضلعی فیلیگری',
    categoryId: 'rings',
    descriptionEn: 'Architectural 18K signet ring balancing crisp bevels with low-weight hollow gallery.',
    descriptionFa: 'انگشتر مهندسی‌شده ۱۸ عیار با تراش هشت‌ضلعی و وزن بهینه برای گردش سرمایه سریع.',
    imageUrl: GENERATED_IMAGES.ring,
    minWeightGrams: 3.2,
    maxWeightGrams: 6.4,
    purityKarat: 18,
    laborFeePct: 14,
    additionalCostPerUnit: 4500000,
    productionHours: 5.5,
    demandIndex: 84,
    isActive: true,
    isDemo: true,
  },
  {
    id: 'uma-bangle-mirror',
    nameEn: 'Damascus Diamond-Cut Bangle Pair',
    nameFa: 'النگو آینه‌ای و تراش الماسی',
    categoryId: 'bangles',
    descriptionEn: 'High-liquidity retail bangle pair combining mirror polish with CNC diamond-cut facets.',
    descriptionFa: 'جفت النگو پرفروش ویترین با پرداخت آینه‌ای و تراش CNC الماسی.',
    imageUrl: GENERATED_IMAGES.bangle,
    minWeightGrams: 6.5,
    maxWeightGrams: 12.0,
    purityKarat: 18,
    laborFeePct: 9.5,
    additionalCostPerUnit: 2200000,
    productionHours: 3.5,
    demandIndex: 91,
    isActive: true,
    isDemo: true,
  },
  {
    id: 'uma-necklace-herringbone',
    nameEn: 'Imperial Herringbone Medallion',
    nameFa: 'گردنبند هرینگ‌بون با مدالیون دایره‌ای',
    categoryId: 'necklaces',
    descriptionEn: 'Fluid 18K flat-link herringbone collar paired with a brushed-edge disc pendant.',
    descriptionFa: 'گردنبند تخت هرینگ‌بون ۱۸ عیار همراه با مدال صیقلی کلاسیک.',
    imageUrl: GENERATED_IMAGES.necklace,
    minWeightGrams: 7.0,
    maxWeightGrams: 14.5,
    purityKarat: 18,
    laborFeePct: 13,
    additionalCostPerUnit: 3800000,
    productionHours: 6.5,
    demandIndex: 79,
    isActive: true,
    isDemo: true,
  },
  {
    id: 'uma-earrings-hex',
    nameEn: 'Hexagonal Geometric Drop Earrings',
    nameFa: 'گوشواره هندسی شش‌ضلعی آویز',
    categoryId: 'earrings',
    descriptionEn: 'Lightweight precision-cast geometric hoops and articulated drop studs.',
    descriptionFa: 'گوشواره سبک ریخته‌گری دقیق با ساختار هندسی و تقاضای بالا در رده هدیه.',
    imageUrl: GENERATED_IMAGES.earrings,
    minWeightGrams: 2.6,
    maxWeightGrams: 4.8,
    purityKarat: 18,
    laborFeePct: 16,
    additionalCostPerUnit: 3100000,
    productionHours: 4.0,
    demandIndex: 82,
    isActive: true,
    isDemo: true,
  },
  {
    id: 'uma-bracelet-cartier',
    nameEn: 'Atelier Link Cuff Bracelet',
    nameFa: 'دستبند زنجیری کاف آتلیه',
    categoryId: 'bracelets',
    descriptionEn: 'Versatile unisex link bracelet calibrated for 4.5g–8.5g workshop batches.',
    descriptionFa: 'دستبند زنجیری پرکاربرد کالیبره‌شده برای تولید سری در وزن‌های ۴.۵ تا ۸.۵ گرم.',
    imageUrl: GENERATED_IMAGES.bangle,
    minWeightGrams: 4.5,
    maxWeightGrams: 8.5,
    purityKarat: 18,
    laborFeePct: 11.5,
    additionalCostPerUnit: 2500000,
    productionHours: 4.2,
    demandIndex: 87,
    isActive: true,
    isDemo: true,
  },
  {
    id: 'uma-chain-box',
    nameEn: 'Venetian Box-Link Chain 45cm',
    nameFa: 'زنجیر ونیزی ۴۵ سانتی‌متری',
    categoryId: 'chains',
    descriptionEn: 'Durable everyday 18K chain with ultra-low manufacturing loss and rapid wholesale turnover.',
    descriptionFa: 'زنجیر روزمره بادوام ۱۸ عیار با کمترین پرت ساخت و سرعت فروش عمده بالا.',
    imageUrl: GENERATED_IMAGES.necklace,
    minWeightGrams: 2.4,
    maxWeightGrams: 5.5,
    purityKarat: 18,
    laborFeePct: 8.5,
    additionalCostPerUnit: 1200000,
    productionHours: 2.5,
    demandIndex: 89,
    isActive: true,
    isDemo: true,
  },
  {
    id: 'uma-pendant-coin',
    nameEn: 'Minimalist Disc Engraved Pendant',
    nameFa: 'پلاک دایره‌ای مینیمال حکاکی',
    categoryId: 'pendants',
    descriptionEn: 'Entry-weight gift pendant optimized for high unit velocity during seasonal peaks.',
    descriptionFa: 'پلاک سبک هدیه‌ای بهینه‌شده برای فروش تیراژ بالا در مناسبت‌ها.',
    imageUrl: GENERATED_IMAGES.necklace,
    minWeightGrams: 1.4,
    maxWeightGrams: 3.1,
    purityKarat: 18,
    laborFeePct: 15,
    additionalCostPerUnit: 1600000,
    productionHours: 2.0,
    demandIndex: 86,
    isActive: true,
    isDemo: true,
  },
  {
    id: 'uma-set-bridal',
    nameEn: 'Royal Meridian Demi-Set',
    nameFa: 'نیم‌ست رویال مریدین',
    categoryId: 'jewelry_sets',
    descriptionEn: 'Matched pendant and geometric drop earrings crafted for bridal & luxury gifting.',
    descriptionFa: 'نیم‌ست هماهنگ گردنبند و گوشواره مناسب هدیه‌های لوکس و مراسم.',
    imageUrl: GENERATED_IMAGES.earrings,
    minWeightGrams: 9.5,
    maxWeightGrams: 18.0,
    purityKarat: 18,
    laborFeePct: 14.5,
    additionalCostPerUnit: 6800000,
    productionHours: 9.0,
    demandIndex: 73,
    isActive: true,
    isDemo: true,
  },
];

export const DEFAULT_LEGAL_DOCS = {
  privacy: {
    slug: 'privacy' as const,
    titleEn: 'Privacy Policy',
    titleFa: 'سیاست حفظ حریم خصوصی',
    bodyEn: `UMA Gold ("we", "our") respects the confidentiality of every goldsmith, retailer, and bullion participant.

1. Strict Financial & Inventory Isolation
All melted gold balances, scrap weights, returned gold logs, sales records, and production plans are stored under strict user-isolated access rules. No other platform subscriber or visitor can read or list your workshop inventory or financial figures.

2. Authentication & Verification
Account access relies on Firebase Authentication (Google Sign-In or verified Email/Password). Email verification is enforced before sensitive workspace mutations are accepted.

3. Contact & Data Erasure
You may export your workshop data or initiate permanent account deletion from Profile & Settings at any time. Support inquiries: amirhossinbasirpor@gmail.com.`,
    bodyFa: `پلتفرم UMA Gold متعهد به حفظ محرمانگی اطلاعات مالی، موجودی طلای آب‌شده و داده‌های کارگاهی کاربران است.

۱. جداسازی کامل داده‌های مالی و موجودی
تمامی موجودی‌های طلای آب‌شده، ضایعات، طلای مرجوعی، سوابق فروش و برنامه‌های تولید با قوانین امنیتی سخت‌گیرانه ایزوله شده و صرفاً در اختیار مالک حساب و مدیران مجاز قرار دارد.

۲. احراز هویت امن
ورود از طریق Firebase Authentication (ورود با گوگل یا ایمیل تاییدشده) انجام می‌شود و پیش از تغییر داده‌های حساس، تایید ایمیل الزامی است.

۳. درخواست حذف حساب و پشتیبانی
امکان حذف حساب کاربری از بخش تنظیمات پروفایل فراهم است. ایمیل پشتیبانی: amirhossinbasirpor@gmail.com.`,
  },
  terms: {
    slug: 'terms' as const,
    titleEn: 'Terms & Conditions',
    titleFa: 'شرایط و قوانین استفاده',
    bodyEn: `Welcome to UMA Gold, owned and operated by amiruma.

1. Scope of Service
UMA Gold provides gold market analytics, deterministic purity/loss calculators, workshop inventory tracking, and AI-assisted jewelry production planning.

2. Market Data Attribution
Prices displayed in UMA Gold are marked as Live, Delayed, Manual Admin Entry, or Unavailable. Demo evaluation feeds are clearly flagged and must not be treated as live execution quotes.

3. Acceptable Use
Automated scraping, unauthorized privilege escalation, or manipulation of payment callbacks is strictly prohibited and logged in our security audit trail.`,
    bodyFa: `به پلتفرم UMA Gold (متعلق به amiruma) خوش آمدید.

۱. محدوده خدمات
UMA Gold ابزارهای تحلیل بازار طلا، ماشین‌حساب عیار و پرت ساخت، مدیریت موجودی و برنامه‌ریزی تولید هوشمند را ارائه می‌دهد.

۲. شفافیت منبع قیمت‌ها
وضعیت هر قیمت به‌صورت واضح (لحظه‌ای، تاخیری، ثبت دستی مدیر یا در دسترس نیست) نمایش داده می‌شود. داده‌های دمو صرفاً جهت ارزیابی است و جایگزین نرخ معامله واقعی نیست.

۳. استفاده مجاز
هرگونه تلاش برای دسترسی غیرمجاز به داده‌های سایر کاربران یا دستکاری تراکنش‌های پرداخت ممنوع بوده و در گزارش ممیزی ثبت می‌شود.`,
  },
  'subscription-refund': {
    slug: 'subscription-refund' as const,
    titleEn: 'Subscription & Refund Policy',
    titleFa: 'قوانین اشتراک و بازگشت وجه',
    bodyEn: `1. Plans & Billing Cycles
UMA Gold offers Free, Professional (Monthly & Annual), and Organization tiers. Plan pricing is configurable by platform administrators and displayed transparently before checkout.

2. Server-Side Payment Verification
Paid subscriptions activate strictly after verified server-side confirmation from the payment gateway (Zarinpal or configured international provider). Duplicate callbacks are rejected.

3. Refund Eligibility
Annual or monthly Pro subscriptions may be reviewed for refund within 7 days of initial purchase if core platform services were unavailable. Submit refund requests via Support Tickets or amirhossinbasirpor@gmail.com.`,
    bodyFa: `۱. طرح‌های اشتراک
پلتفرم UMA Gold شامل طرح رایگان، حرفه‌ای (ماهانه و سالانه) و سازمانی است. تعرفه‌ها پیش از پرداخت به‌صورت شفاف نمایش داده می‌شوند.

۲. تایید سمت سرور
فعال‌سازی اشتراک پولی صرفاً پس از تایید قطعی تراکنش در سمت سرور درگاه پرداخت (زرین‌پال یا درگاه بین‌المللی) انجام می‌شود.

۳. شرایط بازگشت وجه
در صورت بروز خطای فنی در ارائه سرویس یا پرداخت تکراری، درخواست استرداد ظرف ۷ روز از طریق تیکت پشتیبانی یا ایمیل amirhossinbasirpor@gmail.com بررسی می‌شود.`,
  },
  'ai-disclaimer': {
    slug: 'ai-disclaimer' as const,
    titleEn: 'AI Prediction Disclaimer',
    titleFa: 'سلب مسئولیت پیش‌بینی‌های هوش مصنوعی',
    bodyEn: `1. Probabilistic Estimates Only
All market forecasts, jewelry category demand scores, and recommended production mixes generated by UMA Gold AI are probabilistic analytical estimates, NOT guaranteed financial, investment, or trading advice.

2. Data Sufficiency Dependency
Forecast reliability depends directly on verified market history and user-supplied sales records. When historical data is insufficient, UMA Gold lowers confidence scores and explicitly warns the user.

3. Final Workshop Responsibility
Gold retailers, manufacturers, and investors remain solely responsible for verifying spot prices, alloy tolerances, and capital risk prior to casting or purchasing bullion.`,
    bodyFa: `۱. برآوردهای احتمالی و غیرقطعی
تمامی پیش‌بینی‌های بازار، شاخص‌های تقاضا و پیشنهادهای مدل تولید ارائه‌شده توسط هوش مصنوعی UMA Gold صرفاً تحلیل‌های کمکی احتمالی هستند و به هیچ وجه مشاوره قطعی سرمایه‌گذاری یا تضمین سود نیستند.

۲. وابستگی به کفایت داده‌ها
دقت تحلیل به سوابق فروش واقعی ثبت‌شده توسط کاربر و تاریخچه معتبر بازار وابسته است. در صورت ناکافی بودن داده، ضریب اطمینان کاهش یافته و هشدار نمایش داده می‌شود.

۳. مسئولیت نهایی تصمیم‌گیری
مسئولیت بررسی نهایی نرخ‌های لحظه‌ای بازار، عیار دقیق و ریسک سرمایه پیش از ذوب یا تولید بر عهده کاربر است.`,
  },
};

export const DEFAULT_FAQS = [
  {
    id: 'faq-1',
    questionEn: 'How does UMA Gold separate recoverable scrap from permanent production loss?',
    questionFa: 'پلتفرم UMA Gold چگونه ضایعات قابل بازیافت را از پرت دائمی تولید تفکیک می‌کند؟',
    answerEn:
      'In both the Production Calculator and Inventory Ledger, filing/polishing recoverable scrap is tracked separately with its own purity and recovery percentage so it returns to your reusable stock, whereas permanent casting/burn-off loss is deducted from net yield.',
    answerFa:
      'در ماشین‌حساب تولید و دفتر موجودی، سوهان‌کاری و ضایعات قابل بازیافت با عیار و نرخ بازیابی مجزا ثبت شده و به موجودی قابل استفاده بازمی‌گردند؛ اما پرت دائمی ریخته‌گری از خالص تولید کسر می‌شود.',
  },
  {
    id: 'faq-2',
    questionEn: 'Where do Iranian and international gold prices come from?',
    questionFa: 'نرخ‌های بازار طلای ایران و انس جهانی چگونه تامین می‌شوند؟',
    answerEn:
      'UMA Gold supports configurable external API adapters (GoldAPI, Metals-API, TGJU, or custom feeds), manual audited updates by authorized administrators, and a clearly labeled Demo Evaluation mode when no external API key is connected.',
    answerFa:
      'پلتفرم از آداپتورهای قابل تنظیم API (مانند GoldAPI، Metals-API و TGJU)، ثبت دستی ممیزی‌شده توسط مدیر و حالت دمو با برچسب شفاف (در زمان عدم اتصال API) پشتیبانی می‌کند.',
  },
  {
    id: 'faq-3',
    questionEn: 'Can the AI Production Planner recommend more gold than I have in stock?',
    questionFa: 'آیا برنامه‌ریز تولید هوشمند ممکن است بیش از موجودی طلای آب‌شده من پیشنهاد دهد؟',
    answerEn:
      'No. The server-side optimization verifier converts your available melted gold and purity into maximum producible fine gold after accounting for loss rates, and enforces hard quantity caps so plans never exceed your physical gold or budget.',
    answerFa:
      'خیر. موتور بهینه‌سازی سمت سرور ابتدا طلای خالص قابل استحصال را پس از کسر نرخ پرت محاسبه کرده و سقف تعداد و وزن را به‌صورت قطعی محدود می‌کند تا هیچ طرحی از موجودی و بودجه شما فراتر نرود.',
  },
  {
    id: 'faq-4',
    questionEn: 'How can I contact UMA Gold support or request a refund?',
    questionFa: 'چگونه می‌توانم با پشتیبانی تماس بگیرم یا درخواست بازگشت وجه ثبت کنم؟',
    answerEn:
      'You can use Live Support Chat, submit a Support Ticket from the Support Center, or email our support desk directly at amirhossinbasirpor@gmail.com.',
    answerFa:
      'می‌توانید از گفتگوی زنده پشتیبانی، ثبت تیکت در مرکز پشتیبانی یا ایمیل مستقیم amirhossinbasirpor@gmail.com استفاده کنید.',
  },
];
