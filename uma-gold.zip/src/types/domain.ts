export type Language = 'en' | 'fa';

export type PageRoute =
  | 'landing'
  | 'overview'
  | 'prices'
  | 'iran-market'
  | 'intl-market'
  | 'ai-predictions'
  | 'demand-analysis'
  | 'production-planner'
  | 'inventory'
  | 'catalog'
  | 'calculator'
  | 'user-dashboard'
  | 'pricing'
  | 'payments'
  | 'support-center'
  | 'support-chat'
  | 'support-tickets'
  | 'faq'
  | 'contact'
  | 'auth'
  | 'profile'
  | 'legal-privacy'
  | 'legal-terms'
  | 'legal-refund'
  | 'legal-ai'
  | 'admin';

export type UserRole =
  | 'guest'
  | 'free'
  | 'pro'
  | 'organization'
  | 'support_agent'
  | 'admin'
  | 'super_admin';

export type PriceStatus = 'live' | 'delayed' | 'manual' | 'unavailable';

export interface GoldPriceItem {
  id: string;
  symbol: string;
  labelEn: string;
  labelFa: string;
  market: 'iran' | 'international';
  unit: string;
  price: number;
  change24hPct: number;
  status: PriceStatus;
  source: string;
  updatedBy?: string;
  updatedAt: string;
  isDemo?: boolean;
}

export interface CurrencyPriceItem {
  id: string;
  pair: string;
  labelEn: string;
  labelFa: string;
  rate: number;
  change24hPct: number;
  status: PriceStatus;
  source: string;
  updatedBy?: string;
  updatedAt: string;
  isDemo?: boolean;
}

export interface MarketHistoryPoint {
  id: string;
  symbol: string;
  dateLabel: string;
  price: number;
  sourceType: 'api' | 'manual' | 'demo';
}

export type JewelryCategorySlug =
  | 'rings'
  | 'bracelets'
  | 'bangles'
  | 'chains'
  | 'necklaces'
  | 'earrings'
  | 'pendants'
  | 'jewelry_sets';

export interface JewelryCategory {
  id: JewelryCategorySlug;
  slug: JewelryCategorySlug;
  nameEn: string;
  nameFa: string;
  sortOrder: number;
}

export interface JewelryModel {
  id: string;
  nameEn: string;
  nameFa: string;
  categoryId: JewelryCategorySlug;
  descriptionEn: string;
  descriptionFa: string;
  imageUrl: string;
  minWeightGrams: number;
  maxWeightGrams: number;
  purityKarat: number;
  laborFeePct: number;
  additionalCostPerUnit: number;
  productionHours: number;
  demandIndex: number;
  isActive: boolean;
  isDemo?: boolean;
}

export interface InventoryBalance {
  ownerId: string;
  meltedGoldGrams: number;
  meltedPurityPerMille: number;
  scrapGoldGrams: number;
  returnedGoldGrams: number;
  updatedAt: string;
}

export interface InventoryTransaction {
  id: string;
  ownerId: string;
  txType: 'melted_add' | 'melted_consume' | 'scrap_add' | 'scrap_recover' | 'returned_add' | 'adjustment';
  grossGrams: number;
  purityPerMille: number;
  fineGoldGrams: number;
  note: string;
  createdAt: string;
}

export interface ScrapRecord {
  id: string;
  ownerId: string;
  sourceLabel: string;
  grossGrams: number;
  purityPerMille: number;
  estimatedRecoveryPct: number;
  status: 'stored' | 'refined' | 'reused';
  createdAt: string;
}

export interface ReturnedGoldRecord {
  id: string;
  ownerId: string;
  itemLabel: string;
  grossGrams: number;
  purityPerMille: number;
  condition: 'reusable' | 'remelt_required' | 'stone_removal';
  createdAt: string;
}

export interface SalesRecord {
  id: string;
  ownerId: string;
  categoryId: JewelryCategorySlug;
  modelName: string;
  unitsSold: number;
  totalWeightGrams: number;
  saleDate: string;
  isDemo: boolean;
  createdAt: string;
}

export interface ProductionPlanItem {
  modelId: string;
  modelName: string;
  categoryId: string;
  units: number;
  unitWeightGrams: number;
  totalGoldGrams: number;
  estimatedLaborCost: number;
  rationale: string;
  demandConfidence: number;
}

export interface ProductionPlanScenario {
  planName: string;
  strategyType: 'balanced' | 'turnover' | 'margin';
  riskLevel: 'low' | 'medium' | 'high';
  explanation: string;
  items: ProductionPlanItem[];
  totals: {
    totalUnits: number;
    totalGoldRequiredGrams: number;
    maxAvailableTargetGoldGrams: number;
    remainingGoldGrams: number;
    estimatedProductionCost: number;
    estimatedProfit: number;
  };
}

export interface SavedProductionPlan {
  id: string;
  ownerId: string;
  title: string;
  availableMeltedGrams: number;
  meltedPurity: number;
  budget: number;
  totalGoldUsedGrams: number;
  estimatedProfit: number;
  riskLevel: 'low' | 'medium' | 'high';
  summary: string;
  createdAt: string;
}

export interface AIForecastResult {
  id?: string;
  horizon: 'short_term' | 'medium_term';
  market: 'iran' | 'international' | 'combined';
  dataSufficiency: 'sufficient' | 'limited' | 'insufficient';
  confidenceScore: number;
  riskLevel: 'low' | 'medium' | 'high';
  historicalFacts: string[];
  calculatedEstimates: string[];
  forecastOutlook: string;
  risingCategories: string[];
  decliningCategories: string[];
  keyDrivers: string[];
  disclaimer: string;
  generatedAt: string;
}

export interface SupportTicket {
  id: string;
  ownerId: string;
  subject: string;
  category: 'billing' | 'technical' | 'market_data' | 'production_ai' | 'general';
  priority: 'low' | 'medium' | 'high';
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  createdAt: string;
  updatedAt: string;
}

export interface SupportMessage {
  id: string;
  ownerId: string;
  ticketId: string;
  senderUid: string;
  senderRole: 'user' | 'support_agent' | 'admin';
  body: string;
  createdAt: string;
}

export interface PaymentRecord {
  id: string;
  ownerId: string;
  planId: 'pro' | 'organization';
  billingCycle: 'monthly' | 'annual';
  amount: number;
  currency: 'IRR' | 'USD';
  gateway: 'zarinpal' | 'international';
  authority?: string;
  refId?: string;
  status: 'pending' | 'verified' | 'failed' | 'refunded';
  isTestMode: boolean;
  createdAt: string;
}

export interface AppSettings {
  defaultLossPct: number;
  recoverableScrapPct: number;
  proMonthlyIrr: number;
  proAnnualIrr: number;
  proMonthlyUsd: number;
  proAnnualUsd: number;
  demoModeEnabled: boolean;
}
