export interface ProductionCalcInput {
  meltedWeightGrams: number;
  meltedPurityPerMille: number; // e.g., 750, 705, 900, 999.9
  targetPurityPerMille: number; // 750 (18K), 875 (21K), 999.9 (24K)
  unitsToProduce: number;
  unitFinishedWeightGrams: number;
  recoverableScrapPct: number; // e.g., 4.0%
  actualLossPct: number; // e.g., 1.5%
  goldPricePerGram18K: number;
  laborFeePct: number;
  additionalWorkshopCosts: number;
  retailMarkupPct: number;
}

export interface ProductionCalcResult {
  grossFinishedWeightGrams: number;
  pureGoldInFinishedGrams: number;
  availablePureGoldGrams: number;
  alloyAdjustmentGrams: number; // positive = copper/silver alloy to add, negative = fine 24K gold needed to upgrade purity
  needsFineGoldUpgrade: boolean;
  fineGoldToAddGrams: number;
  recoverableScrapGrams: number;
  permanentLossGrams: number;
  totalMeltedConsumedGrams: number;
  remainingMeltedInventoryGrams: number;
  goldCostValue: number;
  laborFeeCost: number;
  totalProductionCost: number;
  estimatedSellingRevenue: number;
  estimatedNetProfit: number;
  profitMarginPct: number;
  exceedsAvailableInventory: boolean;
  formulas: {
    fineGoldFormula: string;
    alloyFormula: string;
    scrapVsLossFormula: string;
    profitFormula: string;
  };
}

export function karatToPerMille(karat: number): number {
  if (karat >= 24) return 999.9;
  return Number(((karat / 24) * 1000).toFixed(2));
}

export function perMilleToKarat(perMille: number): number {
  return Number(((perMille / 1000) * 24).toFixed(2));
}

export function calculateProductionEconomics(input: ProductionCalcInput): ProductionCalcResult {
  const units = Math.max(0, input.unitsToProduce);
  const unitW = Math.max(0, input.unitFinishedWeightGrams);
  const grossFinishedWeightGrams = Number((units * unitW).toFixed(3));

  const targetFrac = Math.min(Math.max(input.targetPurityPerMille, 100), 999.9) / 1000;
  const sourceFrac = Math.min(Math.max(input.meltedPurityPerMille, 100), 999.9) / 1000;

  const pureGoldInFinishedGrams = Number((grossFinishedWeightGrams * targetFrac).toFixed(3));
  const availablePureGoldGrams = Number((input.meltedWeightGrams * sourceFrac).toFixed(3));

  // Gross weight required before permanent loss and recoverable scrap
  const lossFrac = Math.min(Math.max(input.actualLossPct, 0), 25) / 100;
  const scrapFrac = Math.min(Math.max(input.recoverableScrapPct, 0), 40) / 100;

  const permanentLossGrams = Number((grossFinishedWeightGrams * lossFrac).toFixed(3));
  const recoverableScrapGrams = Number((grossFinishedWeightGrams * scrapFrac).toFixed(3));

  // Pure gold actually consumed = finished pure gold + permanent loss pure gold
  // (Recoverable scrap retains its pure gold value and returns to workshop inventory!)
  const pureGoldConsumed = pureGoldInFinishedGrams + permanentLossGrams * targetFrac;

  // How much source melted gold is needed to supply pureGoldConsumed
  const totalMeltedConsumedGrams = sourceFrac > 0 ? Number((pureGoldConsumed / sourceFrac).toFixed(3)) : 0;

  // Alloy or fine gold adjustment to transform totalMeltedConsumedGrams from sourceFrac to targetFrac
  const targetGrossBeforeLoss = grossFinishedWeightGrams + permanentLossGrams;
  const rawAlloyDiff = targetGrossBeforeLoss - totalMeltedConsumedGrams;
  const needsFineGoldUpgrade = rawAlloyDiff < -0.001 && sourceFrac < targetFrac;
  const fineGoldToAddGrams = needsFineGoldUpgrade
    ? Number(Math.abs(pureGoldConsumed - input.meltedWeightGrams * sourceFrac).toFixed(3))
    : 0;
  const alloyAdjustmentGrams = !needsFineGoldUpgrade ? Number(Math.max(0, rawAlloyDiff).toFixed(3)) : 0;

  const exceedsAvailableInventory = totalMeltedConsumedGrams > input.meltedWeightGrams + 0.001;
  const remainingMeltedInventoryGrams = Number(
    Math.max(0, input.meltedWeightGrams - totalMeltedConsumedGrams).toFixed(3)
  );

  // Financial math (18K equivalent price scaling)
  const pricePerPureGram = input.goldPricePerGram18K / 0.75;
  const goldCostValue = Number((pureGoldConsumed * pricePerPureGram).toFixed(0));
  const laborFeeCost = Number(
    (grossFinishedWeightGrams * input.goldPricePerGram18K * (input.laborFeePct / 100)).toFixed(0)
  );
  const totalProductionCost = Number(
    (goldCostValue + laborFeeCost + input.additionalWorkshopCosts).toFixed(0)
  );
  const estimatedSellingRevenue = Number(
    (
      grossFinishedWeightGrams *
      (targetFrac / 0.75) *
      input.goldPricePerGram18K *
      (1 + (input.laborFeePct + input.retailMarkupPct) / 100)
    ).toFixed(0)
  );
  const estimatedNetProfit = Number((estimatedSellingRevenue - totalProductionCost).toFixed(0));
  const profitMarginPct =
    estimatedSellingRevenue > 0
      ? Number(((estimatedNetProfit / estimatedSellingRevenue) * 100).toFixed(2))
      : 0;

  return {
    grossFinishedWeightGrams,
    pureGoldInFinishedGrams,
    availablePureGoldGrams,
    alloyAdjustmentGrams,
    needsFineGoldUpgrade,
    fineGoldToAddGrams,
    recoverableScrapGrams,
    permanentLossGrams,
    totalMeltedConsumedGrams,
    remainingMeltedInventoryGrams,
    goldCostValue,
    laborFeeCost,
    totalProductionCost,
    estimatedSellingRevenue,
    estimatedNetProfit,
    profitMarginPct,
    exceedsAvailableInventory,
    formulas: {
      fineGoldFormula: `${grossFinishedWeightGrams}g × (${input.targetPurityPerMille}/1000) = ${pureGoldInFinishedGrams}g Au`,
      alloyFormula: needsFineGoldUpgrade
        ? `Upgrade ${input.meltedPurityPerMille}→${input.targetPurityPerMille}: +${fineGoldToAddGrams}g 24K`
        : `Dilute ${input.meltedPurityPerMille}→${input.targetPurityPerMille}: +${alloyAdjustmentGrams}g Alloy`,
      scrapVsLossFormula: `Recoverable Scrap: ${recoverableScrapGrams}g (${input.recoverableScrapPct}%) · Permanent Loss: ${permanentLossGrams}g (${input.actualLossPct}%)`,
      profitFormula: `Revenue (${estimatedSellingRevenue.toLocaleString()}) − Cost (${totalProductionCost.toLocaleString()}) = ${estimatedNetProfit.toLocaleString()}`,
    },
  };
}

/**
 * Iranian Gold Parity & Coin Bubble (Habab) Calculator
 */
export function calculateIranGoldParity(params: {
  xauUsd: number;
  usdIrr: number;
  market18kIrr: number;
  marketEmamiCoinIrr: number;
}) {
  const TROY_OUNCE_GRAMS = 31.1034768;
  const MITHQAL_GRAMS = 4.6083;
  const EMAMI_GROSS_GRAMS = 8.133;
  const EMAMI_PURITY = 0.9;

  const intrinsic24kPerGramIrr = (params.xauUsd * params.usdIrr) / TROY_OUNCE_GRAMS;
  const intrinsic18kPerGramIrr = intrinsic24kPerGramIrr * 0.75;
  const intrinsicMithqal17kIrr = intrinsic24kPerGramIrr * 0.705 * MITHQAL_GRAMS;
  const intrinsicEmamiIrr = intrinsic24kPerGramIrr * EMAMI_GROSS_GRAMS * EMAMI_PURITY;

  const gold18kBubbleIrr = params.market18kIrr - intrinsic18kPerGramIrr;
  const gold18kBubblePct =
    intrinsic18kPerGramIrr > 0 ? (gold18kBubbleIrr / intrinsic18kPerGramIrr) * 100 : 0;

  const coinBubbleIrr = params.marketEmamiCoinIrr - intrinsicEmamiIrr;
  const coinBubblePct = intrinsicEmamiIrr > 0 ? (coinBubbleIrr / intrinsicEmamiIrr) * 100 : 0;

  return {
    intrinsic24kPerGramIrr: Math.round(intrinsic24kPerGramIrr),
    intrinsic18kPerGramIrr: Math.round(intrinsic18kPerGramIrr),
    intrinsicMithqal17kIrr: Math.round(intrinsicMithqal17kIrr),
    intrinsicEmamiIrr: Math.round(intrinsicEmamiIrr),
    gold18kBubbleIrr: Math.round(gold18kBubbleIrr),
    gold18kBubblePct: Number(gold18kBubblePct.toFixed(2)),
    coinBubbleIrr: Math.round(coinBubbleIrr),
    coinBubblePct: Number(coinBubblePct.toFixed(2)),
  };
}
